"""临时诊断：看整篇禁则测试那份文稿到底折了几行。"""
from __future__ import annotations

import sys
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tests"))

import image_export as ie  # noqa: E402
import main as app_main  # noqa: E402
from image_export import Palette, _Fonts, build_layout  # noqa: E402
from test_export import ExportKinsokuLayoutTests, small_options  # noqa: E402

DOC = ExportKinsokuLayoutTests.DOC
print("文稿字面量：")
for chunk in DOC.split("\n"):
    print(f"  {len(chunk):>3} 字  {chunk[:30]!r}")

options = small_options()
fonts = _Fonts()
try:
    rows = app_main.build_export_rows(DOC, options)
    print(f"\n记录行 {len(rows)}")
    lines = build_layout(rows, options, Palette(), fonts)
    groups: list[list] = []
    for line in lines:
        if groups and groups[-1][0].row is line.row:
            groups[-1].append(line)
        else:
            groups.append([line])
    total = 0
    for group in groups:
        row = group[0].row
        text = "".join(p.text for p in row.pieces)
        if len(group) > 1:
            total += len(group) - 1
        print(f"  {row.kind:8} 显示行 {len(group):2}  {text[:44]!r}")
    print(f"\n续行合计 {total}")
finally:
    fonts.close()
