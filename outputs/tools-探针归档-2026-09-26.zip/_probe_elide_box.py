"""量「行首记号被 elide 时」`dlineinfo` 到底给什么盒子，word / char 两种折行对比。

背景：Tk 对自动换行的显示行按「该行第一个 chunk」算几何。行首那段被 elide
（`1. `、`> `、`# ` 平时都藏着）时，旧行为是返回那个宽 0 的空盒子，高度只剩
「行高 − 字体行距」——`is_real_display_box` 就是为滤掉它而写的。

把控件改成 `wrap="char"` 之后，`test_the_degenerate_box_really_is_taller_than_the_old_threshold`
这条**前提校验**失败了：第 2 行的 `dlineinfo` 不再是空盒子。这个探针把两种折行下的
原始盒子打出来，确认到底是「空盒子没了」还是「位置变了」。

    JIANJI_WRAP=word python tools/quiet_desktop.py <python 全路径> tools/_probe_elide_box.py
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402

DOC = (
    "1. 短的一条\n"
    "2. 这一条故意写得很长很长很长很长很长很长很长很长很长很长很长很长很长很长很长，"
    "长到必须折行才行，折行之后序号还能不能完整显示就是要看的东西\n"
    "3. 第三条\n"
    "> 引用的第一行也故意写得很长很长很长很长很长很长很长很长很长很长很长很长很长，"
    "长到必须折行\n"
    "> 引用第二行\n"
    "        1. 缩进最深的有序项也写得很长很长很长很长很长很长很长很长很长很长很长，"
    "长到必须折行\n"
)
SETTINGS = {"line_width": 60, "font_size": 18, "line_height": 34}


def main() -> int:
    tmp = Path(tempfile.mkdtemp())
    saved = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"
    folder = tmp / "简记日记"
    folder.mkdir()
    doc = folder / "折行.md"
    doc.write_text(DOC, encoding="utf-8")
    storage.set_default_folder(folder)
    storage.set_settings(dict(SETTINGS))

    import main as app_main  # noqa: E402

    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()
    if os.environ.get("JIANJI_WRAP"):
        app.editor.configure(wrap=os.environ["JIANJI_WRAP"])
    app.open_file(doc)
    root.update()
    app.editor.mark_set("insert", "end-1c")
    app._apply_styles_without_dirty_flag()
    root.update()

    editor = app.editor
    line_height = app_main.px(SETTINGS["line_height"])
    print(f"wrap={editor.cget('wrap')}  px(行高)={line_height}")
    for line in (2, 4):
        source = editor.get(f"{line}.0", f"{line}.end")
        print(f"\n--- 第 {line} 行  {source[:28]!r} ---")
        for index in range(0, 7):
            info = editor.dlineinfo(f"{line}.{index}")
            real = app_main.is_real_display_box(info, line_height)
            print(f"  dlineinfo({line}.{index}) = {info}  真实显示行={real}")
    root.destroy()
    storage.default_state_path = saved
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
