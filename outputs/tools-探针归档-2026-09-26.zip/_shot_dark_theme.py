"""核验「深色主题」：同一篇文稿、同一个界面，浅色与深色各抓一张。

用法：python tools/_shot_dark_theme.py
产出：outputs/主题-浅色.png、outputs/主题-深色.png（主窗口）
      outputs/主题-设置-浅色.png、outputs/主题-设置-深色.png（设置窗口）

**必须在当前桌面跑**（不是隐藏桌面）：这里抓的是窗口客户区 DC，
`capture_hwnd` 走的 `GetDC(hwnd)` 在隐藏桌面上也能用，但窗口要先真正映射出来，
留一份在看得见的地方更好核对。跑的时候会短暂弹出两个窗口。
"""
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import storage                                    # noqa: E402
from capture_window import capture_hwnd           # noqa: E402

DOC = """# 深色主题

这是一篇用来核验主题配色的文稿，把各类语法都摆上来，好看清深色下的层级。

## 行内样式

正文里可以有 **加粗**、*斜体*、~~删除线~~、==高亮==、`行内代码` 和
[链接](https://example.com)。

## 列表

- 第一层项目符号
- 第二层嵌套
  - 再深一层
- [x] 已经完成的任务
- [ ] 还没做的任务

1. 有序列表第一项
2. 有序列表第二项

## 引用

> 引用的文字前面有一条竖条，
> 续行也要连起来。

```python
def greet(name: str) -> str:
    return f"你好，{name}"
```

---

| 语法 | 是否支持 | 说明 |
| --- | :---: | --- |
| 标题 | 是 | H1 到 H6 |
| 表格 | 是 | 带表头底色与斑马纹 |
| 图片 | 是 | 紫色斜体的说明文字 |

### 结尾

到这里就结束了。
"""


def shoot(theme: str, out: Path) -> None:
    import tkinter as tk

    from main import JianJiApp

    tmp = Path(tempfile.mkdtemp())
    storage.default_state_path = lambda: tmp / "state.json"
    folder = tmp / "简记日记"
    folder.mkdir()
    doc = folder / "主题核验.md"
    doc.write_text(DOC, encoding="utf-8")
    (folder / "另一篇.md").write_text(
        "# 另一篇\n\n正文里的**加粗**与*斜体*也要能分清。\n", encoding="utf-8")
    storage.set_default_folder(folder)
    storage.set_settings({"theme": theme})

    root = tk.Tk()
    root.geometry("1240x820")
    app = JianJiApp(root)
    root.update()
    app.open_file(doc)
    root.update()
    app.editor.mark_set("insert", "1.0")
    app._apply_markdown_styles()
    root.update()

    assert app.theme == theme, f"期望 {theme}，实际 {app.theme}"

    width, height = capture_hwnd(int(root.winfo_id()), out / f"主题-{theme}.png")
    print(f"  outputs/主题-{theme}.png  {width}×{height}")

    # 设置窗口：主题开关就在里面，深色下它的底色也要跟着换
    app.open_settings()
    root.update()
    window = app.settings_window
    assert window is not None
    window.update()
    width, height = capture_hwnd(
        int(window.winfo_id()), out / f"主题-设置-{theme}.png")
    print(f"  outputs/主题-设置-{theme}.png  {width}×{height}")

    app._close_settings()
    root.update()

    # 字体选择窗口：搜索框、预览块、选中行都是单独挑过色的表面
    app.open_font_picker()
    root.update()
    picker = app.font_window
    assert picker is not None
    picker.update()
    width, height = capture_hwnd(
        int(picker.winfo_id()), out / f"主题-字体-{theme}.png")
    print(f"  outputs/主题-字体-{theme}.png  {width}×{height}")

    app._close_font_picker()
    root.destroy()


def main() -> None:
    out = PROJECT / "outputs"
    out.mkdir(exist_ok=True)
    for theme in ("light", "dark"):
        print(f"[{theme}]")
        shoot(theme, out)


if __name__ == "__main__":
    main()
