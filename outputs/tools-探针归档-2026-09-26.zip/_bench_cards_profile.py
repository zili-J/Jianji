"""把 `refresh_files` 拆开量：摘录（读盘 + 解析）vs 画布调用，各占多少。

用法：python tools/_bench_cards_profile.py
产出：屏幕输出 + outputs/卡片重建拆解.txt
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import time
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402


def build_doc(sections: int, title: str) -> str:
    parts = [f"# {title}\n"]
    for index in range(1, sections + 1):
        parts.append(f"\n## 第 {index} 节\n")
        parts.append(f"\n这是第 {index} 节的正文，带 **粗体** 和 `代码`。\n")
        parts.append(f"\n- 第 {index} 节的第一条\n  - 嵌套一条\n- [ ] 待办 {index}\n")
        parts.append(f"\n> 第 {index} 节的引用。\n")
        if index % 5 == 0:
            parts.append(f"\n| 项目 | 数量 |\n| --- | ---: |\n| 第 {index} 节 | {index} |\n")
    return "".join(parts)


def real_settings() -> dict:
    path = Path(os.environ.get("LOCALAPPDATA", "")) / "JianJi" / "state.json"
    try:
        return json.loads(path.read_text(encoding="utf-8")).get("settings", {})
    except (OSError, ValueError):
        return {}


def bench(sections: int, doc_count: int, out: list[str]) -> None:
    tmp = Path(tempfile.mkdtemp())
    state_path = tmp / "state.json"
    state_path.write_text(json.dumps({"settings": real_settings()}, ensure_ascii=False),
                          encoding="utf-8")
    storage.default_state_path = lambda: state_path
    folder = tmp / "简记日记"
    folder.mkdir()
    for i in range(doc_count):
        (folder / f"文稿-{i:03d}.md").write_text(build_doc(sections, f"文稿 {i}"),
                                                 encoding="utf-8")
    storage.set_default_folder(folder)

    import main
    from main import JianJiApp

    root = tk.Tk()
    root.geometry("1240x820")
    app = JianJiApp(root)
    app.refresh_files()
    root.update()

    tally: dict[str, float] = {"excerpt": 0.0, "trim": 0.0, "list": 0.0}
    counts: dict[str, int] = {"excerpt": 0, "trim": 0}

    real_excerpt = main._card_excerpt
    real_trim = JianJiApp._trim_card_text
    real_list = main.list_markdown

    def timed_excerpt(*args, **kwargs):
        start = time.perf_counter()
        try:
            return real_excerpt(*args, **kwargs)
        finally:
            tally["excerpt"] += time.perf_counter() - start
            counts["excerpt"] += 1

    def timed_trim(self, *args, **kwargs):
        start = time.perf_counter()
        try:
            return real_trim(self, *args, **kwargs)
        finally:
            tally["trim"] += time.perf_counter() - start
            counts["trim"] += 1

    def timed_list(*args, **kwargs):
        start = time.perf_counter()
        try:
            return real_list(*args, **kwargs)
        finally:
            tally["list"] += time.perf_counter() - start

    main._card_excerpt = timed_excerpt
    JianJiApp._trim_card_text = timed_trim
    main.list_markdown = timed_list

    root.update()
    for key in tally:
        tally[key] = 0.0
    start = time.perf_counter()
    app.refresh_files(app.current_path)
    root.update()
    total = (time.perf_counter() - start) * 1000

    main._card_excerpt = real_excerpt
    JianJiApp._trim_card_text = real_trim
    main.list_markdown = real_list

    excerpt_ms = tally["excerpt"] * 1000
    trim_ms = tally["trim"] * 1000
    list_ms = tally["list"] * 1000
    out.append(f"--- {doc_count} 篇 × {sections} 节 ---")
    out.append(f"  refresh_files 总计   {total:8.1f} ms")
    out.append(f"    摘录（读盘+解析）  {excerpt_ms:8.1f} ms  ×{counts['excerpt']}")
    out.append(f"    裁剪（二分测量）   {trim_ms:8.1f} ms  ×{counts['trim']}")
    out.append(f"    列文件             {list_ms:8.1f} ms")
    out.append(f"    其余（画图元）     {total - excerpt_ms - trim_ms - list_ms:8.1f} ms")
    out.append("")
    root.destroy()


if __name__ == "__main__":
    lines: list[str] = []
    for sections, doc_count in ((20, 6), (60, 12), (150, 30), (400, 60)):
        bench(sections, doc_count, lines)
    text = "\n".join(lines)
    print(text)
    out_dir = PROJECT / "outputs"
    out_dir.mkdir(exist_ok=True)
    (out_dir / "卡片重建拆解.txt").write_text(text, encoding="utf-8")
