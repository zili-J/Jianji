"""临时核验：复现「文档比视口少时，往上滚会把整列推到下方、顶部留一条空白」。

复现条件（用户截图里正好满足）：
  · 中间列表的内容比画布视口矮 → Tk 不夹原点
  · 滚轮往上滚一格 → 原点变成 -视口/10，内容整体下移，顶上留白
  · yview() 仍然报 (0.0, 1.0)，滚动条上完全看不出异常

修复前 / 修复后各截一张图。用完可以删。
"""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402
from capture_window import crop_bgra, encode_png, grab_hwnd  # noqa: E402


class Wheel:
    def __init__(self, delta: int) -> None:
        self.delta = delta


def main() -> None:
    tmp = Path(tempfile.mkdtemp())
    real_path = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"

    folder = tmp / "简记日记"
    folder.mkdir()
    (folder / "2026-09-20.md").write_text(
        "# 周六\n\n上午去了一趟书店，挑了两本一直想读的书。\n"
        "下午在窗边看完其中一本的前两章。\n傍晚下楼走了走，风很凉。\n",
        encoding="utf-8",
    )
    (folder / "2026-09-19.md").write_text(
        "# 周五\n\n把积了两周的衣服洗了。\n晚上做了番茄牛腩，炖得有点久。\n",
        encoding="utf-8",
    )
    storage.set_default_folder(folder)

    import main as app_main

    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()
    root.update_idletasks()

    canvas = app.cards_canvas
    out = PROJECT / "outputs"
    region_h = 400

    def shot(name: str) -> None:
        root.update()
        w, h, data = grab_hwnd(int(root.winfo_id()))
        x = canvas.winfo_rootx() - root.winfo_rootx()
        y = canvas.winfo_rooty() - root.winfo_rooty()
        cw, ch, cdata = crop_bgra(
            w, h, data,
            (x, y, x + canvas.winfo_width(), min(h, y + region_h)),
        )
        path = out / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(encode_png(cw, ch, cdata))
        print(f"  截图 {path.name}  {cw}x{ch}")

    def report(label: str) -> None:
        top = min(
            (canvas.bbox(i)[1] for i in canvas.find_all() if canvas.type(i) == "text"),
            default=None,
        )
        print(f"  {label:<12} 视口高 {canvas.winfo_height():<5} "
              f"滚动区高 {str(canvas.cget('scrollregion')).split()[3]:<5} "
              f"canvasy(0)={canvas.canvasy(0):<7.1f} yview={tuple(round(v, 3) for v in canvas.yview())} "
              f"最靠上的卡片文字 y={top}")

    print(f"文稿 {len(app.file_paths)} 篇，画布 {canvas.winfo_width()}x{canvas.winfo_height()}")
    original = app_main.JianJiApp._clamp_cards_scroll

    print("\n【修复前】把夹原点关掉：")
    app_main.JianJiApp._clamp_cards_scroll = lambda self: None
    report("起点")
    app._on_cards_wheel(Wheel(120))          # 往上滚一格
    report("往上滚一格")
    shot("修复前-顶部空白.png")

    print("\n【修复后】恢复夹原点：")
    app_main.JianJiApp._clamp_cards_scroll = original
    app._rebuild_cards()
    root.update()
    report("重建后")
    app._on_cards_wheel(Wheel(120))          # 再往上滚一格
    report("往上滚一格")
    shot("修复后-顶部无空白.png")

    root.destroy()
    storage.default_state_path = real_path


if __name__ == "__main__":
    main()
