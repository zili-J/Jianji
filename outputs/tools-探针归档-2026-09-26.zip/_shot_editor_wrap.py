"""截编辑区的图，看「空格 / 中英混合」导致的提前折行，以及正文块宽度。

用户第 11 轮反馈（都在**编辑区**）：
  1. 引用有中英混合时，会出现换行；
  2. 文字间插入空格，会出现换行；
  3. 编辑区的显示比例（正文块宽度）不对。

产出放 outputs/。同类见 _shot_ui_chrome.py。
"""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import json  # noqa: E402
import os  # noqa: E402

import storage  # noqa: E402
import tkinter as tk  # noqa: E402
from capture_window import capture_hwnd, capture_widget_region  # noqa: E402

REAL_STATE = Path(os.environ.get("LOCALAPPDATA", "")) / "JianJi" / "state.json"

DOC = (
    "# 折行核验\n"                                                    # 1
    "\n"                                                              # 2
    "这是一段用来做对照的纯中文文字里面完全没有空格所以折行位置应该填满整行才对。\n"  # 3
    "\n"                                                              # 4
    "短 后面这一整串中文没有任何空格所以会被当成一个词整串挪到下一行去。\n"          # 5
    "\n"                                                              # 6
    "> 引用开头 English 后面这一整串中文没有任何空格会被整串挪到下一行去。\n"        # 7
    "\n"                                                              # 8
    "- 列表开头 English 后面这一整串中文没有任何空格会被整串挪到下一行去。\n"        # 9
)


def main() -> int:
    tmp = Path(tempfile.mkdtemp())
    real = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"

    folder = tmp / "简记日记"
    folder.mkdir()
    doc = folder / "折行核验.md"
    doc.write_text(DOC, encoding="utf-8")
    storage.set_default_folder(folder)
    # 核验必须在**用户真实设置**下做：行宽 60 / 字号 18 / 行高 34，折行位置与默认完全不同
    settings = {}
    if REAL_STATE.is_file():
        settings = json.loads(REAL_STATE.read_text(encoding="utf-8")).get("settings", {})
    if settings:
        storage.set_settings(dict(settings))
        print(f"用户设置：{settings}")

    import main as app_main

    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()
    app.open_file(doc)
    root.update()

    out = PROJECT / "outputs"
    editor = app.editor
    width = editor.winfo_width()
    pad = app._current_pad
    print(f"窗口 {root.winfo_width()}  控件宽 {width}  留白 {pad}  "
          f"正文块宽 {width - 2 * pad}  = {((width - 2 * pad) / width) * 100:.1f}% 控件宽")
    print(f"正文块宽 ÷ 窗口宽 = {((width - 2 * pad) / root.winfo_width()) * 100:.1f}%")

    # 1) 整窗：看正文块在窗口里的比例（第 3 条）
    size = capture_hwnd(int(root.winfo_id()), out / "核验-编辑区比例-整窗.png")
    print(f"核验-编辑区比例-整窗.png {size[0]}×{size[1]}")

    # 2) 光标停在末尾：正文整体按「非光标行」显示，看有空格的那几行填不填满
    editor.mark_set("insert", "end-1c")
    editor.see("insert")
    app._refresh_cursor_line()
    root.update()
    size = capture_widget_region(editor, out / "核验-空格折行-修复后.png", factor=2)
    print(f"核验-空格折行-修复后.png {size[0]}×{size[1]}")

    # 3) 光标停在「中英混合的引用」那一行（第 1 条）
    editor.mark_set("insert", "7.end")
    editor.see("insert")
    app._refresh_cursor_line()
    root.update()
    size = capture_widget_region(editor, out / "核验-光标在混合引用行.png", factor=2)
    print(f"核验-光标在混合引用行.png {size[0]}×{size[1]}")

    root.destroy()
    storage.default_state_path = real
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
