"""按关键词找到逻辑行与显示行，看「列表项的续行」有没有被并进同一行。

    python tools/quiet_desktop.py <python 全路径> tools/_probe_join.py 关键词 [文稿路径]
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))

import image_export as ie  # noqa: E402
import main as app_main  # noqa: E402
import storage  # noqa: E402
import tkinter as tk  # noqa: E402

REAL_STATE = Path(os.environ.get("LOCALAPPDATA", "")) / "JianJi" / "state.json"
NEEDLE = sys.argv[1] if len(sys.argv) > 1 else "滚到底部会留一段空白"
DOC = Path(sys.argv[2]) if len(sys.argv) > 2 else \
    Path(r"C:\Users\22910\Documents\wb01\说明书\简记使用说明.md")


def row_text(row) -> str:
    if row.kind == "table":
        return " | ".join("".join(p.text for p in cell) for line in row.cells for cell in line)
    return "".join(p.text for p in row.pieces)


def main() -> int:
    tmp = Path(tempfile.mkdtemp())
    saved = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"
    settings = json.loads(REAL_STATE.read_text(encoding="utf-8")).get("settings", {})
    folder = tmp / "d"
    folder.mkdir()
    (tmp / "state.json").write_text(json.dumps({
        "folder": str(folder), "default_folder": str(folder),
        "last_file": "", "settings": settings}, ensure_ascii=False), encoding="utf-8")

    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()
    options = app._export_options()
    fonts = ie._Fonts()
    try:
        rows = app_main.build_export_rows(DOC.read_text(encoding="utf-8-sig"), options)
        hit = [i for i, row in enumerate(rows) if NEEDLE in row_text(row)]
        print(f"命中逻辑行下标：{hit}")
        for i in hit:
            for j in range(max(0, i - 1), min(len(rows), i + 3)):
                row = rows[j]
                mark = ">>>" if j == i else "   "
                text = row_text(row)
                print(f"{mark} row[{j}] kind={row.kind:<8} level={getattr(row, 'level', '-')} "
                      f"({len(text)} 字) [{text[:70]}]")

        lines = ie.build_layout(rows, options, app_main.export_palette(), fonts)
        print("\n命中显示行：")
        for index, line in enumerate(lines):
            text = "".join(p.text for p in line.pieces)
            if NEEDLE in text or "光标停在末尾" in text or "写。" == text:
                avail = options.margin + options.content_width - line.x
                width = ie._measure(line.pieces, fonts)
                print(f"  y={line.top:<6} x={line.x:<4} wrap={line.wrap!s:<5} "
                      f"{width:>4}/{avail}px ({width / avail * 100:5.1f}%) [{text}]")
    finally:
        fonts.close()
        root.destroy()
        storage.default_state_path = saved
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
