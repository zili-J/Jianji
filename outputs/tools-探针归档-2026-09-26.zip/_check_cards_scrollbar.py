"""临时核验：滚动条改用包装函数后，Tk 侧调用命令仍走得通。

不用鼠标事件（Tk 的滚动条轨道点击会进事件循环等松开，会挂住），
改成直接按 Tk 的调用形态去调那条已注册的 Tcl 命令：
`command moveto 0.5` / `command scroll 1 units`。
"""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402


def main() -> int:
    tmp = Path(tempfile.mkdtemp())
    real = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"
    folder = tmp / "很多篇"
    folder.mkdir()
    for i in range(40):
        (folder / f"第{i:02d}篇.md").write_text(
            f"# 标题{i}\n\n第{i}篇的正文，写长一点。\n第二行。\n第三行。\n", encoding="utf-8")
    storage.set_default_folder(folder)

    import main as app_main

    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()

    sb = next(c for c in app.cards_canvas.master.winfo_children()
              if isinstance(c, tk.Scrollbar))
    canvas = app.cards_canvas
    command = sb.cget("command")
    print(f"文稿 {len(app.file_paths)} 篇  画布高 {canvas.winfo_height()}")
    print(f"滚动条命令名 {command}")
    print(f"起点          canvasy(0)={canvas.canvasy(0):.1f}")

    root.tk.call(command, "moveto", "0.5")
    root.update()
    print(f"moveto 0.5    canvasy(0)={canvas.canvasy(0):.1f}  "
          f"yview={tuple(round(v, 3) for v in canvas.yview())}")

    root.tk.call(command, "scroll", "3", "units")
    root.update()
    print(f"scroll 3 单位 canvasy(0)={canvas.canvasy(0):.1f}  "
          f"yview={tuple(round(v, 3) for v in canvas.yview())}")

    root.tk.call(command, "moveto", "0.0")
    root.update()
    print(f"moveto 0.0    canvasy(0)={canvas.canvasy(0):.1f}  "
          f"yview={tuple(round(v, 3) for v in canvas.yview())}")

    # 内容矮（一屏放得下）时，点轨道往上滚也不该把列表推下去
    app.scope_folder = tmp / "只有一篇"
    (tmp / "只有一篇").mkdir()
    (tmp / "只有一篇" / "短篇.md").write_text("# 短\n\n很短。\n", encoding="utf-8")
    app.refresh_files()
    root.update()
    print(f"\n换成 1 篇：滚动区高 {str(canvas.cget('scrollregion')).split()[3]}  "
          f"画布高 {canvas.winfo_height()}")
    root.tk.call(command, "scroll", "-1", "units")
    root.update()
    print(f"点轨道往上滚  canvasy(0)={canvas.canvasy(0):.1f}（应为 0.0）")

    root.destroy()
    storage.default_state_path = real
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
