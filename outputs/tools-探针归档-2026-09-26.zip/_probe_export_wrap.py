"""查「导出长图时随机增加换行」。

思路：折行是 `image_export._wrap` 干的，它**逐字累加宽度**决定断在哪。
如果它算出来的宽度偏大（或可用宽度偏小），就会出现**过早断行**——本来放得下
的下一段被推到新的一行，肉眼看就是「凭空多了一个换行」。

判据（不靠猜）：对同一段落里每一对相邻显示行 (a, b)，b 是折出来的续行，
则把 b 开头那一个「单位」接回 a 后面，如果**仍然放得下**，这次断行就是过早的。
- 中文：一个单位 = 一个字符
- 西文：一个单位 = 到下一个空格为止的一个词
（a 的宽度用 `_measure`，可用宽度用 `build_layout` 里同一个公式算。）

顺带把每段的「填充率」分布打出来——填充率普遍偏低就说明是系统性的，
而不是偶发。

    python tools/_probe_export_wrap.py [文稿...]
"""
from __future__ import annotations

import collections
import sys
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import image_export as ie  # noqa: E402
import main as app_main  # noqa: E402

DEFAULT_DOCS = [
    Path(r"C:\Users\22910\Documents\wb01\说明书\project.md"),
    Path(r"C:\Users\22910\Documents\wb01\说明书\简记使用说明.md"),
]


def options_for(app=None) -> ie.Options:
    """尽量用真实导出参数（有 app 就走 app，没有就用模块默认值）。"""
    return app._export_options() if app is not None else ie.Options()


def next_unit(text: str) -> str:
    """续行开头的「一个单位」：西文取一个词，中文取一个字。"""
    if not text:
        return ""
    if ie._is_wide(text[0]):
        return text[0]
    # 西文/数字：一直取到下一个空格
    end = 0
    while end < len(text) and not text[end].isspace() and not ie._is_wide(text[end]):
        end += 1
    return text[:end] if end else text[0]


def analyse(doc: Path, options: ie.Options, fonts: ie._Fonts) -> dict:
    text = doc.read_text(encoding="utf-8-sig")
    rows = app_main.build_export_rows(text, options)
    lines = ie.build_layout(rows, options, app_main.export_palette(), fonts)

    # 按行（Row）分组，保留顺序
    groups: list[list[ie._DisplayLine]] = []
    for line in lines:
        if groups and groups[-1][0].row is line.row:
            groups[-1].append(line)
        else:
            groups.append([line])

    stats = collections.Counter()
    premature: list[str] = []
    fill_ratios: list[float] = []

    for group in groups:
        row = group[0].row
        if row.kind == "table":
            stats["跳过表格"] += 1
            continue
        indent = options.margin
        if row.kind in ("bullet", "task", "ordered"):
            indent = options.list_left(row.level)
        elif row.kind == "quote":
            indent = options.margin + options.list_indent
        available = max(40, options.margin + options.content_width - indent)

        for index in range(len(group) - 1):
            head = group[index]
            tail = group[index + 1]
            if not tail.wrap:
                continue
            stats["续行"] += 1
            head_width = ie._measure(head.pieces, fonts)
            # 断行时那个空格也算进了行宽（`_trim_tail` 是事后才把它裁掉的），
            # 所以判「还放不放得下」要把这个空格加回去——否则会把**正确的**断行
            # 全报成过早（实测 18 个「过早」里有 17 个是这么来的）。
            gap = fonts.width(" ", head.pieces[-1].font) if head.pieces else 0
            fill_ratios.append(head_width / available)
            unit = next_unit(tail.pieces[0].text if tail.pieces else "")
            if not unit:
                continue
            need = head_width + gap + fonts.width(unit, tail.pieces[0].font)
            if need <= available:
                stats["过早断行"] += 1
                if len(premature) < 12:
                    head_text = "".join(p.text for p in head.pieces)
                    tail_text = "".join(p.text for p in tail.pieces)
                    premature.append(
                        f"      行 {head.row.kind}：{head_text[-26:]!r} ‖ {tail_text[:26]!r}\n"
                        f"         已用 {head_width} + 空格 {gap} + 下一个单位 {unit!r} "
                        f"({fonts.width(unit, tail.pieces[0].font)}) = {need} "
                        f"≤ 可用 {available}（还差 {available - head_width}）")
            else:
                stats["断得合理"] += 1

    return {"doc": doc, "stats": stats, "premature": premature,
            "fill": fill_ratios}


def main() -> int:
    docs = [Path(p) for p in sys.argv[1:]] or DEFAULT_DOCS
    docs = [d for d in docs if d.is_file()]
    if not docs:
        print("没找到可用的文稿")
        return 1

    options = options_for()
    print(f"导出参数：宽 {options.width}  边距 {options.margin}  "
          f"正文列宽 {options.content_width}  正文字号 {options.body_size}  "
          f"行高 {options.line_height}")
    fonts = ie._Fonts()
    try:
        total = collections.Counter()
        for doc in docs:
            result = analyse(doc, options, fonts)
            stats = result["stats"]
            fill = sorted(result["fill"])
            print(f"\n=== {doc.name} ===")
            print(f"  续行 {stats['续行']} 个：断得合理 {stats['断得合理']}，"
                  f"**过早断行 {stats['过早断行']}**")
            if fill:
                mid = fill[len(fill) // 2]
                print(f"  折行前一行填充率：最低 {fill[0]:.1%}  中位 {mid:.1%}  "
                      f"最高 {fill[-1]:.1%}")
                low = sum(1 for f in fill if f < 0.9)
                print(f"  填充率 < 90% 的续行：{low} / {len(fill)}")
            if result["premature"]:
                print("  例子：")
                print("\n".join(result["premature"]))
            total.update(stats)
        print(f"\n合计：续行 {total['续行']}，断得合理 {total['断得合理']}，"
              f"过早断行 {total['过早断行']}")
    finally:
        fonts.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
