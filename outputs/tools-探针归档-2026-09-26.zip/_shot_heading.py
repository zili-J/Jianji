"""截取「各级标题字号与正文一致」的核验图。

产出：
  outputs/标题字号一致预览.png   —— 整窗
  outputs/标题字号一致特写.png   —— 编辑区 2 倍放大（看字号是否真的齐平）
"""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402
from capture_window import capture_hwnd, capture_widget_region  # noqa: E402

DOC = """# 一级标题

正文段落，字号与一级标题完全相同，只靠加粗和上下留白区分层级。

## 二级标题

再写一段正文用来对照：二级标题和这段正文应该一样大。

### 三级标题

最后一段正文。三级标题同样不放大，只是加粗而已。

正文里还有 **加粗**、*斜体* 与 `行内代码` 三种行内样式。
"""


def main() -> None:
    tmp = Path(tempfile.mkdtemp())
    real_state = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"

    folder = tmp / "简记日记"
    folder.mkdir()
    doc = folder / "标题字号.md"
    doc.write_text(DOC, encoding="utf-8")
    storage.set_default_folder(folder)

    from main import JianJiApp

    root = tk.Tk()
    app = JianJiApp(root)
    app.open_file(doc)
    root.update()

    # 把光标放到文末，让标题行的 Markdown 记号被隐藏，看到真正的排版效果
    app.editor.mark_set("insert", "end-1c")
    app._apply_styles_without_dirty_flag()
    root.update()
    root.update_idletasks()

    out_dir = PROJECT / "outputs"
    out_dir.mkdir(parents=True, exist_ok=True)

    w, h = capture_hwnd(int(root.winfo_toplevel().winfo_id()),
                        out_dir / "标题字号一致预览.png")
    print(f"full   {w} x {h}")

    zw, zh = capture_widget_region(app.editor, out_dir / "标题字号一致特写.png", factor=2)
    print(f"zoom   {zw} x {zh}")

    root.destroy()
    storage.default_state_path = real_state


if __name__ == "__main__":
    main()
