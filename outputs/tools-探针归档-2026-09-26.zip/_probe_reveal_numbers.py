"""临时诊断：把 `_inline_reveal_fits` 用到的几个量打出来，校准可用宽度。"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402

REAL_STATE = Path(os.environ.get("LOCALAPPDATA", "")) / "JianJi" / "state.json"
FILLER = "列表项正文要够长才会折行，这里故意写得长一些用来观察折行位置。"
LINE = "- **" + (FILLER * 4)[:34] + "**：说明"
PLAIN = "- " + (FILLER * 4)[:34] + "：说明"


def main() -> int:
    tmp = Path(tempfile.mkdtemp())
    saved = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"
    settings = json.loads(REAL_STATE.read_text(encoding="utf-8")).get("settings", {})
    folder = tmp / "简记日记"
    folder.mkdir()
    doc = folder / "校准.md"
    doc.write_text("# 校准\n\n" + LINE + "\n\n" + PLAIN + "\n\n见证行。\n", encoding="utf-8")
    (tmp / "state.json").write_text(json.dumps({
        "folder": str(folder), "default_folder": str(folder),
        "last_file": str(doc), "settings": settings}, ensure_ascii=False), encoding="utf-8")

    import main as app_main
    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()
    app.open_file(doc)
    root.update()
    ed = app.editor
    print(f"设置 {app.settings}")
    print(f"winfo_width={ed.winfo_width()}  _current_pad={app._current_pad}  "
          f"px(LIST_INDENT)={app_main.px(app_main.LIST_INDENT)}")
    print(f"list_indent(0)={app_main.list_indent(0)}  "
          f"正文列宽={ed.winfo_width() - app._current_pad * 2}")
    for number, text in ((3, LINE), (5, PLAIN)):
        for where in ("光标在别处", "光标在本行"):
            if where == "光标在本行":
                ed.mark_set("insert", f"{number}.end")
                app._refresh_cursor_line()
                root.update()
            else:
                ed.mark_set("insert", "1.0")
                app._refresh_cursor_line()
                root.update()
            ed.tk.call(ed, "count", "-update", "1.0", "end")
            source = ed.get(f"{number}.0", f"{number}.end")
            boxes = [ed.bbox(f"{number}.{i}") for i in range(len(source) + 1)]
            print(f"\n第 {number} 行 {source[:14]!r}…  【{where}】")
            print(f"  tags = {sorted(set(ed.tag_names(f'{number}.4')))}")
            rows = {}
            for i, box in enumerate(boxes):
                if box and box[2] > 0 and box[3] > 0:
                    rows.setdefault(box[1], []).append((i, box[0], box[2], box[3]))
            for top in sorted(rows):
                items = rows[top]
                print(f"  显示行 y={top} 高={items[0][3]} "
                      f"字 {items[0][0]}..{items[-1][0]} "
                      f"x {items[0][1]}..{max(x + w for _i, x, w, _h in items)}")
    root.destroy()
    storage.default_state_path = saved
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
