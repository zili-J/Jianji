"""渲染「禁则修复前 / 修复后」的导出长图，各裁一段出来对照。

裁的是用户真文稿里**实测出问题**的那两处：句号单独占一行（y≈4400）、
逗号跑到行首（y≈5000）。y 坐标是从 `tools/_probe_export_break.py` 打出来的。

    python tools/quiet_desktop.py tools/_shot_export_kinsoku.py
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import image_export as ie  # noqa: E402
import main as app_main  # noqa: E402
import storage  # noqa: E402
import tkinter as tk  # noqa: E402

from _probe_export_break import raw_break  # noqa: E402
from png_crop import crop  # noqa: E402

REAL_STATE = Path(os.environ.get("LOCALAPPDATA", "")) / "JianJi" / "state.json"
DOC = Path(r"C:\Users\22910\Documents\wb01\说明书\简记使用说明.md")
OUT = PROJECT / "outputs"
# (起点 y, 高度, 文件名后缀)
WINDOWS = [(4340, 260, "句号"), (4900, 220, "逗号")]


def main() -> int:
    tmp = Path(tempfile.mkdtemp())
    saved = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"
    settings = json.loads(REAL_STATE.read_text(encoding="utf-8")).get("settings", {})
    folder = tmp / "简记日记"
    folder.mkdir()
    (tmp / "state.json").write_text(json.dumps({
        "folder": str(folder), "default_folder": str(folder),
        "last_file": "", "settings": settings}, ensure_ascii=False), encoding="utf-8")

    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()
    options = app._export_options()
    fonts = ie._Fonts()
    saved_break = ie._break_index
    try:
        rows = app_main.build_export_rows(DOC.read_text(encoding="utf-8-sig"), options)
        for tag, breaker in (("修复后", None), ("修复前", raw_break)):
            ie._break_index = breaker or saved_break
            images = ie.render(rows, options, app_main.export_palette(), fonts)
            full = tmp / f"导出-{tag}.png"
            full.write_bytes(images[0])
            for top, height, what in WINDOWS:
                target = OUT / f"禁则{tag}-{what}.png"
                crop(full, target, top, height)
                print(f"{target.name}  ← 源图 {len(images)} 张")
    finally:
        ie._break_index = saved_break
        fonts.close()
        root.destroy()
        storage.default_state_path = saved
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
