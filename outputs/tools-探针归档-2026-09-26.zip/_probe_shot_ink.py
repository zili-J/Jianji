"""从截图里量出「正文块」的左右边界，用来比较不同版本之间的排版比例。

只在编辑区横向范围内统计每一列有多少非背景像素，找正文墨迹最右/最左的那一列。
这样不用靠肉眼估，能直接回答「正文块是不是变窄了」。

    python tools/_probe_shot_ink.py 图1.png 图2.png ...
"""
from __future__ import annotations

import sys
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "tools"))

from png_crop import decode_png  # noqa: E402


def profile(path: Path, x0: int, x1: int, y0: int, y1: int) -> None:
    width, height, pixels = decode_png(path)
    x1 = min(x1, width)
    y1 = min(y1, height)
    counts = [0] * width
    for y in range(y0, y1):
        row = y * width * 4
        for x in range(x0, x1):
            i = row + x * 4
            r, g, b = pixels[i], pixels[i + 1], pixels[i + 2]
            # 背景是浅灰白（>235 且三通道接近）；低于它就算墨迹
            if not (r > 232 and g > 232 and b > 232):
                counts[x] += 1
    ink = [x for x in range(x0, x1) if counts[x] > 0]
    print(f"{path.name}  {width}×{height}")
    if not ink:
        print("   该范围内没有墨迹")
        return
    # 打印空档：正文块右边界 / 行号列 / 滚动条之间都是空档
    gaps: list[tuple[int, int]] = []
    start = None
    for x in range(x0, x1):
        if counts[x] == 0:
            if start is None:
                start = x
        elif start is not None:
            if x - start >= 12:
                gaps.append((start, x))
            start = None
    if start is not None and x1 - start >= 12:
        gaps.append((start, x1))
    print(f"   墨迹最左 x={ink[0]}   墨迹最右 x={ink[-1]}")
    print(f"   空档（>=12 列）: {gaps}")


def main() -> int:
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    # 编辑区大致横向范围：跳过左侧导航与卡片栏，避开右侧行号列/滚动条
    for arg in sys.argv[1:]:
        profile(Path(arg), 700, 1440, 100, 700)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
