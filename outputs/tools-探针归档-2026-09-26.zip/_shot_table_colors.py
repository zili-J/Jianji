"""核验表格渲染与彩色语法在真实窗口里的效果。

产出 outputs/表格与彩色语法-1.png ~ -N.png。
"""
from __future__ import annotations

import re
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402
from capture_window import capture_hwnd  # noqa: E402

DOC = """# 彩色语法与表格

## 一、表格

### 1. 带对齐的基础表格

| 项目 | 数量 | 单价 | 备注 |
| --- | ---: | ---: | :---: |
| 苹果 | 3 | 5.50 | 很甜 |
| 香蕉 | 5 | 3.20 | 很软 |
| 车厘子 | 12 | 28.00 | 有点贵 |

表格里的行内语法照常生效：**加粗**、*斜体*、`代码` 都认。

### 2. 单列表格

| 待办 |
| --- |
| 写周报 |
| 交房租 |

## 二、各级标题的颜色

# 一级标题
## 二级标题
### 三级标题
#### 四级标题
##### 五级标题
###### 六级标题

## 三、列表与引用

- 第一层项目符号
  - 第二层是空心圆，颜色不同
    - 第三层换成方块
      - 第四层

1. 有序列表用蓝色序号
2. 第二条

- [ ] 还没做的事
- [x] 已经做完的事

> 引用的竖条是淡蓝色。
> 第二行连成一条。

## 四、行内语法

**粗体**、*斜体*、~~删除线~~、==高亮==、`行内代码`，
还有 [链接文字](https://example.com) 和 ![图片说明](a.png)。

---

分隔线也是彩色的。
"""


def main() -> None:
    tmp = Path(tempfile.mkdtemp())
    folder = tmp / "简记日记"
    folder.mkdir()
    doc = folder / "彩色语法.md"
    doc.write_text(DOC, encoding="utf-8")
    real_state = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"
    storage.set_default_folder(folder)

    from main import JianJiApp

    root = tk.Tk()
    app = JianJiApp(root)
    app.open_file(doc)
    root.update()

    app.editor.mark_set("insert", "end-1c")
    app._apply_styles_without_dirty_flag()
    root.update()
    root.update_idletasks()

    lines = re.split(r"\r\n|\r|\n", app.editor.get("1.0", "end-1c"))
    print(f"文档 {len(lines)} 行")

    frames = [c for c in app._table_pool if c.winfo_manager()]
    print(f"画出的表格框：{len(frames)} 个（应为 2）")
    for canvas in frames:
        items = canvas.find_all()
        kinds = [canvas.type(item) for item in items]
        print(f"  位置 x={canvas.winfo_x()} y={canvas.winfo_y()} "
              f"尺寸 {canvas.winfo_width()}x{canvas.winfo_height()}  "
              f"图元 {kinds}")

    def hidden(index: str) -> bool:
        def in_tag(tag: str, where: str) -> bool:
            raw = app.editor.tag_ranges(tag)
            for i in range(0, len(raw), 2):
                if (app.editor.compare(where, ">=", raw[i])
                        and app.editor.compare(where, "<", raw[i + 1])):
                    return True
            return False
        return in_tag("syntax", index) and not in_tag("syntax_current", index)

    print("表格首行隐藏的字符：")
    row = app.editor.get("5.0", "5.end").rstrip("\r\n")
    print(f"  原文 {row!r}")
    print(f"  隐藏 {''.join(ch for i, ch in enumerate(row) if hidden(f'5.{i}'))!r}（应只有竖线和空格）")

    out_dir = PROJECT / "outputs"
    out_dir.mkdir(parents=True, exist_ok=True)
    for index in range(3):
        app.editor.yview_moveto(index / 3.0)
        app._apply_styles_without_dirty_flag()
        root.update()
        root.update_idletasks()
        path = out_dir / f"表格与彩色语法-{index + 1}.png"
        w, h = capture_hwnd(int(root.winfo_toplevel().winfo_id()), path)
        print(f"  {path.name}  {w}x{h}")

    # 再截一张特写：把表格区域裁出来放大
    print("done")
    root.destroy()
    storage.default_state_path = real_state


if __name__ == "__main__":
    main()
