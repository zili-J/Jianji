"""截「行首记号露出前后」的对照图，用**用户自己的设置**。

「修复前」不是靠注释掉代码，而是把 `_tag_marker` 换回旧行为（只加 `syntax_current`，
不做缩进补偿、不按字符折行），这样两张图的差别就只来自那一处改动。

一次性核验脚本，产出放 outputs/。
"""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402

REAL_STATE = Path.home() / "AppData/Local/JianJi/state.json"

TAIL = "，正文写得长一些好让这一行折起来，才能看出折行位置有没有被改动过。"
DOC = "\n".join([
    "# 记号核验", "",
    "- 这是一条会折行的无序列表项" + TAIL, "",
    "- [ ] 这是一条会折行的任务项" + TAIL, "",
    "> 这是一条会折行的引用" + TAIL, "",
    "1. 这是一条会折行的有序项" + TAIL, "",
    "这是一段普通正文" + TAIL, "",
]) + "\n"

# (光标行, 输出名)
SHOTS = [(11, "折行核验-光标在普通正文.png"), (3, "折行核验-光标在无序项.png"),
         (5, "折行核验-光标在任务项.png"), (7, "折行核验-光标在引用.png")]


def main() -> int:
    tmp = Path(tempfile.mkdtemp())
    real = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"
    settings = json.loads(REAL_STATE.read_text(encoding="utf-8")).get("settings", {})
    folder = tmp / "简记日记"
    folder.mkdir()
    doc = folder / "记号核验.md"
    doc.write_text(DOC, encoding="utf-8")
    (tmp / "state.json").write_text(json.dumps({
        "folder": str(folder), "default_folder": str(folder),
        "last_file": str(doc), "settings": settings,
    }, ensure_ascii=False), encoding="utf-8")

    import main as app_main  # noqa: E402

    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()
    app.open_file(doc)
    root.update()

    from capture_window import capture_widget_region  # noqa: E402

    out = PROJECT / "outputs"
    ed = app.editor

    def shoot(line: int, name: str) -> None:
        ed.mark_set("insert", f"{line}.end")
        ed.see("insert")
        app._refresh_cursor_line()
        root.update()
        path = out / name
        capture_widget_region(ed, path, factor=1)
        print(f"{name}  （光标在第 {line} 行）")

    for line, name in SHOTS:
        shoot(line, name)

    # 修复前：把 _tag_marker 换回旧行为，只截无序项那一张
    def old_tag_marker(line, start, end, cursor_line, indent):
        tag = "syntax_current" if line == cursor_line else "syntax"
        app.editor.tag_add(tag, f"{line}.{start}", f"{line}.{end}")
        app._line_marks.setdefault(line, []).append(
            ("syntax", "syntax_current", start, end, None))

    app._tag_marker = old_tag_marker
    app.editor.mark_set("insert", "11.end")
    app._apply_styles_without_dirty_flag()
    root.update()
    shoot(3, "折行核验-修复前-光标在无序项.png")

    root.destroy()
    storage.default_state_path = real
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
