"""在软件里打开「文档文件夹」中的《简记使用说明.md》，核验它确实在文稿列表里、且渲染正确。

用临时 state.json，避免改动用户真实的应用状态（不动 %LOCALAPPDATA%\\JianJi\\state.json）。
产出 outputs/说明文档-应用内-1.png ~ -4.png。
"""
from __future__ import annotations

import json
import re
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402
from capture_window import capture_hwnd  # noqa: E402

DOC_FOLDER = Path.home() / "Documents" / "wb01"


def main() -> None:
    guide = DOC_FOLDER / "简记使用说明.md"
    if not guide.is_file():
        raise SystemExit(f"找不到 {guide}")

    tmp = Path(tempfile.mkdtemp())
    real_state = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"
    (tmp / "state.json").write_text(
        json.dumps({"folder": str(DOC_FOLDER), "default_folder": str(DOC_FOLDER)},
                   ensure_ascii=False, indent=2),
        encoding="utf-8")

    from main import JianJiApp  # noqa: E402

    root = tk.Tk()
    app = JianJiApp(root)
    root.update()

    print("应用打开的文件夹：", app.folder)
    names = [p.name for p in app.file_paths]
    print(f"文稿列表共 {len(names)} 篇")
    print("说明文档在列表中：", guide.name in names)

    app.open_file(guide)
    root.update()
    app.editor.mark_set("insert", "end-1c")
    app._apply_styles_without_dirty_flag()
    root.update()
    root.update_idletasks()

    lines = re.split(r"\r\n|\r|\n", app.editor.get("1.0", "end-1c"))
    print(f"编辑器载入 {len(lines)} 行")

    def in_tag(tag: str, index: str) -> bool:
        raw = app.editor.tag_ranges(tag)
        for i in range(0, len(raw), 2):
            if (app.editor.compare(index, ">=", raw[i])
                    and app.editor.compare(index, "<", raw[i + 1])):
                return True
        return False

    print("四反引号围栏嵌套核验（第 254/259 行应为分隔线，255/258 行应为代码内容）：")
    for n in (254, 255, 258, 259, 263, 266):
        text = lines[n - 1] if n <= len(lines) else ""
        print(f"  第 {n:>3} 行 {text.strip()[:10]!r:<14} "
              f"{'分隔线（隐藏）' if in_tag('syntax', f'{n}.0') else '代码内容（显示）'}")

    out_dir = PROJECT / "outputs"
    out_dir.mkdir(parents=True, exist_ok=True)
    for index, fraction in enumerate((0.0, 0.24, 0.82, 1.0), start=1):
        app.editor.yview_moveto(fraction)
        app._apply_styles_without_dirty_flag()
        root.update()
        root.update_idletasks()
        first = app.editor.index("@0,0")
        path = out_dir / f"说明文档-应用内-{index}.png"
        w, h = capture_hwnd(int(root.winfo_toplevel().winfo_id()), path)
        print(f"  {path.name}  从第 {str(first).split('.')[0]} 行开始  {w}x{h}")

    root.destroy()
    storage.default_state_path = real_state


if __name__ == "__main__":
    main()
