"""截一张整窗图，一次看三处改动：粗体/斜体配色、排序入口、顶部留白。

用用户自己的设置（行宽 60 / 字号 18 / 行高 34）和一份包含各级标题 + 粗体 +
斜体的样例，这样「粗体像不像标题」一眼就能判。

一次性核验脚本，产出放 outputs/。
"""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402

REAL_STATE = Path.home() / "AppData/Local/JianJi/state.json"

DOC = (
    "# 一级标题：训练小结\n"
    "\n"
    "## 二级标题：动作模式\n"
    "\n"
    "### 三级标题：重量选择\n"
    "\n"
    "这一行是普通正文，用来做对照。**这一段是粗体**，和标题放在一起看。\n"
    "\n"
    "*这一段是斜体*，和粗体也要分得开。\n"
    "\n"
    "**粗体里带 *斜体* 混排**，再看一眼。\n"
    "\n"
    "1. 有序项第一条，正文里带 **粗体** 和 *斜体*。\n"
    "2. 有序项第二条。\n"
    "\n"
    "> 引用一段话，里面也有 **粗体**。\n"
    "\n"
    "| 项目 | 数量 |\n"
    "| --- | --- |\n"
    "| 苹果 | 3 |\n"
)


def main() -> int:
    tmp = Path(tempfile.mkdtemp())
    real = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"
    user = json.loads(REAL_STATE.read_text(encoding="utf-8"))
    folder = tmp / "简记日记"
    folder.mkdir()
    doc = folder / "样式核对.md"
    doc.write_text(DOC, encoding="utf-8")
    # 多造几篇，好看清排序入口和卡片列表
    for name in ("2026-09-20.md", "2026-09-18.md", "2026-09-15.md"):
        (folder / name).write_text(f"# {name}\n\n随手记一点。\n", encoding="utf-8")
    (tmp / "state.json").write_text(json.dumps({
        "folder": str(folder), "default_folder": str(folder),
        "last_file": str(doc), "settings": user["settings"],
    }, ensure_ascii=False), encoding="utf-8")

    import main as app_main  # noqa: E402

    root = tk.Tk()
    root.geometry("1500x950+60+40")
    app = app_main.JianJiApp(root)
    root.update()
    app.open_file(doc)
    root.update()
    # 光标要先摆好再上色：记号显示与否是按**光标行**定的，顺序反了截出来
    # 就是「记号没藏起来」的假象（第一次就是这么被骗的）。
    app.editor.mark_set("insert", "1.0")
    app._apply_styles_without_dirty_flag()
    root.update()
    app.editor.yview_moveto(0.0)
    root.update()

    from capture_window import capture_hwnd

    out = PROJECT / "outputs"
    shot = out / "样式与排序-整窗.png"
    capture_hwnd(root.winfo_id(), shot)
    print(f"{shot.name}")

    # 顶部留白实测：正文第一行的显示行上沿，离顶栏下沿多远。
    # 两者不在同一个父容器里，必须都换算到**屏幕**坐标再比。
    ed = app.editor
    top_bar_bottom = app.topbar.winfo_rooty() + app.topbar.winfo_height()
    box = ed.dlineinfo("1.0")
    text_top = ed.winfo_rooty() + box[1]
    print(f"顶栏下沿 {top_bar_bottom}  正文第一行上沿 {text_top}  "
          f"（差 {text_top - top_bar_bottom} 像素）")
    print(f"编辑器 pady={ed.cget('pady')!r}  第一行显示行高 {box[3]}")

    # 配色核对
    print()
    for tag in ("h1", "h2", "h3", "bold", "italic"):
        print(f"   {tag:8s} {ed.tag_cget(tag, 'foreground')}")

    root.destroy()
    storage.default_state_path = real
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
