"""查 `test_wheel_scrolls_exactly_the_configured_factor` 为什么会量出 5.775 倍。

那条测试用 `|Δyview[0]| × count("1.0","end-1c","ypixels")` 反推滚了多少像素。
这个式子的前提是「`yview` 的分数分母 == `count(...,"end-1c","ypixels")`」。
底部留白（`bottom_pad` 的 `spacing3`）是**加在滚动区里**的，所以这个前提可能不成立了。

这里换一种**不依赖分数**的量法：找一条「滚动前后都可见」的行，
用它的 `dlineinfo` 直接量 y 位移——这才是真正滚了多少像素。

    python tools/quiet_desktop.py <python> tools/_probe_wheel_measure.py
"""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402

LONG = "\n".join(
    [f"## 第 {i} 节" for i in range(1, 200)]
    + [f"这是第 {i} 节的正文，用来把文档撑长一点，好让滚动有空间。"
       for i in range(1, 200)]
)


def _count(editor, *args) -> int:
    """`count` 在某些 Tk 版本返回单元素元组，取出来。"""
    raw = editor.count(*args)
    if isinstance(raw, (tuple, list)):
        raw = raw[0]
    return int(raw)


def main() -> int:
    tmp = Path(tempfile.mkdtemp())
    real = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"
    folder = tmp / "简记日记"
    folder.mkdir()
    doc = folder / "长文.md"
    doc.write_text(LONG, encoding="utf-8")
    storage.set_default_folder(folder)

    import main as app_main  # noqa: E402
    # 开关：把底部留白关掉，看分母的不稳定是不是它带来的
    import os
    if os.environ.get("NO_PAD"):
        app_main.EDITOR_BOTTOM_PAD_RATIO = 0.0

    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()
    app.open_file(doc)
    root.update()

    ed = app.editor
    print(f"视口高           {ed.winfo_height()}")
    print(f"_bottom_pad      {app._bottom_pad}  （最后一行 {app._bottom_pad_line}）")
    print(f"count end-1c     {_count(ed, '1.0', 'end-1c', 'ypixels')}  ← 测试用的分母")
    print(f"count end        {_count(ed, '1.0', 'end', 'ypixels')}")
    print(f"bottom_pad 标签  {ed.tag_ranges('bottom_pad')}")

    def y_of_a_visible_line():
        """返回 {行号: y}，供前后取交集量位移。"""
        out = {}
        for line in range(1, 400):
            info = ed.dlineinfo(f"{line}.0")
            if info is not None:
                out[line] = info[1]
        return out

    for delta in (-120, 120, -240):
        rows = []
        for bound in (False, True):
            if bound:
                ed.bind("<MouseWheel>", app._on_editor_wheel)
            else:
                ed.unbind("<MouseWheel>")
            root.update()
            ed.yview_moveto(0.0 if delta < 0 else 1.0)
            root.update()
            before_frac = ed.yview()[0]
            before_rows = y_of_a_visible_line()
            raw_before = _count(ed, "1.0", "end-1c", "ypixels")
            ed.event_generate("<MouseWheel>", delta=delta)
            root.update()
            after_frac = ed.yview()[0]
            after_rows = y_of_a_visible_line()
            raw_after = _count(ed, "1.0", "end-1c", "ypixels")

            shared = sorted(set(before_rows) & set(after_rows))
            true_px = (max(abs(before_rows[k] - after_rows[k]) for k in shared)
                       if shared else None)
            frac_px = round(abs(after_frac - before_frac) * raw_before)
            rows.append((bound, before_frac, after_frac, raw_before, raw_after,
                         frac_px, true_px, len(shared)))
        ed.bind("<MouseWheel>", app._on_editor_wheel)

        print(f"\n--- delta={delta} ---")
        for bound, bf, af, rb, ra, frac_px, true_px, shared in rows:
            tag = "ours" if bound else "native"
            print(f"  {tag:<7} yview {bf:.6f} → {af:.6f}   Δfrac {af - bf:+.6f}")
            print(f"          分母 {rb}（滚后 {ra}）  分数反推 {frac_px} px"
                  f"  真实位移 {true_px} px（共 {shared} 行可比）")
        native_true = rows[0][6]
        ours_true = rows[1][6]
        if native_true and ours_true:
            print(f"  真实倍数 {ours_true / native_true:.3f}"
                  f"   （分数反推 {rows[1][5] / rows[0][5]:.3f}）")

    root.destroy()
    storage.default_state_path = real
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
