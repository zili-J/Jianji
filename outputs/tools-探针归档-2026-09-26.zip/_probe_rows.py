"""看看 `build_export_rows` 到底把文稿切成了什么「行」，以及每行折成几个显示行。

用户报「行宽很窄 → 逗号后面异常换行」。要判断是不是「折行太早」，
先得知道有多少显示行是折出来的（`wrap=True`），以及逻辑行的长度分布。

    python tools/quiet_desktop.py <python 全路径> tools/_probe_rows.py [文稿路径]
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from collections import Counter
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))

import image_export as ie  # noqa: E402
import main as app_main  # noqa: E402
import storage  # noqa: E402
import tkinter as tk  # noqa: E402

REAL_STATE = Path(os.environ.get("LOCALAPPDATA", "")) / "JianJi" / "state.json"
DOC = Path(sys.argv[1]) if len(sys.argv) > 1 else \
    Path(r"C:\Users\22910\Documents\wb01\说明书\简记使用说明.md")


def row_text(row) -> str:
    if row.kind == "table":
        return " | ".join("".join(p.text for p in cell) for line in row.cells for cell in line)
    return "".join(p.text for p in row.pieces)


def main() -> int:
    tmp = Path(tempfile.mkdtemp())
    saved = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"
    settings = json.loads(REAL_STATE.read_text(encoding="utf-8")).get("settings", {})
    folder = tmp / "d"
    folder.mkdir()
    (tmp / "state.json").write_text(json.dumps({
        "folder": str(folder), "default_folder": str(folder),
        "last_file": "", "settings": settings}, ensure_ascii=False), encoding="utf-8")

    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()
    options = app._export_options()
    fonts = ie._Fonts()
    try:
        source = DOC.read_text(encoding="utf-8-sig")
        rows = app_main.build_export_rows(source, options)
        lines = ie.build_layout(rows, options, app_main.export_palette(), fonts)
        print(f"{DOC.name}: 源 {len(app_main.split_document_lines(source))} 行 → "
              f"{len(rows)} 逻辑行 → {len(lines)} 显示行")
        print(f"逻辑行类型：{dict(Counter(row.kind for row in rows))}")

        # 每个逻辑行折成几个显示行
        per_row: dict[int, int] = {}
        for line in lines:
            per_row[id(line.row)] = per_row.get(id(line.row), 0) + 1
        print(f"每逻辑行的显示行数：{dict(sorted(Counter(per_row.values()).items()))}")

        # 正文类逻辑行的字符数分布（正文/列表/引用才该折行）
        body_kinds = {"text", "bullet", "task", "ordered", "quote", "heading"}
        lengths = [len(row_text(row)) for row in rows if row.kind in body_kinds]
        if lengths:
            lengths.sort()
            print(f"正文类逻辑行 {len(lengths)} 个，字符数："
                  f"最小 {lengths[0]} 中位 {lengths[len(lengths) // 2]} 最大 {lengths[-1]}")
            print("  长度分布（每 10 字一档）："
                  f"{dict(sorted(Counter(n // 10 * 10 for n in lengths).items()))}")

        # 折成 1 个显示行、但字符数超过 29 的正文行 —— 说明它没被折（不该发生）
        suspicious = []
        for row in rows:
            if row.kind not in body_kinds:
                continue
            count = per_row.get(id(row), 0)
            text = row_text(row)
            if count <= 1 and len(text) > 29:
                suspicious.append((len(text), row.kind, text[:40]))
        print(f"字符数 > 29 却只有 1 个显示行的正文行：{len(suspicious)} 个")
        for length, kind, text in sorted(suspicious, reverse=True)[:10]:
            print(f"    {length:>4} 字 {kind:<8} [{text}]")
    finally:
        fonts.close()
        root.destroy()
        storage.default_state_path = saved
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
