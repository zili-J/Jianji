"""直接量「行首记号露出来」这件事对排版几何的影响，不做任何推断。

用来定位两个问题：
1. `syntax_marker` 的 `lmargin1` 补偿到底有没有生效（正文首字符的 x 变不变）；
2. `index("L.0 + 1 display lines")` 在记号可见/隐藏时返回的是不是同一套语义。

    python tools/quiet_desktop.py python.exe tools/_probe_marker_geom.py
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402

REAL_STATE = Path.home() / "AppData/Local/JianJi/state.json"

BODY = "列表项正文要够长才会折行，这里故意写得长一些用来观察折行位置。"
CASES = [("- " + BODY, "无序 0 级"), ("  - " + BODY, "无序 1 级"),
         ("- [ ] " + BODY, "任务未勾"), ("1. " + BODY, "有序"),
         ("> " + BODY, "引用"), (BODY, "普通正文")]


def main() -> int:
    tmp = Path(tempfile.mkdtemp())
    real_state_path = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"

    settings = {}
    if REAL_STATE.is_file():
        settings = json.loads(REAL_STATE.read_text(encoding="utf-8")).get("settings", {})
    folder = tmp / "简记日记"
    folder.mkdir()
    doc = folder / "记号几何.md"
    lines = ["# 记号几何", ""]
    for source, _label in CASES:
        lines.append(source)
        lines.append("")
    doc.write_text("\n".join(lines) + "\n", encoding="utf-8")
    (tmp / "state.json").write_text(json.dumps({
        "folder": str(folder), "default_folder": str(folder),
        "last_file": str(doc), "settings": settings,
    }, ensure_ascii=False), encoding="utf-8")

    import main as app_main

    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()
    if os.environ.get("JIANJI_NO_COMPENSATE"):
        app._body_text_width = lambda _text: 0
        print("**缩进补偿已关闭（旧行为）**")
    app.open_file(doc)
    root.update()

    editor = app.editor
    total = int(editor.index("end-1c").split(".")[0])
    print(f"设置 {app.settings}")
    print(f"留白 {app._current_pad}  px(LIST_INDENT)={app_main.px(app_main.LIST_INDENT)}\n")

    def snapshot(line: int) -> dict:
        editor.tk.call(editor, "count", "-update", "1.0", "end")
        source = editor.get(f"{line}.0", f"{line}.end")
        marker = app_main.parse_block(source).marker or (0, 0)
        body = marker[1]
        out = {
            "marks": app._line_marks.get(line),
            "marker": marker,
            "tags@0": editor.tag_names(f"{line}.0"),
            "tags@body": editor.tag_names(f"{line}.{body}"),
            "cfg_marker": editor.tag_configure("syntax_marker"),
            "dline": editor.dlineinfo(f"{line}.0"),
            "bbox0": editor.bbox(f"{line}.0"),
            "bbox1": editor.bbox(f"{line}.1"),
            "bboxBody": editor.bbox(f"{line}.{body}"),
            "bboxEnd": editor.bbox(f"{line}.{len(source)}"),
            "plus1display": str(editor.index(f"{line}.0 + 1 display lines")),
            "plus1line": str(editor.index(f"{line}.0 + 1 lines")),
            "ndisplay": int(editor.tk.call(editor, "count", "-displaylines",
                                           f"{line}.0", f"{line}.end") or 0),
            "len": len(source),
            "rng_marker": [str(x) for x in editor.tag_ranges("syntax_marker")],
            "rng_current": [str(x) for x in editor.tag_ranges("syntax_current")],
        }
        return out

    def move_cursor(target: str) -> None:
        editor.mark_set("insert", target)
        editor.see("insert")
        app._refresh_cursor_line()
        root.update()

    for index, (source, label) in enumerate(CASES):
        line = 3 + index * 2
        print("=" * 78)
        print(f"{label}  第 {line} 行  {source[:14]}…")
        for state in ("光标在别处", "光标在本行"):
            move_cursor(f"{total}.0" if state == "光标在别处" else f"{line}.end")
            snap = snapshot(line)
            print(f"  [{state}] insert={editor.index('insert')}")
            print(f"    marks      = {snap['marks']}")
            print(f"    cfg_marker = lmargin1={snap['cfg_marker'].get('lmargin1')} "
                  f"lmargin2={snap['cfg_marker'].get('lmargin2')}")
            print(f"    tags@0     = {snap['tags@0']}")
            print(f"    dline      = {snap['dline']}")
            print(f"    bbox 0/1/body/end = {snap['bbox0']} {snap['bbox1']} "
                  f"{snap['bboxBody']} {snap['bboxEnd']}")
            print(f"    +1 display lines -> {snap['plus1display']}   "
                  f"+1 lines -> {snap['plus1line']}   显示行数={snap['ndisplay']} "
                  f"字符数={snap['len']}")
            print(f"    rng_marker={snap['rng_marker']} rng_current={snap['rng_current']}")
    root.destroy()
    storage.default_state_path = real_state_path
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
