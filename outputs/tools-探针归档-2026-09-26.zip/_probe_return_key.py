"""深挖「回车续号」：光标框、滚动位置、左侧序号画布到底画了什么。

用法：python tools/_probe_return_key.py
产出：outputs/回车按键探针.txt
必须在前台桌面跑（隐藏桌面上按键事件投递不到）。
"""
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))

import storage                                    # noqa: E402

DOC = "".join(f"{i}. 第{i}条\n" for i in range(1, 6))


def decorations(app) -> list[str]:
    """左侧装饰画布里都画了什么（位置 + 文字/图形）。"""
    found = []
    for index, canvas in enumerate(app._decor_pool):
        if not canvas.winfo_ismapped():
            continue
        info = canvas.place_info()
        items = []
        for item in canvas.find_all():
            kind = canvas.type(item)
            if kind == "text":
                items.append(repr(canvas.itemcget(item, "text")))
            else:
                items.append(kind)
        if items:
            found.append(f"    画布{index} x={info.get('x')} y={info.get('y')} "
                         f"w={info.get('width')} h={info.get('height')} {items}")
    return found or ["    （没有可见装饰）"]


def dump(app, title: str, out: list[str]) -> None:
    editor = app.editor
    out.append(f"--- {title} ---")
    out.append(f"文本: {editor.get('1.0', 'end-1c')!r}")
    out.append(f"insert = {editor.index('insert')}   _cursor_line = {app._cursor_line}")
    out.append(f"光标框 bbox('insert') = {editor.bbox('insert')}")
    box = editor.bbox("insert")
    if box:
        ox = editor.winfo_rootx() - app.root.winfo_rootx()
        oy = editor.winfo_rooty() - app.root.winfo_rooty()
        out.append(f"  换算到窗口坐标：光标 x={ox + box[0]} y={oy + box[1]}"
                   f"（截图坐标 ×1.5 ≈ {int((ox + box[0]) * 1.5)}, {int((oy + box[1]) * 1.5)}）")
    out.append(f"编辑区高 = {editor.winfo_height()}   可见行 = {len(app._visible_lines())}")
    out.append(f"yview = {editor.yview()}")
    out.append("  左侧序号画布：")
    out.extend(decorations(app))
    out.append("")


def main() -> None:
    tmp = Path(tempfile.mkdtemp())
    storage.default_state_path = lambda: tmp / "state.json"
    folder = tmp / "简记日记"
    folder.mkdir()
    doc = folder / "续号.md"
    doc.write_text(DOC, encoding="utf-8")
    storage.set_default_folder(folder)

    import tkinter as tk

    from main import JianJiApp

    root = tk.Tk()
    root.geometry("1000x600")
    app = JianJiApp(root)
    root.update()
    app.open_file(doc)
    root.update()

    out: list[str] = []
    dump(app, "打开后", out)

    app.editor.mark_set("insert", "1.end")
    app._refresh_cursor_line()
    root.update()
    dump(app, "光标在 1.end", out)

    app.editor.focus_force()
    root.update()
    app.editor.event_generate("<Return>", when="now")
    root.update()
    dump(app, "按了 <Return> 之后", out)

    (PROJECT / "outputs").mkdir(exist_ok=True)
    (PROJECT / "outputs" / "回车按键探针.txt").write_text("\n".join(out), encoding="utf-8")
    print("\n".join(out))

    # 截图，看光标到底露不露得出来（DPI 1.5 → 窗口坐标 × 1.5 = 图像坐标）
    sys.path.insert(0, str(PROJECT / "tools"))
    from capture_window import capture_hwnd
    out_dir = PROJECT / "outputs"
    width, height = capture_hwnd(int(root.winfo_id()), out_dir / "回车按键探针.png")
    print(f"写出 outputs/回车按键探针.png {width}×{height}")

    # 对照：把左侧装饰画布全藏起来再抓一张。光标如果这时才出现，
    # 就说明是「不透明的小画布盖住了光标」。
    app._hide_decorations(0)
    root.update()
    width, height = capture_hwnd(int(root.winfo_id()), out_dir / "回车按键探针-无装饰.png")
    print(f"写出 outputs/回车按键探针-无装饰.png {width}×{height}")

    root.destroy()


if __name__ == "__main__":
    main()
