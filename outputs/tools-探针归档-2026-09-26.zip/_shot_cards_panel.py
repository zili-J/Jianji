"""截整窗，核验「预览栏宽度恢复 + 预览栏滚动条已隐藏」。

用户反馈：排序入口原来挂在文稿列表标题右侧，把卡片区挤窄了一截（Tk 的 grid
是「一列宽 = 该列所有行里最宽的那个」，标题行多一列，下面卡片区就少一块）；
滚动条又从右边切走一条。两处都改掉之后卡片区应当拿到面板的整幅宽度。

脚本顺手把三栏宽度打出来，图和数据一起看。产出放 outputs/。

一次性核验脚本，同类见 _shot_style_and_sort.py。
"""
from __future__ import annotations

import sys
import tempfile
import time
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402
from capture_window import capture_widget_region  # noqa: E402

TITLES = ("训练计划", "读书笔记", "会议要点", "随手记", "本周复盘", "菜谱")


def main() -> int:
    tmp = Path(tempfile.mkdtemp())
    real = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"

    folder = tmp / "简记日记"
    folder.mkdir()
    for index, title in enumerate(TITLES):
        (folder / f"{index:02d}-{title}.md").write_text(
            f"# {title}\n\n"
            "这一篇的摘录用来占几行，好让卡片看起来是正常的样子，"
            "也顺便看看宽度变了之后一行能放多少字。\n",
            encoding="utf-8",
        )
    storage.set_default_folder(folder)

    import main as app_main  # noqa: E402

    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()
    app.open_file(folder / f"00-{TITLES[0]}.md")
    root.update()

    panel = app.cards_panel.winfo_width()
    canvas = app.cards_canvas.winfo_width()
    holder = app.cards_canvas.master
    mapped_scrollbars = [w for w in holder.winfo_children()
                         if isinstance(w, tk.Scrollbar) and w.winfo_manager()]
    print(f"预览栏面板     {panel}")
    print(f"卡片区宽度     {canvas}   （占面板 {canvas / panel:.0%}）")
    print(f"编辑器画布     {app.editor.winfo_width()}")
    print(f"预览栏滚动条   {mapped_scrollbars or '已隐藏'}")
    print(f"标题行控件     "
          f"{[type(w).__name__ for w in app.cards_panel.winfo_children() if w.winfo_manager() and w.grid_info().get('row') == 0]}")

    root.deiconify()
    root.lift()
    root.attributes("-topmost", True)
    for _ in range(50):
        root.update()
        if root.winfo_viewable() and root.winfo_width() > 100:
            break
        time.sleep(0.02)
    root.update()
    time.sleep(0.35)

    out = PROJECT / "outputs" / "预览栏宽度与滚动条.png"
    width, height = capture_widget_region(root, out, factor=1)
    print(f"已截图 {out.name} {width}x{height}")

    root.destroy()
    storage.default_state_path = real
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
