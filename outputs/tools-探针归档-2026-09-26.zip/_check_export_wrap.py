"""核验「导出长图随机增加换行」：用**用户真实设置**把真文稿排一遍，A/B 对照。

为什么单独有这个脚本：`tools/_probe_export_wrap.py` 走的是 `image_export.Options()`
的默认参数，而导出参数在适配层里是由编辑区设置换算出来的
（`main._export_options()`，`line_height` 会随字号缩放）。折行只取决于**正文列宽**
与正文字号，但既然用户的设置本来就能读到，就别用默认值去猜——这个脚本把用户
`state.json` 里的 `settings` 原样写进临时文件再构造 `JianJiApp`。

判据（**都不含绝对像素**，全部相对可用宽度）：
- 段落内部不能出现空显示行（空行只该来自文稿里真的空了一行）
- 续行不能以断点那个空格开头
- 填充率的下限与中位
- 显示行总数、渲染总高度（修好之后应该变少、变矮）

A/B 的做法是把 `image_export._break_index` 临时换回旧实现（一路退到「上一个空格」），
同一份文稿再排一遍，直接看差多少行、差多少像素。

    python tools/quiet_desktop.py tools/_check_export_wrap.py [文稿...]
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))

import image_export as ie  # noqa: E402
import main as app_main  # noqa: E402
import storage  # noqa: E402
import tkinter as tk  # noqa: E402

REAL_STATE = Path(os.environ.get("LOCALAPPDATA", "")) / "JianJi" / "state.json"

DEFAULT_DOCS = [
    Path(r"C:\Users\22910\Documents\wb01\说明书\project.md"),
    Path(r"C:\Users\22910\Documents\wb01\说明书\简记使用说明.md"),
]


def old_break_index(text: str, start: int, index: int) -> int:
    """上一版：一路退到「上一个空格」，退不到就返回 start（= 按字断）。"""
    for position in range(index - 1, start, -1):
        char = text[position]
        if char.isspace() and not ie._is_wide(char):
            return position + 1
    return start


def indent_of(row, options: ie.Options) -> int:
    if row.kind in ("bullet", "task", "ordered"):
        return options.list_left(row.level)
    if row.kind == "quote":
        return options.margin + options.list_indent
    return options.margin


def measure(rows, options: ie.Options, fonts: ie._Fonts) -> dict:
    lines = ie.build_layout(rows, options, app_main.export_palette(), fonts)
    groups: list[list] = []
    for line in lines:
        if groups and groups[-1][0].row is line.row:
            groups[-1].append(line)
        else:
            groups.append([line])

    blanks: list[str] = []
    leading_space: list[str] = []
    fill: list[float] = []

    # 这些块本来就没有文字片段（分隔线是一条横线、表格文字在 `line.table` 里、
    # 空行本来就是空的），不能算成「凭空多出来的空行」。
    no_text = ("blank", "hr", "table", "image")

    for group in groups:
        row = group[0].row
        row_text = "".join(p.text for p in row.pieces)
        # 判据：**本来有文字的块，折行后不能出现空显示行**。
        # 整块就没文字（空引用行 `>`、分隔线、表格）不算——它们空着是对的。
        if row.kind in no_text or not row_text.strip():
            continue
        for number, line in enumerate(group):
            content = "".join(p.text for p in line.pieces)
            if not content.strip():
                blanks.append(f"{row.kind} 第 {number + 1} 显示行"
                              f"（本块内容 {row_text[:24]!r}）")
            if number and content.startswith(" "):
                leading_space.append(f"{row.kind}：{content[:20]!r}")
        if row.kind == "table" or len(group) < 2:
            continue
        available = max(40, options.margin + options.content_width
                        - indent_of(row, options))
        for line in group[:-1]:
            fill.append(ie._measure(line.pieces, fonts) / available)

    height = lines[-1].top + lines[-1].height if lines else 0
    fill.sort()
    return {
        "lines": len(lines),
        "height": height,
        "blanks": blanks,
        "leading_space": leading_space,
        "fill_min": fill[0] if fill else 1.0,
        "fill_mid": fill[len(fill) // 2] if fill else 1.0,
        "fill_low": sum(1 for value in fill if value < 0.9),
        "fill_count": len(fill),
    }


def report(tag: str, rows, options: ie.Options, fonts: ie._Fonts) -> dict:
    data = measure(rows, options, fonts)
    print(f"  {tag}：显示行 {data['lines']}  总高 {data['height']} px  "
          f"段内空行 {len(data['blanks'])}  续行以空格开头 {len(data['leading_space'])}  "
          f"填充率 最低 {data['fill_min']:.1%} / 中位 {data['fill_mid']:.1%}  "
          f"<90% 的续行 {data['fill_low']}/{data['fill_count']}")
    for item in data["blanks"][:5]:
        print(f"      ✗ 空行：{item}")
    for item in data["leading_space"][:5]:
        print(f"      ✗ 行首空格：{item}")
    return data


def main() -> int:
    tmp = Path(tempfile.mkdtemp())
    real_state_path = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"

    if not REAL_STATE.is_file():
        print(f"找不到用户设置 {REAL_STATE}")
        return 1
    user = json.loads(REAL_STATE.read_text(encoding="utf-8"))
    settings = user.get("settings", {})

    folder = tmp / "简记日记"
    folder.mkdir()
    (tmp / "state.json").write_text(json.dumps({
        "folder": str(folder),
        "default_folder": str(folder),
        "last_file": "",
        "settings": settings,
    }, ensure_ascii=False), encoding="utf-8")

    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()

    options = app._export_options()
    fonts = ie._Fonts()
    docs = [Path(p) for p in sys.argv[1:]] or DEFAULT_DOCS
    docs = [d for d in docs if d.is_file()]
    print(f"用户设置 {settings}")
    print(f"导出参数 宽 {options.width}  边距 {options.margin}  "
          f"正文列宽 {options.content_width}  正文字号 {options.body_size}  "
          f"行高 {options.line_height}  字体 {options.family}\n")

    good = True
    try:
        for doc in docs:
            text = doc.read_text(encoding="utf-8-sig")
            rows = app_main.build_export_rows(text, options)
            print(f"=== {doc.name} ===")
            new = report("修好之后", rows, options, fonts)

            ie._break_index, saved = old_break_index, ie._break_index
            try:
                old = report("上一版  ", rows, options, fonts)
            finally:
                ie._break_index = saved

            print(f"  差值：显示行 {old['lines'] - new['lines']:+d}  "
                  f"总高 {old['height'] - new['height']:+d} px  "
                  f"段内空行 {len(old['blanks']) - len(new['blanks']):+d}\n")
            good = good and not new["blanks"] and not new["leading_space"]
    finally:
        fonts.close()
        root.destroy()
        storage.default_state_path = real_state_path

    print("段落内没有空显示行、续行也不以空格开头" if good else "**仍有问题**")
    return 0 if good else 1


if __name__ == "__main__":
    raise SystemExit(main())
