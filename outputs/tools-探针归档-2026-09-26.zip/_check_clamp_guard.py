"""临时核验：把夹原点的修复关掉，新增的测试应当失败（证明测试抓得住这个 bug）。"""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tests"))

import main  # noqa: E402
import test_cards  # noqa: E402

main.JianJiApp._clamp_cards_scroll = lambda self: None   # 还原成修复前的行为

suite = unittest.TestLoader().loadTestsFromTestCase(test_cards.CardScrollBoundsTests)
result = unittest.TextTestRunner(verbosity=2).run(suite)
print(f"\n关掉修复后：跑了 {result.testsRun} 项，失败 {len(result.failures)}，错误 {len(result.errors)}")
sys.exit(0 if result.failures or result.errors else 1)
