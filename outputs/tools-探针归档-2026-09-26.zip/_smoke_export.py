"""长图渲染的冒烟脚本：不依赖 Tk，直接把构造好的 Row 渲染成 PNG。

用法：python tools/_smoke_export.py
产出：outputs/_smoke_long.png
"""
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "app"))

from image_export import Options, Palette, Piece, Row, render   # noqa: E402

opt = Options()
pal = Palette()
FAM, MONO = "Microsoft YaHei UI", "Consolas"
B, M = opt.body_size, 22


def p(text, **kw):
    kw.setdefault("family", FAM)
    kw.setdefault("size", B)
    return Piece(text, **kw)


def head(level, text, color):
    return Row(kind="heading", level=level, badge=f"H{level}",
               pieces=[p(text, bold=True, color=color)])


def cell(text, **kw):
    kw.setdefault("bold", False)
    return [p(text, **kw)]


rows = [
    head(1, "今天的记录", "#1F3864"),
    Row(kind="blank"),
    Row(kind="text", pieces=[
        p("正文里可以有 "), p("加粗", bold=True, color="#31688E"),
        p("、"), p("斜体", italic=True, color="#4A6B8A"),
        p("、"), p("删除线", strike=True, color="#A8A29A"),
        p("、"), p("高亮", background="#FFF3C4", color="#8A6412"),
        p("、"), p("行内代码", family=MONO, size=M, background="#F1F0EC", color="#B5396B"),
        p("、"), p("链接", color="#2F6BD8", underline=True),
        p("，以及 a very long english sentence that must wrap at spaces correctly."),
    ]),
    head(2, "列表", "#2C5282"),
    Row(kind="bullet", level=0,
        pieces=[p("第一层，一个比较长的条目，用来验证中文折行是否落在正确的位置上，再补一些字让它折行。")]),
    Row(kind="bullet", level=1, pieces=[p("第二层（空心圆）")]),
    Row(kind="bullet", level=2, pieces=[p("第三层（方块）")]),
    Row(kind="ordered", level=0, number="1.", pieces=[p("有序列表第一项")]),
    Row(kind="task", level=0, checked=True, pieces=[p("已完成")]),
    Row(kind="task", level=0, checked=False, pieces=[p("未完成")]),
    head(3, "引用与代码", "#31688E"),
    Row(kind="quote", pieces=[p("引用的一段话，前面会有一条竖条。", color="#54657A")]),
    Row(kind="code", pieces=[p("def hello():", family=MONO, size=M, color="#3F4A56")]),
    Row(kind="code", pieces=[p('    print("你好")', family=MONO, size=M, color="#3F4A56")]),
    Row(kind="hr"),
    head(4, "表格", "#3D7A87"),
    Row(kind="table", alignments=["none", "center", "right"], table_id=0, cells=[
        [cell("项目", bold=True, color="#1F3864"),
         cell("状态", bold=True, color="#1F3864"),
         cell("数量", bold=True, color="#1F3864")],
        [cell("写代码"), cell("完成"), cell("12")],
        [cell("写文档"), cell("进行中"), cell("3")],
        [cell("很长很长的一个单元格，需要折行显示"), cell("待办"), cell("1")],
    ]),
    Row(kind="blank"),
    Row(kind="text", pieces=[p("结束。")]),
]

start = time.perf_counter()
images = render(rows, opt, pal)
elapsed = (time.perf_counter() - start) * 1000

out = ROOT / "outputs" / "_smoke_long.png"
out.parent.mkdir(exist_ok=True)
out.write_bytes(images[0])
print(f"张数 {len(images)}  字节 {[len(b) for b in images]}  耗时 {elapsed:.0f} ms")
print(f"写出 {out}")

# 顺手报告一下图片实际尺寸（PNG 的 IHDR 里就有）
import struct   # noqa: E402
w, h = struct.unpack(">II", images[0][16:24])
print(f"尺寸 {w}×{h}")
