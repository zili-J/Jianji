"""量清 Tk 的 `spacing3` 到底对**什么样的标签区间**生效。

背景：底部留白靠一个只挂在最后一行的 `spacing3` 标签。它不是「挂在行上就生效」，
标签区间一变就可能静默失效（用户报的「编辑区的空白在回车后闪回」）。
这里把「末行内容 × 标签区间」摆成一个矩阵，逐个量内容总高的增量，
把规则定出来，判据才不用猜。

    python tools/quiet_desktop.py python.exe tools/_probe_pad_rule.py
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402

REAL_STATE = Path.home() / "AppData/Local/JianJi/state.json"
PARAGRAPH = "\n".join(f"第 {i} 段正文，用来把文稿撑长一点，好让它超过一屏。"
                      for i in range(1, 60))
PAD = 267


def main() -> int:
    tmp = Path(tempfile.mkdtemp())
    saved = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"

    settings = {}
    if REAL_STATE.is_file():
        settings = json.loads(REAL_STATE.read_text(encoding="utf-8")).get("settings", {})
    folder = tmp / "简记日记"
    folder.mkdir()
    doc = folder / "规则.md"
    (tmp / "state.json").write_text(json.dumps({
        "folder": str(folder), "default_folder": str(folder),
        "last_file": str(doc), "settings": settings,
    }, ensure_ascii=False), encoding="utf-8")

    import main as app_main

    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()
    editor = app.editor
    editor.tag_configure("probe_pad", spacing3=PAD)

    def total() -> int:
        editor.tk.call(editor, "count", "-update", "1.0", "end")
        return int(editor.count("1.0", "end", "ypixels")[0])

    def measure(content: str, start: str, stop: str, tag: int) -> tuple[int, str]:
        # 每个用例换一个**新文件名**：`open_file` 对同一个路径会短路，正文根本不会换。
        path = folder / f"规则-{tag:02d}.md"
        path.write_text(PARAGRAPH + "\n" + content + "\n", encoding="utf-8")
        app.open_file(path)
        root.update()
        editor.yview_moveto(1.0)
        root.update()
        editor.tag_remove("probe_pad", "1.0", "end")
        baseline = total()
        editor.tag_add("probe_pad", start, stop)
        with_tag = total()
        ranges = editor.tag_ranges("probe_pad")
        spans = "..".join(str(x) for x in ranges) if len(ranges) == 2 else "（无）"
        tail = repr(editor.get("end-3l", "end-1c"))
        return with_tag - baseline, f"{spans}   末行 end-1c={editor.index('end-1c')} 尾={tail}"

    cases = [
        ("（空行）", "end-1c", "end"),
        ("（空行）", "end-1c linestart", "end-1c lineend"),
        ("（空行）", "end-1c", "end-1c"),
        ("字", "end-1c linestart", "end-1c lineend"),
        ("字", "end-1c", "end"),
        ("字", "end-1c linestart", "end"),
        ("字", "end-1c linestart", "end-1c linestart"),
        ("字字", "end-1c linestart", "end-1c lineend"),
        ("字字", "end-1c linestart", "end-1c -1c"),
        ("字字", "end-1c -1c", "end"),
        ("字字字字字", "end-1c linestart", "end-1c lineend"),
        ("字字字字字", "end-1c linestart", "end-1c linestart +1c"),
    ]

    print(f"留白值 spacing3 = {PAD}（量的是内容总高的增量，等于 PAD 才算生效）\n")
    print(f"{'末行内容':<12}{'标签区间':<40}{'增量':>6}  生效")
    for tag, (content, start, stop) in enumerate(cases):
        delta, spans = measure(content, start, stop, tag)
        print(f"{content:<12}{f'{start} → {stop}':<40}{delta:>6}  "
              f"{'是' if abs(delta - PAD) < 8 else '否'}")
        print(f"{'':12}{spans}")

    root.destroy()
    storage.default_state_path = saved
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
