"""把「长文滚到底」的样子截下来，用眼睛看一遍。

用法：python tools/_shot_bottom.py
产出：outputs/滚到底-全窗.png、outputs/滚到底-下半.png

几何量不出来、但肉眼一眼能看出的东西（比如留白其实在别的控件上）只能靠截图。
窗口 DC 抓图在隐藏桌面上也能用（屏幕 DC 会全黑）。
"""
import json
import os
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import storage                                     # noqa: E402
from capture_window import capture_hwnd            # noqa: E402

BODY = "\n".join(f"第 {i} 段正文，用来把文稿撑长一点，好让它超过一屏。"
                 for i in range(1, 80))


def real_settings() -> dict:
    path = Path(os.environ.get("LOCALAPPDATA", "")) / "JianJi" / "state.json"
    try:
        return json.loads(path.read_text(encoding="utf-8")).get("settings", {})
    except (OSError, ValueError):
        return {}


def main() -> None:
    tmp = Path(tempfile.mkdtemp())
    state_path = tmp / "state.json"
    state_path.write_text(json.dumps({"settings": real_settings()}, ensure_ascii=False),
                          encoding="utf-8")
    storage.default_state_path = lambda: state_path
    folder = tmp / "简记日记"
    folder.mkdir()
    for i in range(12):
        (folder / f"文稿-{i:03d}.md").write_text(
            f"# 文稿 {i}\n\n" + "正文内容。\n" * 3, encoding="utf-8")
    doc = folder / "长文.md"
    doc.write_text("# 长文\n\n" + BODY + "\n最后一句正文。\n", encoding="utf-8")
    storage.set_default_folder(folder)

    import tkinter as tk

    from main import JianJiApp

    root = tk.Tk()
    root.geometry("1240x820")
    app = JianJiApp(root)
    root.update()
    app.open_file(doc)
    root.update()
    # 先让 Tk 把「底部留白」带来的高度变化算完，再滚——否则 moveto(1.0)
    # 是按**旧**总高算的比例，布局一更新就落不到底。
    # 多转几圈：Tk 只为视口附近的行排版，`yview()` 的分母是逐步收敛的
    # （`count ... ypixels` 实测 13938 → … → 27627），一圈不够。
    for _ in range(3):
        root.update_idletasks()
        root.update()
    app.editor.yview_moveto(1.0)
    for _ in range(3):
        root.update_idletasks()
        root.update()

    out_dir = PROJECT / "outputs"
    out_dir.mkdir(exist_ok=True)
    hwnd = int(root.winfo_id())
    try:
        width, height = capture_hwnd(hwnd, out_dir / "滚到底-全窗.png")
        print(f"全窗 {width}×{height}")
    except OSError as error:
        print("抓图失败:", error)
        root.destroy()
        return

    editor = app.editor
    print(f"编辑器在窗口里的位置 = x {editor.winfo_rootx() - root.winfo_rootx()}, "
          f"y {editor.winfo_rooty() - root.winfo_rooty()}, "
          f"{editor.winfo_width()}×{editor.winfo_height()}")
    print(f"窗口 = {root.winfo_width()}×{root.winfo_height()}")
    box = editor.bbox("end-1c")
    viewport = editor.winfo_height()
    print(f"末行 bbox = {box}   视口高 = {viewport}")
    if box:
        blank = viewport - (box[1] + box[3])
        print(f"末行下方留白 = {blank} px = {blank / viewport:.1%}"
              f"   （目标 {app_main_ratio():.0%}）")
    # `yview()` 只作参考：它取决于 Tk 有没有把整篇版面都算完，是个逐步收敛的值，
    # 单独看它容易误判。真正说明问题的是上面那行「末行下方留白」。
    print(f"yview = {editor.yview()}   ← 仅供参考，不稳定，别当判据")
    root.destroy()


def app_main_ratio() -> float:
    """读一下 `EDITOR_BOTTOM_PAD_RATIO`，免得这里再写死一个数字。"""
    import main
    return main.EDITOR_BOTTOM_PAD_RATIO


if __name__ == "__main__":
    main()
