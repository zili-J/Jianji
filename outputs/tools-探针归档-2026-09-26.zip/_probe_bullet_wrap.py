"""核验「光标落到列表/标题那一行，那一行就自动多折一行」（用户报的）。

**判据（三条，全部要与「光标在别处」逐项相等）**
1. `断点`：第一个**真实显示行**承载到第几个字符；
2. `显示行数`：这一行占几个真实显示行；
3. `正文 x`：正文首字符的横坐标（记号露出来不能把正文顶右）。

`见证 y` 只**打印**、不参与判定：行首记号一露出来，那个 elide 的首块就不再算一份
额外的行距，整段确实会矮 `px(行高) − 字体行距`（用户设置下 16px），下方内容跟着上移。
这是 `_marker_options` 里明确记下的、暂时接受的残留，不是「重折行」，别混进来。

**三个坑，探针必须绕开**（都踩过，都会得出假结论）：

* 直接 `mark_set` 只动 Tk 的插入点，应用侧的标签互换排在 `after_idle` 里，
  不显式跑一次 `_refresh_cursor_line()` 就量不到真实状态；
* 「光标在别处」不能把光标扔到文稿末尾——目标行会被滚出视口，`bbox` 全返回 `None`，
  于是量到一堆 `x=0`。这里改成把光标停在**紧邻目标行的普通正文行**上：目标行仍在
  视口内，而且那一行自身没有记号、几何恒定，正好当见证；
* **`bbox` 会给 elide 的字符返回「它自己那个块」的盒子**，不是显示行的盒子。行首
  记号被 elide 时那块没有字、高只剩行距（16px），于是凭空多出一个「假显示行」——
  用 `bbox` 的 y 值分显示行会把断点算成 2、显示行数多算一个（`无序+粗体` 就是这么
  被误判成「重折行」的）。改用 `dlineinfo`（给的是显示行盒子）过一遍
  `is_real_display_box`，把假盒子滤掉。

    python tools/quiet_desktop.py python.exe tools/_probe_bullet_wrap.py
    JIANJI_OLD=1 python tools/quiet_desktop.py python.exe tools/_probe_bullet_wrap.py
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402

REAL_STATE = Path.home() / "AppData/Local/JianJi/state.json"

FILLER = "列表项正文要够长才会折行，这里故意写得长一些用来观察折行位置。"
# (前缀, 后缀, 标签)。后缀用来放**行内记号的收尾**：`**加粗**`、`` `代码` ``。
# 行内记号（`**`、`` ` ``）平时是 elide 的，光标进到这一行才露出来——那会让这一行
# **变宽**，卡在折行边界上的行就会重折。这是「有序列表也换行」的真正嫌疑。
KINDS = [("- ", "", "无序 0 级"), ("  - ", "", "无序 1 级"), ("    - ", "", "无序 2 级"),
         ("* ", "", "星号"), ("- [ ] ", "", "任务未勾"), ("- [x] ", "", "任务已勾"),
         ("1. ", "", "有序"), ("> ", "", "引用"), ("", "", "普通正文"),
         ("## ", "", "二级标题"), ("#### ", "", "四级标题"),
         ("1. **", "**：说明", "有序+粗体"), ("- **", "**：说明", "无序+粗体"),
         ("**", "**：说明", "正文+粗体"), ("1. `", "`：说明", "有序+行内码"),
         ("- [ ] **", "**：说明", "任务+粗体"), ("> **", "**：说明", "引用+粗体"),
         ("## **", "**：说明", "标题+粗体")]
LENGTHS = list(range(34, 46))
WITNESS = "这是见证行，用来量这一行下方有没有位移。"


def build_document():
    """每个用例一行，紧跟一行普通正文当见证。返回 [(目标行, 见证行, 标签)]。"""
    lines = ["# 折行核验", ""]
    targets = []
    for prefix, suffix, label in KINDS:
        for size in LENGTHS:
            lines.append(prefix + (FILLER * 4)[:size] + suffix)
            lines.append(WITNESS)
            targets.append((len(lines) - 1, len(lines), f"{label} {size} 字"))
    return "\n".join(lines) + "\n", targets


def main() -> int:
    tmp = Path(tempfile.mkdtemp())
    real_state_path = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"

    settings = {}
    if REAL_STATE.is_file():
        settings = json.loads(REAL_STATE.read_text(encoding="utf-8")).get("settings", {})
    folder = tmp / "简记日记"
    folder.mkdir()
    doc = folder / "折行核验.md"
    text, targets = build_document()
    doc.write_text(text, encoding="utf-8")
    (tmp / "state.json").write_text(json.dumps({
        "folder": str(folder), "default_folder": str(folder),
        "last_file": str(doc), "settings": settings,
    }, ensure_ascii=False), encoding="utf-8")

    import main as app_main

    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()
    if os.environ.get("JIANJI_OLD"):
        def old_tag_marker(line, start, end, cursor_line, indent):
            tag = "syntax_current" if line == cursor_line else "syntax"
            app.editor.tag_add(tag, f"{line}.{start}", f"{line}.{end}")
            app._line_marks.setdefault(line, []).append(
                ("syntax", "syntax_current", start, end, None))
        app._tag_marker = old_tag_marker
        print("**修复前行为（syntax_current：无缩进补偿、不按字符折行）**\n")
    if os.environ.get("JIANJI_REVEAL_ALWAYS"):
        app._inline_reveal_fits = lambda line_number, line: True
        print("**修复前行为（行内记号一律露出，不看会不会多折一行）**\n")
    app.open_file(doc)
    root.update()

    editor = app.editor
    line_height = app_main.px(app.settings["line_height"])
    print(f"设置 {app.settings}")
    print(f"正文列宽 {editor.winfo_width() - app._current_pad * 2}  "
          f"留白 {app._current_pad}  px(LIST_INDENT)={app_main.px(app_main.LIST_INDENT)}  "
          f"wrap={editor.cget('wrap')}  px(行高)={line_height}\n")

    def elided_columns(line: int) -> list[tuple[int, int]]:
        """这一行被 elide 的字符区间（行首记号 + 行内记号）。"""
        spans = []
        for tag in ("syntax", "syntax_marker"):
            ranges = editor.tag_ranges(tag)
            for start, end in zip(ranges[0::2], ranges[1::2]):
                head = editor.index(start).split(".")
                if int(head[0]) != line:
                    continue
                spans.append((int(head[1]), int(editor.index(end).split(".")[1])))
        return spans

    def measure(line: int, witness: int) -> tuple[int, int, int, int] | None:
        """(断点, 显示行数, 正文 x, 见证行 y)。量不到返回 None。"""
        editor.tk.call(editor, "count", "-update", "1.0", "end")
        source = editor.get(f"{line}.0", f"{line}.end")
        groups: list[list] = []
        for i in range(len(source) + 1):
            info = editor.dlineinfo(f"{line}.{i}")
            if not app_main.is_real_display_box(info, line_height):
                continue                    # elide 首块的假盒子，不是显示行
            key = (info[1], info[3])
            if groups and groups[-1][0] == key:
                groups[-1][2] = i
            else:
                groups.append([key, i, i])
        if not groups:
            return None
        spans = elided_columns(line)
        marker = app_main.parse_block(source).marker
        body = marker[1] if marker else 0
        body_column = next(
            (i for i in range(body, len(source) + 1)
             if not any(a <= i < b for a, b in spans)), None)
        body_box = editor.bbox(f"{line}.{body_column}") if body_column is not None else None
        witness_box = editor.bbox(f"{witness}.0")
        if body_box is None or witness_box is None:
            return None
        return groups[0][2] + 1, len(groups), body_box[0], witness_box[1]

    def move_cursor(target: str) -> None:
        editor.mark_set("insert", target)
        editor.see("insert")
        app._refresh_cursor_line()
        root.update()

    rows = []
    for line, witness, label in targets:
        move_cursor(f"{witness}.0")            # 光标停在见证行：目标行仍在视口内
        away = measure(line, witness)
        move_cursor(f"{line}.end")             # 光标落到目标行
        here = measure(line, witness)
        rows.append((label, away, here))

    usable = [r for r in rows if r[1] and r[2]]
    # 只看前三项：见证 y 的 16px 位移是 `_marker_options` 里接受的残留（见文件头）。
    broken = [r for r in usable if r[1][:3] != r[2][:3]]
    shifted = [r for r in usable if r[1][3] != r[2][3]]
    print(f"{'列表项':<16} {'光标在别处 (断点/行数/正文x/见证y)':<34} "
          f"{'光标在本行':<26} 结论")
    for label, away, here in rows:
        if away is None or here is None:
            print(f"{label:<16} 量不到（目标行或见证行不在视口内）")
            continue
        if away[:3] == here[:3] and not label.endswith("34 字"):
            continue                            # 折行没变的形状只打第一条
        flag = ""
        if away[0] != here[0]:
            flag += " **断点变了**"
        if away[1] != here[1]:
            flag += " **显示行数变了**"
        if away[2] != here[2]:
            flag += " **正文x变了**"
        if away[3] != here[3]:
            flag += " （见证y位移，已接受）"
        print(f"{label:<16} {str(away):<34} {str(here):<26}{flag}")

    print(f"\n可量 {len(usable)}/{len(rows)} 条，折行全等："
          f"{sum(1 for r in usable if r[1][:3] == r[2][:3])} 条，折行有差异：{len(broken)} 条"
          f"（另有 {len(shifted)} 条只有见证 y 的 16px 位移，属已接受残留）")
    if broken:
        for label, away, here in broken:
            print(f"  差异 {label}: {away} -> {here}")
    root.destroy()
    storage.default_state_path = real_state_path
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
