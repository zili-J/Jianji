"""核验：使用说明新加的两条（「一行排满才换行」「内容行宽」）真的进了长图，
并且看清落在第几张、在第几行。

跑法：

    python tools/quiet_desktop.py <python 全路径> tools/_probe_new_bullets.py

关键词可当参数传：`... tools/_probe_new_bullets.py 一行排满 内容行宽`
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))

import image_export as ie  # noqa: E402
import main as app_main  # noqa: E402
import storage  # noqa: E402
import tkinter as tk  # noqa: E402

REAL_STATE = Path(os.environ.get("LOCALAPPDATA", "")) / "JianJi" / "state.json"
DEFAULT_KEYWORDS = ["一行排满才换行", "内容行宽"]
TARGET = PROJECT / "简记使用说明.md"


def build_app():
    tmp = Path(tempfile.mkdtemp())
    saved = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"
    settings = {}
    if REAL_STATE.exists():
        settings = json.loads(REAL_STATE.read_text(encoding="utf-8")).get("settings", {})
    folder = tmp / "简记日记"
    folder.mkdir()
    (tmp / "state.json").write_text(json.dumps({
        "folder": str(folder), "default_folder": str(folder),
        "last_file": "", "settings": settings}, ensure_ascii=False), encoding="utf-8")
    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()
    storage.default_state_path = saved
    return root, app


def line_text(line) -> str:
    return "".join(piece.text for piece in line.pieces)


def main() -> int:
    keywords = sys.argv[1:] or DEFAULT_KEYWORDS
    root, app = build_app()
    options = app._export_options()
    fonts = ie._Fonts()
    try:
        text = TARGET.read_text(encoding="utf-8-sig")
        rows = app_main.build_export_rows(text, options)
        lines = ie.build_layout(rows, options, app_main.export_palette(), fonts)
        chunks = ie._split_chunks(lines, options)

        print("源行 %d → 逻辑块 %d → 显示行 %d → %d 张"
              % (len(app_main.split_document_lines(text)), len(rows), len(lines), len(chunks)))
        for i, chunk in enumerate(chunks, 1):
            print("  第 %d 张: 显示行 %d 条  真实高 %d"
                  % (i, len(chunk), ie._chunk_height(ie._shift_chunk(chunk, options), options)))

        # 每张的分界：按 chunk 里第一条显示行在总表里的下标算
        first_of_chunk = []
        cursor = 0
        for chunk in chunks:
            first_of_chunk.append(cursor)
            cursor += len(chunk)

        def chunk_of(index: int) -> int:
            result = 0
            for n, start in enumerate(first_of_chunk):
                if index >= start:
                    result = n
            return result + 1

        print()
        for kw in keywords:
            hits = [(n, ln) for n, ln in enumerate(lines) if kw in line_text(ln)]
            print("关键词「%s」命中 %d 条显示行" % (kw, len(hits)))
            for n, ln in hits:
                print("    第 %d 张  显示行 #%d  top=%d h=%d  「%s」"
                      % (chunk_of(n), n, ln.top, ln.height, line_text(ln)[:48]))
            if not hits:
                print("    !! 没进长图 —— md 改了但没同步？")
    finally:
        fonts.close()
        root.destroy()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
