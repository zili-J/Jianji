"""把含指定关键词的那几行摊开看：每显示行的内容、宽度、可用宽度、填充率。

    python tools/quiet_desktop.py tools/_probe_wrap_dump.py <关键词> [文稿]
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))

import image_export as ie  # noqa: E402
import main as app_main  # noqa: E402
import storage  # noqa: E402
import tkinter as tk  # noqa: E402

REAL_STATE = Path(os.environ.get("LOCALAPPDATA", "")) / "JianJi" / "state.json"
NEEDLE = sys.argv[1]
DOC = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(
    r"C:/Users/22910/Documents/wb01/说明书/project.md")


def main() -> int:
    tmp = Path(tempfile.mkdtemp())
    saved = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"
    settings = json.loads(REAL_STATE.read_text(encoding="utf-8")).get("settings", {})
    folder = tmp / "简记日记"
    folder.mkdir()
    (tmp / "state.json").write_text(json.dumps({
        "folder": str(folder), "default_folder": str(folder),
        "last_file": "", "settings": settings}, ensure_ascii=False), encoding="utf-8")

    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()
    options = app._export_options()
    fonts = ie._Fonts()
    try:
        rows = app_main.build_export_rows(DOC.read_text(encoding="utf-8-sig"), options)
        lines = ie.build_layout(rows, options, app_main.export_palette(), fonts)
        groups: list[list] = []
        for line in lines:
            if groups and groups[-1][0].row is line.row:
                groups[-1].append(line)
            else:
                groups.append([line])
        for group in groups:
            row = group[0].row
            whole = "".join(p.text for p in row.pieces)
            if NEEDLE not in whole:
                continue
            if row.kind in ("bullet", "task", "ordered"):
                indent = options.list_left(row.level)
            elif row.kind == "quote":
                indent = options.margin + options.list_indent
            else:
                indent = options.margin
            available = options.margin + options.content_width - indent
            print(f"--- {row.kind} level={row.level} 可用宽度 {available} "
                  f"片段 {[(p.text[:14], p.font[1]) for p in row.pieces]}")
            for number, line in enumerate(group):
                content = "".join(p.text for p in line.pieces)
                width = ie._measure(line.pieces, fonts)
                print(f"  {number + 1:>3}  宽 {width:>4}  {width / available:6.1%}  {content!r}")
            print()
    finally:
        fonts.close()
        root.destroy()
        storage.default_state_path = saved
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
