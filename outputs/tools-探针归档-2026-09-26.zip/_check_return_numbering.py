"""核验「有序列表回车续号」：新行到底有没有出来、光标停在哪儿、显示成什么样。

用法：python tools/_check_return_numbering.py
产出：outputs/回车续号.txt（每一步的文本、光标、标签、elide 状态）
      outputs/回车续号.png（界面截图）

为什么不能只断言文本：用户报的是「**不显示换行、光标丢了**」——文本层面看着是对的，
问题出在「光标所在行要显示源码、其它行隐藏记号」这条规则有没有跟着更新。
所以要同时把 `insert` 的位置、`_cursor_line`、以及记号区间的 elide 状态都打出来。
"""
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import storage                                    # noqa: E402
from capture_window import capture_hwnd           # noqa: E402

DOC = """# 续号核验

1. 第一条
2. 第二条
3. 第三条

正文结束。
"""


def dump(app, title: str, out: list[str]) -> None:
    editor = app.editor
    text = editor.get("1.0", "end-1c")
    insert = editor.index("insert")
    cursor_line = int(insert.split(".")[0])
    out.append(f"--- {title} ---")
    out.append(f"文本: {text!r}")
    out.append(f"insert = {insert}   _cursor_line = {app._cursor_line}")

    # 光标所在行和上一行的 elide 情况
    for line in (cursor_line, cursor_line - 1):
        if line < 1:
            continue
        line_text = editor.get(f"{line}.0", f"{line}.end")
        elided = []
        for tag in ("syntax", "syntax_current"):
            ranges = editor.tag_ranges(tag)
            spans = [f"{ranges[i]}-{ranges[i + 1]}" for i in range(0, len(ranges), 2)]
            hits = [s for s in spans
                    if editor.compare(f"{line}.0", "<", s.split("-")[1])
                    and editor.compare(s.split("-")[0], "<", f"{line}.end")]
            if hits:
                elided.append(f"{tag}:{hits}")
        out.append(f"  行 {line} {line_text!r}  {elided or '（无记号标签）'}")

    # 记号记录（有序序号**故意不记进 _line_marks**）
    marks = app._line_marks.get(cursor_line)
    out.append(f"  _line_marks[{cursor_line}] = {marks}")
    out.append(f"  该行块类型 = {app._doc_blocks[cursor_line - 1].kind if cursor_line - 1 < len(app._doc_blocks) else '越界'}")
    out.append(f"  焦点在编辑区 = {app.root.focus_get() is editor}")
    out.append("")


def main() -> None:
    tmp = Path(tempfile.mkdtemp())
    storage.default_state_path = lambda: tmp / "state.json"
    folder = tmp / "简记日记"
    folder.mkdir()
    doc = folder / "续号核验.md"
    doc.write_text(DOC, encoding="utf-8")
    storage.set_default_folder(folder)

    import tkinter as tk

    from main import JianJiApp

    root = tk.Tk()
    root.geometry("1240x820")
    app = JianJiApp(root)
    root.update()
    app.open_file(doc)
    root.update()

    out: list[str] = []
    dump(app, "打开后（光标在 1.0）", out)

    # 把光标放到「1. 第一条」的行尾，模拟用户在那里按回车
    app.editor.mark_set("insert", "3.end")
    app.editor.focus_set()
    app._refresh_cursor_line()
    root.update()
    dump(app, "光标移到 3.end 之后", out)

    result = app._on_editor_return()
    root.update()
    dump(app, f"_on_editor_return() 返回 {result!r} 之后", out)

    # 再按一次，看能不能一路续下去
    app._on_editor_return()
    root.update()
    dump(app, "再按一次之后", out)

    out_dir = PROJECT / "outputs"
    out_dir.mkdir(exist_ok=True)
    (out_dir / "回车续号.txt").write_text("\n".join(out), encoding="utf-8")
    print("\n".join(out))

    try:
        width, height = capture_hwnd(int(root.winfo_id()), out_dir / "回车续号.png")
        print(f"写出 outputs/回车续号.png {width}×{height}")
    except OSError as error:                       # pragma: no cover
        print("截图失败:", error)

    root.destroy()


if __name__ == "__main__":
    main()
