"""核验「导出长图断行位置」：用**用户真实设置**排真文稿，逐显示行看断在哪，A/B 对照。

判据（全部相对可用宽度，不含绝对像素）：
- **行首禁则**：续行的第一个字不该是收尾类标点（`，。、；：？！）》」』…`）。
  中日韩标点出现在行首一定是排版错；ASCII 标点单列一桶（`.简记回收站`、`3.12`
  本来就是那个记号的第一个字，断在那儿是对的）。
- **行尾禁则**：上一行的最后一个字不该是开启类标点（`（《「『“`）。
- **填充率**：折行出来的显示行（不是段落末行）填得越满越好；低于阈值就是
  「白扔大半行」，用户看到的就是「凭空多了一个换行」。

A/B 的做法是把 `image_export._break_index` 临时换成**不做禁则**的那一版
（`_raw_break`，禁则之前的行为），同一份文稿再排一遍，直接看差多少处。

    python tools/quiet_desktop.py tools/_probe_export_break.py [文稿...]
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))

import image_export as ie  # noqa: E402
import main as app_main  # noqa: E402
import storage  # noqa: E402
import tkinter as tk  # noqa: E402

REAL_STATE = Path(os.environ.get("LOCALAPPDATA", "")) / "JianJi" / "state.json"

DEFAULT_DOCS = [
    Path(r"C:\Users\22910\Documents\wb01\说明书\简记使用说明.md"),
    Path(r"C:\Users\22910\Documents\wb01\说明书\project.md"),
]

# 不能出现在行首的标点（收尾类）。分两桶：中日韩标点出现在行首一定是排版错，
# ASCII 标点却可能本来就是那个记号的第一个字（`.简记回收站`、`3.12`、`50%`），
# 所以只把前者算成违规，后者单列出来人工看。
CLOSING_CJK = "，。、；：？！）》」』】〕〉…"
CLOSING_ASCII = ",.;:?!)]}%"
CLOSING = CLOSING_CJK + CLOSING_ASCII
# 不能出现在行尾的标点（开启类）
OPENING = "（《「『【〔〈([{<“‘"

FILL_FLOOR = float(os.environ.get("FILL_FLOOR", "0.85"))


def raw_break(text: str, start: int, index: int, floor: int | None = None) -> int:
    """禁则之前的那一版 `_break_index`（A/B 用）。"""
    floor = start if floor is None else floor
    if text[index].isspace():
        return index + 1
    if ie._is_wide(text[index]):
        return index
    for position in range(index - 1, floor - 1, -1):
        char = text[position]
        if char.isspace() or ie._is_wide(char):
            cut = position + 1
            if text[start:cut].strip():
                return cut
            break
    return index


def indent_of(row, options: ie.Options) -> int:
    if row.kind in ("bullet", "task", "ordered"):
        return options.list_left(row.level)
    if row.kind == "quote":
        return options.margin + options.list_indent
    return options.margin


def scan(rows, options: ie.Options, fonts: ie._Fonts) -> dict:
    lines = ie.build_layout(rows, options, app_main.export_palette(), fonts)
    groups: list[list] = []
    for line in lines:
        if groups and groups[-1][0].row is line.row:
            groups[-1].append(line)
        else:
            groups.append([line])

    head: list[str] = []
    soft: list[str] = []
    tail: list[str] = []
    thin: list[str] = []
    for group in groups:
        row = group[0].row
        if row.kind in ("table", "code"):
            continue
        available = max(40, options.margin + options.content_width
                        - indent_of(row, options))
        for number, line in enumerate(group):
            content = "".join(p.text for p in line.pieces)
            if not content:
                continue
            at = f"y={line.top}"
            # 只查**折行出来的**续行：记录行的首行以标点开头是源文本来就这样
            # （比如 `- :smile:`、`- `!`），不是断行的错。
            if number and content[0] in CLOSING:
                previous = "".join(p.text for p in group[number - 1].pieces)
                note = (f"{row.kind} 第 {number + 1} 显示行 {at} 以 {content[0]!r} 开头 "
                        f"← 上一行尾 {previous[-6:]!r}")
                (head if content[0] in CLOSING_CJK else soft).append(note)
            if number + 1 < len(group) and content[-1] in OPENING:
                tail.append(f"{row.kind} 第 {number + 1} 显示行 {at} 以 {content[-1]!r} 结尾")
            # 折行行（不是本段最后一行）才有「该填满」的要求
            if number + 1 < len(group):
                fill = ie._measure(line.pieces, fonts) / available
                if fill < FILL_FLOOR:
                    thin.append(f"{row.kind} 第 {number + 1} 显示行 {at} 填充 {fill:.1%}  "
                                f"尾字 {content[-4:]!r}  "
                                f"下一行首字 {''.join(p.text for p in group[number + 1].pieces)[:4]!r}")
    return {"lines": len(lines), "groups": len(groups), "head": head,
            "soft": soft, "tail": tail, "thin": thin}


def report(tag: str, data: dict, show: bool) -> None:
    print(f"  {tag}：显示行 {data['lines']}  行首禁则 {len(data['head'])}  "
          f"行尾禁则 {len(data['tail'])}  填充不足 {len(data['thin'])}  "
          f"（ASCII 起行 {len(data['soft'])}，可能合法）")
    if not show:
        return
    for item in data["head"][:12]:
        print(f"      ✗ 行首标点：{item}")
    for item in data["tail"][:6]:
        print(f"      ✗ 行尾标点：{item}")
    for item in data["thin"][:12]:
        print(f"      ✗ 填充不足：{item}")
    for item in data["soft"][:6]:
        print(f"      · ASCII 起行：{item}")


def main() -> int:
    tmp = Path(tempfile.mkdtemp())
    saved_state_path = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"

    if not REAL_STATE.is_file():
        print(f"找不到用户设置 {REAL_STATE}")
        return 1
    settings = json.loads(REAL_STATE.read_text(encoding="utf-8")).get("settings", {})

    folder = tmp / "简记日记"
    folder.mkdir()
    (tmp / "state.json").write_text(json.dumps({
        "folder": str(folder), "default_folder": str(folder),
        "last_file": "", "settings": settings,
    }, ensure_ascii=False), encoding="utf-8")

    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()

    options = app._export_options()
    fonts = ie._Fonts()
    docs = [Path(p) for p in sys.argv[1:]] or DEFAULT_DOCS
    docs = [d for d in docs if d.is_file()]
    print(f"用户设置 {settings}")
    print(f"导出参数 宽 {options.width} 边距 {options.margin} 正文列宽 "
          f"{options.content_width} 正文字号 {options.body_size} 行高 {options.line_height}\n")

    totals = {"head": 0, "tail": 0, "thin": 0}
    saved_break = ie._break_index
    try:
        for doc in docs:
            text = doc.read_text(encoding="utf-8-sig")
            rows = app_main.build_export_rows(text, options)
            print(f"=== {doc.name} ===")
            new = scan(rows, options, fonts)
            report("修好之后", new, show=True)

            ie._break_index = raw_break
            try:
                old = scan(rows, options, fonts)
            finally:
                ie._break_index = saved_break
            report("不做禁则", old, show=False)
            print(f"  差值：显示行 {old['lines'] - new['lines']:+d}  "
                  f"行首禁则 {len(old['head']) - len(new['head']):+d}  "
                  f"行尾禁则 {len(old['tail']) - len(new['tail']):+d}  "
                  f"填充不足 {len(old['thin']) - len(new['thin']):+d}\n")

            totals["head"] += len(new["head"])
            totals["tail"] += len(new["tail"])
            totals["thin"] += len(new["thin"])
    finally:
        ie._break_index = saved_break
        fonts.close()
        root.destroy()
        storage.default_state_path = saved_state_path

    print(f"合计：行首禁则 {totals['head']}  行尾禁则 {totals['tail']}  "
          f"填充不足 {totals['thin']}")
    return 0 if not any(totals.values()) else 1


if __name__ == "__main__":
    raise SystemExit(main())
