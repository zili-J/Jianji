"""排版自检：找出任何超出正文右边缘的显示行，并报告它是怎么被切出来的。"""
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "app"))

import storage  # noqa: E402

tmp = Path(tempfile.mkdtemp())
storage.default_state_path = lambda: tmp / "state.json"
folder = tmp / "d"
folder.mkdir()
storage.set_default_folder(folder)

import tkinter as tk  # noqa: E402
from image_export import _Fonts, build_layout  # noqa: E402
from main import build_export_rows, export_palette, JianJiApp  # noqa: E402

root = tk.Tk()
app = JianJiApp(root)
root.update()

for name in sys.argv[1:]:
    text = Path(name).read_text(encoding="utf-8")
    options = app._export_options()
    fonts = _Fonts()
    try:
        rows = build_export_rows(text, options)
        lines = build_layout(rows, options, export_palette(), fonts)
        right = options.margin + options.content_width
        bad = []
        for line in lines:
            if line.table is not None:
                continue
            used = sum(fonts.width(p.text, p.font) for p in line.pieces)
            if line.x + used > right + 2:
                bad.append((line, used))
        print(f"{name}: {len(lines)} 个显示行，{len(bad)} 行越界（右边界 {right}）")
        for line, used in bad[:6]:
            content = "".join(p.text for p in line.pieces)
            print(f"  x={line.x} 宽={used} 右={line.x + used} kind={line.row.kind} "
                  f"wrap={line.wrap} 字数={len(content)}")
            print(f"    片段数={len(line.pieces)} 文本={content[:60]!r}")
    finally:
        fonts.close()
root.destroy()
