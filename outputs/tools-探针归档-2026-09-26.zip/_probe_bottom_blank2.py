"""量「滚到底还剩多少空白」——**两栏分别量**，别把病因猜错。

用法：python tools/_probe_bottom_blank2.py
产出：屏幕输出 + outputs/底部空白2.txt

用户报的：「长文滚动到底部时，仍能显示 25% 区域的空白」。
第一版探针（`_probe_bottom_blank.py`）只量了**编辑区**，结论是底部只空 0.7%
——说明症状不在编辑区（至少不在那份文稿上）。这里补齐两件事：

  A. 编辑区换几种**结尾**（正文 / 标题 / 分隔线 / 代码块 / 表格 / 若干空行），
     看是不是某种结尾会撑出一大截下留白；
  B. **文稿列表**（中间那一栏）滚到底之后的空白——卡片区是自绘画布，
     滚动区高度是自己算的，最可能多留一截。
"""
import json
import os
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import storage                                     # noqa: E402

BODY = "\n".join(f"第 {i} 段正文，用来把文稿撑长一点，好让它超过一屏。"
                 for i in range(1, 60))

ENDINGS = {
    "正文结尾": BODY + "\n最后一句正文。\n",
    "标题结尾": BODY + "\n## 末尾小标题\n",
    "分隔线结尾": BODY + "\n---\n",
    "代码块结尾": BODY + "\n```\ncode line\n```\n",
    "表格结尾": BODY + "\n| a | b |\n| --- | --- |\n| 1 | 2 |\n",
    "三个空行结尾": BODY + "\n最后一句正文。\n\n\n\n",
}


def real_settings() -> dict:
    path = Path(os.environ.get("LOCALAPPDATA", "")) / "JianJi" / "state.json"
    try:
        return json.loads(path.read_text(encoding="utf-8")).get("settings", {})
    except (OSError, ValueError):
        return {}


def editor_blank(app) -> str:
    editor = app.editor
    height = editor.winfo_height()
    box = editor.bbox("end-1c")
    if box is None:
        return f"视口 {height}  bbox('end-1c') = None"
    bottom = box[1] + box[3]
    return (f"视口 {height}  末行下沿 {bottom}  下方空白 {height - bottom} px"
            f"（{(height - bottom) / height * 100:.1f}%）")


def cards_blank(app) -> str:
    canvas = app.cards_canvas
    height = canvas.winfo_height()
    origin = canvas.canvasy(0)
    region = canvas.cget("scrollregion")
    region_bottom = float(str(region).split()[3]) if region else 0.0
    last_bottom = app._card_bounds[-1][1] if app._card_bounds else 0
    blank = height - (last_bottom - origin)
    return (f"视口 {height}  原点 {origin:.0f}  滚动区下沿 {region_bottom:.0f}  "
            f"末卡片下沿 {last_bottom:.0f}  下方空白 {blank:.0f} px"
            f"（{blank / height * 100:.1f}%）  yview = {canvas.yview()}")


def main() -> None:
    settings = real_settings()
    tmp = Path(tempfile.mkdtemp())
    state_path = tmp / "state.json"
    state_path.write_text(json.dumps({"settings": settings}, ensure_ascii=False),
                          encoding="utf-8")
    storage.default_state_path = lambda: state_path
    folder = tmp / "简记日记"
    folder.mkdir()
    storage.set_default_folder(folder)

    import tkinter as tk

    from main import JianJiApp

    root = tk.Tk()
    root.geometry("1240x820")
    app = JianJiApp(root)
    root.update()

    out: list[str] = [f"设置 = {app.settings}", "", "=== A. 编辑区（各种结尾）==="]
    for name, text in ENDINGS.items():
        path = folder / f"{name}.md"
        path.write_text(text, encoding="utf-8")
        app.open_file(path)
        root.update()
        app.editor.yview_moveto(1.0)
        root.update()
        out.append(f"{name:10s} → {editor_blank(app)}")

    out.append("")
    out.append("=== B. 文稿列表（中间那一栏）===")
    # 造 40 篇，让卡片区远超一屏
    for i in range(40):
        (folder / f"文稿-{i:03d}.md").write_text(
            f"# 文稿 {i}\n\n" + "正文内容，用来把卡片撑成四行。\n" * 3, encoding="utf-8")
    app.refresh_files()
    root.update()
    out.append(f"卡片数 = {len(app._card_bounds)}")
    out.append(f"刚刷新完     → {cards_blank(app)}")

    event = type("E", (), {"delta": -120})()
    previous = None
    for _ in range(3000):
        app._on_cards_wheel(event)
        current = app.cards_canvas.yview()
        if previous is not None and current == previous:
            break
        previous = current
    root.update()
    out.append(f"滚轮滚到底   → {cards_blank(app)}")

    app.cards_canvas.yview_moveto(1.0)
    root.update()
    out.append(f"yview_moveto(1.0) → {cards_blank(app)}")

    out_dir = PROJECT / "outputs"
    out_dir.mkdir(exist_ok=True)
    (out_dir / "底部空白2.txt").write_text("\n".join(out), encoding="utf-8")
    print("\n".join(out))

    root.destroy()


if __name__ == "__main__":
    main()
