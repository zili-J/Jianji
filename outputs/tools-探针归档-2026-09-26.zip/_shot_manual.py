"""把《简记使用说明》本身导出成长图——既是文档的真实用例，也是最全的语法核验。"""
import struct
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "app"))

import storage  # noqa: E402

MANUAL = ROOT / "简记使用说明.md"

tmp = Path(tempfile.mkdtemp())
storage.default_state_path = lambda: tmp / "state.json"
folder = tmp / "简记日记"
folder.mkdir()
doc = folder / "使用说明.md"
doc.write_text(MANUAL.read_text(encoding="utf-8"), encoding="utf-8")
storage.set_default_folder(folder)

import tkinter as tk  # noqa: E402
from main import JianJiApp  # noqa: E402

root = tk.Tk()
root.geometry("1240x820")
app = JianJiApp(root)
root.update()
app.open_file(doc)
root.update()

start = time.perf_counter()
images = app.render_document_image(app.editor.get("1.0", "end-1c"))
elapsed = (time.perf_counter() - start) * 1000

out = ROOT / "outputs"
for index, data in enumerate(images):
    width, height = struct.unpack(">II", data[16:24])
    name = f"使用说明-长图{'' if index == 0 else f'-{index + 1}'}.png"
    (out / name).write_bytes(data)
    print(f"{name}: {width}×{height}  {len(data) / 1024:.0f} KB")
lines = int(app.editor.index("end-1c").split(".")[0])
print(f"{lines} 行，{len(images)} 张，耗时 {elapsed:.0f} ms")
root.destroy()
