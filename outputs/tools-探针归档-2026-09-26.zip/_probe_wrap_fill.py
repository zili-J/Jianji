"""量导出长图里每一显示行的「填充率」，找出断得过早的行。

用户报「行宽很窄 → 逗号后面异常换行」。要判断是「正常折行」还是「断得太早」，
只能量：填充率 = 本行宽度 ÷ 本行可用宽度。

可用宽度就是 `build_layout` 折行时用的那个数：
`options.margin + options.content_width - line.x`（缩进行自动变窄）。
所以按**每行自己的**可用宽度算，才不会被缩进带偏。

同时统计真正的「行首禁则」违反：行首是**中文**收尾标点（ASCII 的 `.` `)` 在代码块、
文件名里出现是正常的，不算）。

    python tools/quiet_desktop.py <python 全路径> tools/_probe_wrap_fill.py [文稿路径...]
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))

import image_export as ie  # noqa: E402
import main as app_main  # noqa: E402
import storage  # noqa: E402
import tkinter as tk  # noqa: E402

REAL_STATE = Path(os.environ.get("LOCALAPPDATA", "")) / "JianJi" / "state.json"
# 只看中文收尾标点：ASCII 的 . ) ] 在代码块/文件名里出现在行首是正常的
CJK_CLOSING = "，。、；：？！）》」』】〕〉…"
DEFAULT_DOCS = [
    Path(r"C:\Users\22910\Documents\wb01\说明书\简记使用说明.md"),
    PROJECT / ".3things" / "project.md",
]


def text_of(line) -> str:
    return "".join(p.text for p in line.pieces)


def main() -> int:
    docs = [Path(a) for a in sys.argv[1:]] or DEFAULT_DOCS
    tmp = Path(tempfile.mkdtemp())
    saved = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"
    settings = json.loads(REAL_STATE.read_text(encoding="utf-8")).get("settings", {})
    folder = tmp / "d"
    folder.mkdir()
    (tmp / "state.json").write_text(json.dumps({
        "folder": str(folder), "default_folder": str(folder),
        "last_file": "", "settings": settings}, ensure_ascii=False), encoding="utf-8")

    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()
    options = app._export_options()
    fonts = ie._Fonts()
    try:
        print(f"画布宽 {options.width}，边距 {options.margin}，内容宽 {options.content_width}")
        for doc in docs:
            if not doc.exists():
                print(f"跳过（不存在）：{doc}")
                continue
            rows = app_main.build_export_rows(doc.read_text(encoding="utf-8-sig"), options)
            lines = ie.build_layout(rows, options, app_main.export_palette(), fonts)
            print(f"\n=== {doc.name}：{len(lines)} 显示行 ===")
            buckets = [0] * 10
            measured: list[tuple[float, int, str, int]] = []
            for line in lines:
                text = text_of(line)
                if not text.strip():
                    continue
                avail = options.margin + options.content_width - line.x
                width = ie._measure(line.pieces, fonts)
                if avail <= 0:
                    continue
                ratio = width / avail
                buckets[min(9, int(ratio * 10))] += 1
                measured.append((ratio, line.top, text, line.x))
            for i, n in enumerate(buckets):
                print(f"  填充 {i * 10:>3}-{i * 10 + 10:>3}%: {'#' * min(58, n):<58} {n}")

            heads = [line for line in lines
                     if text_of(line)[:1] in CJK_CLOSING]
            tails = [line for line in lines
                     if text_of(line)[-1:] in CJK_CLOSING]
            print(f"  行首中文收尾标点：{len(heads)} 处   行尾中文收尾标点：{len(tails)} 处")
            for line in heads[:8]:
                print(f"    行首违反 y={line.top}  [{text_of(line)[:30]}]")

            # 关键判据：**同一段里不是最后一行的显示行**都必须填满——
            # 短一行说明「断得太早」。段落的最后一行短是正常的，标题/表格短也正常。
            stats = {"first": 0, "mid": 0, "last": 0}
            anomalies: list[tuple[float, int, str, str, str]] = []
            for i, line in enumerate(lines):
                text = text_of(line)
                if not text.strip():
                    continue
                nxt = lines[i + 1] if i + 1 < len(lines) else None
                is_last = nxt is None or nxt.row is not line.row
                if is_last:
                    stats["last" if line.wrap else "first"] += 1
                    continue
                stats["first" if not line.wrap else "mid"] += 1
                avail = options.margin + options.content_width - line.x
                ratio = ie._measure(line.pieces, fonts) / avail if avail > 0 else 1.0
                if ratio < 0.9:
                    anomalies.append((ratio, line.top,
                                      text[-24:], text_of(nxt)[:20],
                                      "" if not line.wrap else "续"))
            print(f"  段中行（必须填满）：首行 {stats['first']}  续行 {stats['mid']}  "
                  f"段末行 {stats['last']}")
            print(f"  **段中行却没填满（断得太早）：{len(anomalies)} 处**")
            for ratio, top, tail, nxt, kind in sorted(anomalies, key=lambda x: x[0])[:15]:
                print(f"    {ratio * 100:5.1f}%  y={top:<6} {kind} 本行尾[{tail}] → 下行首[{nxt}]")
    finally:
        fonts.close()
        root.destroy()
        storage.default_state_path = saved
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
