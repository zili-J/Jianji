"""把一行的「显示行」逐字符还原出来，看清楚记号露出前后排版到底怎么变。

`bbox(f"L.{i}")` 给的是**该下标所在 chunk** 的盒子（一个 chunk 可能跨多个字符，
也可能跨显示行），所以按 y 值分组就能把显示行拼回来：
同一显示行的所有字符 y 相同，每组的字符区间 = 这一显示行承载的字符。

    python tools/quiet_desktop.py python.exe tools/_probe_display_lines.py
    JIANJI_NO_COMPENSATE=1 python tools/quiet_desktop.py python.exe tools/_probe_display_lines.py
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402

REAL_STATE = Path.home() / "AppData/Local/JianJi/state.json"

BODY = "列表项正文要够长才会折行，这里故意写得长一些用来观察折行位置。"
CASES = [("- " + BODY, "无序 0 级"), ("- [ ] " + BODY, "任务未勾"),
         ("1. " + BODY, "有序"), (BODY, "普通正文")]


def main() -> int:
    tmp = Path(tempfile.mkdtemp())
    real_state_path = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"

    settings = {}
    if REAL_STATE.is_file():
        settings = json.loads(REAL_STATE.read_text(encoding="utf-8")).get("settings", {})
    folder = tmp / "简记日记"
    folder.mkdir()
    doc = folder / "显示行.md"
    lines = ["# 显示行", ""]
    for source, _label in CASES:
        lines.append(source)
        lines.append("")
    doc.write_text("\n".join(lines) + "\n", encoding="utf-8")
    (tmp / "state.json").write_text(json.dumps({
        "folder": str(folder), "default_folder": str(folder),
        "last_file": str(doc), "settings": settings,
    }, ensure_ascii=False), encoding="utf-8")

    import main as app_main

    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()
    if os.environ.get("JIANJI_NO_COMPENSATE"):
        app._body_text_width = lambda _text: 0
        print("**缩进补偿已关闭（旧行为）**")
    if os.environ.get("JIANJI_MARGIN1") is not None:
        value = int(os.environ["JIANJI_MARGIN1"])
        original = app._tag_marker

        def patched(line, start, end, cursor_line, indent):
            original(line, start, end, cursor_line, (value, indent[1]))
        app._tag_marker = patched
        print(f"**lmargin1 强制为 {value}**")
    app.open_file(doc)
    root.update()

    editor = app.editor
    total = int(editor.index("end-1c").split(".")[0])
    print(f"设置 {app.settings}  留白 {app._current_pad}  "
          f"px(LIST_INDENT)={app_main.px(app_main.LIST_INDENT)}\n")

    def display_lines(line: int):
        editor.tk.call(editor, "count", "-update", "1.0", "end")
        source = editor.get(f"{line}.0", f"{line}.end")
        groups: list[list[int]] = []
        for i in range(len(source) + 1):
            box = editor.bbox(f"{line}.{i}")
            if box is None:
                continue
            x, y, w, _h = box
            if groups and groups[-1][0] == y:
                groups[-1][1] = i
                groups[-1][2] = min(groups[-1][2], x)
                groups[-1][3] = max(groups[-1][3], x + w)
            else:
                groups.append([y, i, x, x + w])
        return source, groups

    def move_cursor(target: str) -> None:
        editor.mark_set("insert", target)
        editor.see("insert")
        app._refresh_cursor_line()
        root.update()

    for index, (source, label) in enumerate(CASES):
        line = 3 + index * 2
        print("=" * 78)
        print(f"{label}  第 {line} 行  共 {len(source)} 字符")
        for state in ("光标在别处", "光标在本行"):
            move_cursor(f"{total}.0" if state == "光标在别处" else f"{line}.end")
            text, groups = display_lines(line)
            marks = app._line_marks.get(line)
            print(f"  [{state}]  insert={editor.index('insert')}  marks={marks}")
            print(f"    tags@0 = {editor.tag_names(f'{line}.0')}")
            for k, (y, last, left, right) in enumerate(groups):
                print(f"    显示行{k}: 字符 [0,{last + 1})  y={y}  x={left}..{right} "
                      f"宽={right - left}")
    root.destroy()
    storage.default_state_path = real_state_path
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
