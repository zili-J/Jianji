"""临时诊断：逐字符打 `dlineinfo`（显示行的盒子），看清「光标进出这一行」到底
改变了什么。

`bbox` 会给 elide 的字符返回**它自己那个块**的盒子（不是显示行的盒子），
`**` 这种「行内记号 elide」正好卡在两个显示行之间，于是出现 1px 的假显示行——
`_probe_bullet_wrap.py` 的「断点 / 显示行数」就是被这个 1px 骗了。
`dlineinfo` 给的是**显示行**的盒子，同一显示行上的字符应当给出同一个 `(y, 高)`。

    python tools/quiet_desktop.py python.exe tools/_probe_dline.py
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402

REAL_STATE = Path.home() / "AppData/Local/JianJi/state.json"
FILLER = "列表项正文要够长才会折行，这里故意写得长一些用来观察折行位置。"
CASES = [
    ("- **", "**：说明", "无序+粗体"),
    ("1. **", "**：说明", "有序+粗体"),
    ("- ", "", "无序"),
    ("1. ", "", "有序"),
]
SIZE = 34


def main() -> int:
    tmp = Path(tempfile.mkdtemp())
    saved = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"

    settings = {}
    if REAL_STATE.is_file():
        settings = json.loads(REAL_STATE.read_text(encoding="utf-8")).get("settings", {})
    folder = tmp / "简记日记"
    folder.mkdir()
    doc = folder / "显示行.md"
    lines = ["# 显示行核验", ""]
    targets = []
    for prefix, suffix, label in CASES:
        lines.append(prefix + (FILLER * 4)[:SIZE] + suffix)
        lines.append("见证行。")
        targets.append((len(lines) - 1, label))
    doc.write_text("\n".join(lines) + "\n", encoding="utf-8")
    (tmp / "state.json").write_text(json.dumps({
        "folder": str(folder), "default_folder": str(folder),
        "last_file": str(doc), "settings": settings,
    }, ensure_ascii=False), encoding="utf-8")

    import main as app_main

    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()
    app.open_file(doc)
    root.update()
    ed = app.editor
    print(f"设置 {app.settings}\n")

    def dump(number: int, label: str) -> tuple:
        ed.tk.call(ed, "count", "-update", "1.0", "end")
        source = ed.get(f"{number}.0", f"{number}.end")
        groups: list[tuple] = []
        for i in range(len(source) + 1):
            info = ed.dlineinfo(f"{number}.{i}")
            if info is None:
                continue
            key = (info[1], info[3])          # (y, 高)：显示行盒子的两把尺
            if groups and groups[-1][0] == key:
                groups[-1][2] = i
                groups[-1][3] = max(groups[-1][3], info[0] + info[2])
            else:
                groups.append([key, i, i, info[0] + info[2]])
        return source, groups

    for number, label in targets:
        print(f"=== 第 {number} 行 {label} ===")
        for where in ("光标在别处", "光标在本行"):
            if where == "光标在本行":
                ed.mark_set("insert", f"{number}.end")
            else:
                ed.mark_set("insert", f"{number + 1}.0")
            app._refresh_cursor_line()
            root.update()
            source, groups = dump(number, label)
            tags = sorted(set(ed.tag_names(f"{number}.0")))
            print(f"  【{where}】tags(0)={tags}")
            for (y, height), first, last, right in groups:
                print(f"    显示行 y={y} 高={height} 字 {first}..{last} "
                      f"右缘={right}  文本={source[first:last + 1][:12]!r}")
        print()
    root.destroy()
    storage.default_state_path = saved
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
