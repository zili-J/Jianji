"""量「点选文稿」和「打字」这两条用户路径，看卡顿出在哪一段。

用法：python tools/_bench_click.py
产出：屏幕输出 + outputs/卡顿基准.txt

用户报的两条：
  1. 鼠标光标点选文档时，软件反应卡顿
  5. 编辑时软件有卡顿

`_bench_smoothness.py` 只量了滚轮/移光标/打字，**没有量「点选文稿」**。
点一张卡片走的是 `_on_cards_left_click` → `open_file` → 里面除了整篇重解析，
还有一次 `refresh_files()`（要重新读盘上每一篇文稿的摘要、重画每一张卡片），
文稿一多就可能是大头。所以这里把这条路径拆开分别计时。

设置读用户 `state.json` 里的真实值：列宽、字号、行高不同，折行和解析量都不一样。
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import time
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402


def build_doc(sections: int, title: str) -> str:
    parts = [f"# {title}\n"]
    for index in range(1, sections + 1):
        parts.append(f"\n## 第 {index} 节\n")
        parts.append(f"\n这是第 {index} 节的正文，带 **粗体** 和 `代码`。\n")
        parts.append(f"\n- 第 {index} 节的第一条\n  - 嵌套一条\n- [ ] 待办 {index}\n")
        parts.append(f"\n> 第 {index} 节的引用。\n")
        if index % 5 == 0:
            parts.append(f"\n| 项目 | 数量 |\n| --- | ---: |\n| 第 {index} 节 | {index} |\n")
    return "".join(parts)


def real_settings() -> dict:
    path = Path(os.environ.get("LOCALAPPDATA", "")) / "JianJi" / "state.json"
    try:
        return json.loads(path.read_text(encoding="utf-8")).get("settings", {})
    except (OSError, ValueError):
        return {}


def measure(action, repeat: int = 10) -> float:
    best = float("inf")
    for _ in range(repeat):
        root.update()
        start = time.perf_counter()
        action()
        root.update()
        best = min(best, (time.perf_counter() - start) * 1000)
    return best


def bench(sections: int, doc_count: int, out: list[str]) -> None:
    tmp = Path(tempfile.mkdtemp())
    state_path = tmp / "state.json"
    state_path.write_text(json.dumps({"settings": real_settings()}, ensure_ascii=False),
                          encoding="utf-8")
    storage.default_state_path = lambda: state_path
    folder = tmp / "简记日记"
    folder.mkdir()
    docs = []
    for i in range(doc_count):
        path = folder / f"文稿-{i:03d}.md"
        path.write_text(build_doc(sections, f"文稿 {i}"), encoding="utf-8")
        docs.append(path)
    storage.set_default_folder(folder)

    from main import JianJiApp

    global root
    root = tk.Tk()
    root.geometry("1240x820")
    app = JianJiApp(root)
    app.open_file(docs[0])
    root.update()

    lines = len(app.editor.get("1.0", "end-1c").splitlines())
    out.append(f"--- 每篇 {sections} 节（{lines} 行），共 {doc_count} 篇 ---")

    # ① 点另一张卡片：走 _on_cards_left_click 的整条路径
    pick = {"n": 0}

    def click_card():
        pick["n"] += 1
        app.open_file(docs[pick["n"] % len(docs)])

    click = measure(click_card, repeat=8)

    # ② 其中 refresh_files 单独量一次
    refresh = measure(lambda: app.refresh_files(app.current_path), repeat=6)

    # ③ 整篇重解析（open_file 里的另一半）
    restyle = measure(lambda: app._apply_markdown_styles(), repeat=6)

    # ④ 打字：走 _on_editor_modified 的增量路径
    def type_one():
        app.editor.insert("insert", "字")

    typed = measure(type_one, repeat=10)

    # ⑤ 敲字后 Tk 自己那一次重折行（用户真正感受到的那一下）
    def type_and_settle():
        app.editor.insert("insert", "字")
        app.editor.see("insert")

    typed_full = measure(type_and_settle, repeat=10)

    out.append(f"点选文稿（整条）   {click:7.1f} ms")
    out.append(f"  其中 refresh_files {refresh:7.1f} ms")
    out.append(f"  其中 整篇重解析    {restyle:7.1f} ms")
    out.append(f"敲一个字（处理函数）{typed:7.1f} ms")
    out.append(f"敲一个字（含 settle）{typed_full:7.1f} ms")
    out.append(f"卡片数 = {len(app._card_bounds)}")
    out.append("")
    root.destroy()


if __name__ == "__main__":
    lines: list[str] = []
    for sections, doc_count in ((20, 6), (60, 12), (150, 30), (400, 60)):
        bench(sections, doc_count, lines)
    text = "\n".join(lines)
    print(text)
    out_dir = PROJECT / "outputs"
    out_dir.mkdir(exist_ok=True)
    (out_dir / "卡顿基准.txt").write_text(text, encoding="utf-8")
