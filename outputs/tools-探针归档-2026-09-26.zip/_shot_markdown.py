"""截取「新增 Markdown 语法全部输入即预览」的核验图。

产出：
  outputs/Markdown语法预览.png   —— 整窗
  outputs/Markdown语法特写.png   —— 编辑区 2 倍放大
"""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402
from capture_window import capture_hwnd, capture_widget_region  # noqa: E402

DOC = """# 一级标题

## 二级标题

### 三级标题

#### 四级标题

##### 五级标题

###### 六级标题

正文里的行内样式：**加粗**、*斜体*、__另一种加粗__、_另一种斜体_、
~~删除线~~、==高亮==、`行内代码`。

- 第一层项目符号
- 这是一个很长的项目符号内容，用来确认自动换行之后，续行会和第一行的正文左边缘对齐，而不是缩到项目符号下面去。
  - 第二层用空心圆
    - 第三层用方块
- 回到第一层

1. 有序列表第一项
2. 第二项
3. 第三项

- [ ] 还没做的待办
- [x] 已经做完的待办
  - [ ] 嵌套的待办

> 这是一段引用。
> 引用的第二行，左侧竖条会连起来。

---

```python
def hello(name):
    return f"你好，{name}"
```

正文里还有链接 [简记的说明](https://example.com/docs) 和
图片 ![示例图片](https://example.com/a.png)。
"""


def main() -> None:
    tmp = Path(tempfile.mkdtemp())
    real_state = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"

    folder = tmp / "简记日记"
    folder.mkdir()
    doc = folder / "Markdown 语法.md"
    doc.write_text(DOC, encoding="utf-8")
    storage.set_default_folder(folder)

    from main import JianJiApp

    root = tk.Tk()
    app = JianJiApp(root)
    app.open_file(doc)
    root.update()

    # 把光标放到文末，让所有语法记号被隐藏，看到真正的排版效果
    app.editor.mark_set("insert", "end-1c")
    app._apply_styles_without_dirty_flag()
    root.update()
    root.update_idletasks()

    out_dir = PROJECT / "outputs"
    out_dir.mkdir(parents=True, exist_ok=True)

    w, h = capture_hwnd(int(root.winfo_toplevel().winfo_id()),
                        out_dir / "Markdown语法预览.png")
    print(f"full   {w} x {h}")

    zw, zh = capture_widget_region(app.editor, out_dir / "Markdown语法特写.png", factor=2)
    print(f"zoom   {zw} x {zh}")

    # 下半部分：引用、分隔线、围栏代码块、链接与图片
    app.editor.yview_moveto(1.0)
    app._apply_styles_without_dirty_flag()
    root.update()
    root.update_idletasks()
    zw, zh = capture_widget_region(app.editor, out_dir / "Markdown语法特写-下半.png", factor=2)
    print(f"zoom2  {zw} x {zh}")

    print("pad", app._current_pad, "decor canvases", len(app._decor_pool),
          "used", sum(1 for c in app._decor_pool if c.winfo_manager()))

    # 光标停在列表行：Markdown 记号会显示出来，看正文会不会跳、装饰会不会重影
    app.editor.yview_moveto(0.0)
    app.editor.mark_set("insert", "16.3")
    app._apply_styles_without_dirty_flag()
    root.update()
    root.update_idletasks()
    zw, zh = capture_widget_region(app.editor, out_dir / "Markdown语法-光标在列表行.png", factor=2)
    print(f"zoom3  {zw} x {zh}")
    root.destroy()
    storage.default_state_path = real_state


if __name__ == "__main__":
    main()
