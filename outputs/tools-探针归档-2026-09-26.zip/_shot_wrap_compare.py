"""把「导出长图随机增加换行」的**修复前 / 修复后**各渲染一张小图，直接看差别。

取的真实素材是 `简记使用说明.md` 里以**两个前导空格**开头的那些行——它们正是
Markdown 硬换行留下的「续行」，也就是旧版会甩出一整行空白的那批。

    python tools/quiet_desktop.py tools/_shot_wrap_compare.py

产出：`outputs/导出换行-修复前.png`、`outputs/导出换行-修复后.png`
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))

import image_export as ie  # noqa: E402
import storage  # noqa: E402
import tkinter as tk  # noqa: E402

REAL_STATE = Path(os.environ.get("LOCALAPPDATA", "")) / "JianJi" / "state.json"
SOURCE = Path(r"C:\Users\22910\Documents\wb01\说明书\简记使用说明.md")
OUTPUTS = PROJECT / "outputs"


def old_break_index(text: str, start: int, index: int) -> int:
    for position in range(index - 1, start, -1):
        char = text[position]
        if char.isspace() and not ie._is_wide(char):
            return position + 1
    return start


def lines_of(rows, options, fonts) -> list[str]:
    layout = ie.build_layout(rows, options, None, fonts)
    return ["".join(p.text for p in line.pieces) for line in layout]


def main() -> int:
    tmp = Path(tempfile.mkdtemp())
    real_state_path = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"
    OUTPUTS.mkdir(exist_ok=True)

    user = json.loads(REAL_STATE.read_text(encoding="utf-8"))
    folder = tmp / "简记日记"
    folder.mkdir()
    (tmp / "state.json").write_text(json.dumps({
        "folder": str(folder), "default_folder": str(folder), "last_file": "",
        "settings": user.get("settings", {}),
    }, ensure_ascii=False), encoding="utf-8")

    import main as app_main

    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()

    indented = [line for line in SOURCE.read_text(encoding="utf-8-sig").split("\n")
                if line.startswith("  ") and line.strip()]
    text = "# 导出换行对比\n\n" + "\n\n".join(indented[:3]) + "\n"
    print(f"素材：{SOURCE.name} 里以两个空格开头的行共 {len(indented)} 条，取前 3 条\n")

    options = app._export_options()
    fonts = ie._Fonts()
    try:
        rows = app_main.build_export_rows(text, options)
        fixed = lines_of(rows, options, fonts)

        ie._break_index, saved = old_break_index, ie._break_index
        try:
            broken = lines_of(rows, options, fonts)
            (OUTPUTS / "导出换行-修复前.png").write_bytes(
                ie.render(rows, options, app_main.export_palette(), fonts)[0])
        finally:
            ie._break_index = saved
        (OUTPUTS / "导出换行-修复后.png").write_bytes(
            ie.render(rows, options, app_main.export_palette(), fonts)[0])

        for name, payload in (("修复前", broken), ("修复后", fixed)):
            print(f"{name}：{len(payload)} 显示行  空行 "
                  f"{sum(1 for line in payload if not line.strip())}")

        print()
        for number in range(max(len(broken), len(fixed))):
            left = broken[number] if number < len(broken) else "—"
            right = fixed[number] if number < len(fixed) else "—"
            flag = "  ← 多了空行" if not left.strip() and right.strip() else ""
            print(f"  {number + 1:>2}  旧 {left[:30]!r:<34} 新 {right[:30]!r}{flag}")
    finally:
        fonts.close()
        root.destroy()
        storage.default_state_path = real_state_path
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
