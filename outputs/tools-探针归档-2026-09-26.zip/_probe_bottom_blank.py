"""量「长文滚到底部还剩多少空白」。

用法：python tools/_probe_bottom_blank.py
产出：屏幕输出 + outputs/底部空白.txt

用户报的：「长文滚动到底部时，仍能显示 25% 区域的空白」。

这里把三件事分开量，免得把病因猜错：
  1. 滚到底（`yview_moveto(1.0)`）之后，最后一行的下沿在哪、视口下沿在哪、中间空多少；
  2. 用**滚轮**一路滚到底（走 `_on_editor_wheel`，和用户操作同一条路径）之后再量一次；
  3. 文稿末尾到底有几个空行、最后一行是什么标签（`spacing3` 会撑出下留白）。

设置一律读用户 `%LOCALAPPDATA%\\JianJi\\state.json` 里的真实值——列宽、字号、行高
不同，折行位置和总高都不一样。
"""
import json
import os
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import storage                                     # noqa: E402


def real_state() -> dict:
    path = Path(os.environ.get("LOCALAPPDATA", "")) / "JianJi" / "state.json"
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def longest_doc(folder: Path) -> Path | None:
    docs = [p for p in folder.rglob("*.md") if ".简记回收站" not in p.parts]
    if not docs:
        return None
    return max(docs, key=lambda p: p.stat().st_size)


def report(app, title: str, out: list[str]) -> None:
    editor = app.editor
    height = editor.winfo_height()
    out.append(f"--- {title} ---")
    out.append(f"视口高度 = {height}   yview = {editor.yview()}")
    total = editor.count("1.0", "end-1c", "displaylines")
    out.append(f"总显示行数 = {total[0] if total else '?'}")

    box = editor.bbox("end-1c")
    if box is None:
        out.append("bbox('end-1c') = None（最后一个字符不在视口内）")
    else:
        bottom = box[1] + box[3]
        blank = height - bottom
        out.append(f"最后一行矩形 = {box}  → 下沿 y = {bottom}")
        out.append(f"下方空白 = {blank} px"
                   f"（视口的 {blank / height * 100:.1f}%）")
    # 视口里最后一条**有内容**的显示行
    last_visible = None
    for number in range(1, int(editor.index("end-1c").split(".")[0]) + 1):
        info = editor.dlineinfo(f"{number}.0")
        if info and info[1] < height:
            last_visible = (number, info)
    if last_visible:
        number, info = last_visible
        text = editor.get(f"{number}.0", f"{number}.end")
        out.append(f"视口里最后一条逻辑行 = 第 {number} 行 {text[:40]!r}  "
                   f"下沿 {info[1] + info[3]}")
    out.append("")


def main() -> None:
    state = real_state()
    settings = state.get("settings", {})
    user_folder = Path(state.get("folder") or state.get("default_folder") or ".")

    tmp = Path(tempfile.mkdtemp())
    state_path = tmp / "state.json"
    state_path.write_text(json.dumps({"settings": settings}, ensure_ascii=False),
                          encoding="utf-8")
    storage.default_state_path = lambda: state_path
    storage.set_default_folder(user_folder)

    doc = longest_doc(user_folder)
    if doc is None:
        print("用户文件夹里没有 .md，无法核验")
        return

    import tkinter as tk

    from main import JianJiApp

    root = tk.Tk()
    root.geometry("1240x820")
    app = JianJiApp(root)
    root.update()
    app.open_file(doc)
    root.update()

    out: list[str] = [f"设置 = {app.settings}", f"文稿 = {doc}", ""]
    report(app, "刚打开", out)

    app.editor.yview_moveto(1.0)
    root.update()
    report(app, "yview_moveto(1.0)", out)

    # 先滚回顶，再一路用滚轮滚到底（用户的操作路径）
    app.editor.yview_moveto(0.0)
    root.update()
    event = type("E", (), {"delta": -120, "widget": app.editor})()
    previous = None
    for _ in range(4000):
        app._on_editor_wheel(event)
        current = app.editor.yview()
        if previous is not None and current == previous:
            break
        previous = current
    root.update()
    report(app, "滚轮一路滚到底", out)

    lines = doc.read_text(encoding="utf-8", errors="replace").split("\n")
    out.append(f"源文件共 {len(lines)} 行（按 \\n 切）")
    out.append(f"末尾 8 行 = {lines[-8:]!r}")
    last_content = max([i for i, l in enumerate(lines) if l.strip()] or [0])
    out.append(f"末尾连续空行数 = {len(lines) - 1 - last_content}")
    out.append(f"最后一行原文 = {lines[-1]!r}")

    out_dir = PROJECT / "outputs"
    out_dir.mkdir(exist_ok=True)
    (out_dir / "底部空白.txt").write_text("\n".join(out), encoding="utf-8")
    print("\n".join(out))

    root.destroy()


if __name__ == "__main__":
    main()
