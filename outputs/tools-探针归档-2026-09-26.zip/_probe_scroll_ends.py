"""量两栏「往两端滚过头」之后原点有没有跑出范围。

用法：python tools/_probe_scroll_ends.py
产出：屏幕输出 + outputs/滚动两端.txt

背景：文稿列表是自绘画布，Tk 的 Canvas **只在滚动区比视口高时才夹住原点**。
上一轮修的是「往上滚 → 顶部空出一条」——`_clamp_cards_scroll` 判据是
`canvasy(0) < 0`。用户这次报的是**底部**还有 25% 空白，所以要反过来查一遍：
  ① 内容比视口**矮**时往下滚，原点会不会跑成正数（底部空出来）；
  ② 内容比视口**高**时滚到底，原点有没有超过「滚动区下沿 − 视口高」；
  ③ 编辑区同样两种情形，确认 Text 自己夹得住（它是另一个控件，不要一起加保护）。
"""
import json
import os
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import storage                                     # noqa: E402


def real_settings() -> dict:
    path = Path(os.environ.get("LOCALAPPDATA", "")) / "JianJi" / "state.json"
    try:
        return json.loads(path.read_text(encoding="utf-8")).get("settings", {})
    except (OSError, ValueError):
        return {}


def cards_state(app) -> str:
    canvas = app.cards_canvas
    height = canvas.winfo_height()
    origin = canvas.canvasy(0)
    region = canvas.cget("scrollregion")
    bottom = float(str(region).split()[3]) if region else 0.0
    max_origin = max(0.0, bottom - height)
    last = app._card_bounds[-1][1] if app._card_bounds else 0
    blank = height - (last - origin)
    return (f"视口 {height}  原点 {origin:.0f}（允许 0..{max_origin:.0f}）"
            f"  滚动区 {bottom:.0f}  末卡片下沿 {last:.0f}  "
            f"底部空白 {blank:.0f} px（{blank / height * 100:.1f}%）")


def spin(app, event, limit=3000):
    previous = None
    for _ in range(limit):
        app._on_cards_wheel(event)
        current = app.cards_canvas.yview()
        if previous is not None and current == previous:
            break
        previous = current


def main() -> None:
    tmp = Path(tempfile.mkdtemp())
    state_path = tmp / "state.json"
    state_path.write_text(json.dumps({"settings": real_settings()}, ensure_ascii=False),
                          encoding="utf-8")
    storage.default_state_path = lambda: state_path
    folder = tmp / "简记日记"
    folder.mkdir()
    storage.set_default_folder(folder)

    import tkinter as tk

    from main import JianJiApp

    root = tk.Tk()
    root.geometry("1240x820")
    app = JianJiApp(root)
    root.update()

    out: list[str] = []
    down = type("E", (), {"delta": -120})()
    up = type("E", (), {"delta": 120})()

    for count in (2, 4, 8, 40):
        for path in folder.glob("*.md"):
            path.unlink()
        for i in range(count):
            (folder / f"文稿-{i:03d}.md").write_text(
                f"# 文稿 {i}\n\n正文内容。\n", encoding="utf-8")
        app.refresh_files()
        root.update()
        out.append(f"=== {count} 篇文稿 ===")
        out.append(f"  刚刷新       {cards_state(app)}")
        spin(app, down)
        root.update()
        out.append(f"  往下滚到底   {cards_state(app)}")
        spin(app, up)
        root.update()
        out.append(f"  再往上滚到顶 {cards_state(app)}")
        app.cards_canvas.yview_moveto(1.0)
        root.update()
        out.append(f"  moveto(1.0)  {cards_state(app)}")
        app.cards_canvas.yview_moveto(0.0)
        root.update()
        out.append(f"  moveto(0.0)  {cards_state(app)}")

    out.append("")
    out.append("=== 编辑区（Text 自己夹）===")
    for name, body in (("短文", "只有一句话。\n"),
                       ("长文", "\n".join(f"第 {i} 行。" for i in range(200)) + "\n")):
        doc = folder / f"{name}.md"
        doc.write_text(body, encoding="utf-8")
        app.open_file(doc)
        root.update()
        for label, delta in (("滚轮下", -120), ("滚轮上", 120)):
            event = type("E", (), {"delta": delta})()
            previous = None
            for _ in range(2000):
                app._on_editor_wheel(event)
                current = app.editor.yview()
                if previous is not None and current == previous:
                    break
                previous = current
            root.update()
            out.append(f"  {name} {label} → yview = {app.editor.yview()}")

    out_dir = PROJECT / "outputs"
    out_dir.mkdir(exist_ok=True)
    (out_dir / "滚动两端.txt").write_text("\n".join(out), encoding="utf-8")
    print("\n".join(out))

    root.destroy()


if __name__ == "__main__":
    main()
