"""核验《简记使用说明.md》在软件里的渲染效果。

产出 outputs/说明文档-1.png ~ -N.png（分段整窗截图）。
"""
from __future__ import annotations

import re
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402
from capture_window import capture_hwnd  # noqa: E402


def main() -> None:
    source = PROJECT / "简记使用说明.md"
    # 放到一个干净的空文件夹里截图，免得文件夹树里混进工程目录
    tmp = Path(tempfile.mkdtemp())
    folder = tmp / "简记日记"
    folder.mkdir()
    doc = folder / source.name
    doc.write_text(source.read_text(encoding="utf-8"), encoding="utf-8")
    real_state = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"
    storage.set_default_folder(folder)

    from main import JianJiApp

    root = tk.Tk()
    app = JianJiApp(root)
    app.open_file(doc)
    root.update()

    app.editor.mark_set("insert", "end-1c")
    app._apply_styles_without_dirty_flag()
    root.update()
    root.update_idletasks()

    lines = re.split(r"\r\n|\r|\n", app.editor.get("1.0", "end-1c"))
    print(f"文档 {len(lines)} 行")

    # 围栏是否正确嵌套：四反引号块里的三反引号应当是「内容」而不是分隔线
    codeblock_lines = set()
    raw = app.editor.tag_ranges("codeblock")
    for i in range(0, len(raw), 2):
        start = int(str(raw[i]).split(".")[0])
        end = int(str(raw[i + 1]).split(".")[0])
        codeblock_lines.update(range(start, end + 1))
    print("codeblock 覆盖行数", len(codeblock_lines))

    def in_tag(tag: str, index: str) -> bool:
        raw = app.editor.tag_ranges(tag)
        for i in range(0, len(raw), 2):
            if (app.editor.compare(index, ">=", raw[i])
                    and app.editor.compare(index, "<", raw[i + 1])):
                return True
        return False

    fence_lines = [n for n, text in enumerate(lines, start=1)
                   if text.strip().startswith(("```", "~~~"))]
    print("围栏行（elide 判定，与视口无关）：")
    for n in fence_lines:
        # 只看前三个字符，避免把「四个反引号开、三个反引号当内容」误报成同一种
        marker = lines[n - 1].strip()[:4]
        print(f"  第 {n:>3} 行 {marker!r:<8} "
              f"{'分隔线（隐藏）' if in_tag('syntax', f'{n}.0') else '代码内容（显示）'}")

    out_dir = PROJECT / "outputs"
    out_dir.mkdir(parents=True, exist_ok=True)
    total = len(lines)
    for index in range(6):
        app.editor.yview_moveto(index / 6.0)
        app._apply_styles_without_dirty_flag()
        root.update()
        root.update_idletasks()
        first = app.editor.index("@0,0")
        path = out_dir / f"说明文档-{index + 1}.png"
        w, h = capture_hwnd(int(root.winfo_toplevel().winfo_id()), path)
        print(f"  {path.name}  从第 {str(first).split('.')[0]} 行开始  {w}x{h}")

    root.destroy()
    storage.default_state_path = real_state


if __name__ == "__main__":
    main()
