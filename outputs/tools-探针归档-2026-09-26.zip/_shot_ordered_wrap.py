"""序号折行被裁：修复前后各截一张，用**用户自己的文档和设置**。

「修复前」不是靠注释掉代码，而是把旧的 `_display_line_box` 整套实现临时装回去
（旧实现按「高度 < 6 就算空盒子」判，并和空盒子合并上沿），这样两张图的差别
就只来自那处判据。

一次性核验脚本，产出放 outputs/。
"""
from __future__ import annotations

import json
import shutil
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402

REAL_DOC = Path(r"C:\Users\22910\Documents\wb01\新建-2026-09-24-213637.md")
REAL_STATE = Path.home() / "AppData/Local/JianJi/state.json"


def old_display_line_box(self, index: str):
    """修复前的实现：按高度判空盒子，并把上沿和空盒子合并。"""
    box = self.editor.dlineinfo(index)
    if box is None or box[3] >= 6:
        return box
    try:
        probe = self.editor.index(f"{index} + 1 display chars")
        next_display = self.editor.index(f"{index} + 1 display lines")
    except tk.TclError:
        return box
    if self.editor.compare(probe, ">=", next_display):
        return box
    found = self.editor.dlineinfo(probe)
    if found is None or found[3] < 6:
        return box
    top = box[1]
    return (found[0], top, found[2],
            max(box[1] + box[3], found[1] + found[3]) - top,
            found[1] + found[4] - top)


def main() -> int:
    tmp = Path(tempfile.mkdtemp())
    real = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"
    user = json.loads(REAL_STATE.read_text(encoding="utf-8"))
    folder = tmp / "简记日记"
    folder.mkdir()
    shutil.copy2(REAL_DOC, folder / REAL_DOC.name)
    (tmp / "state.json").write_text(json.dumps({
        "folder": str(folder), "default_folder": str(folder),
        "last_file": str(folder / REAL_DOC.name),
        "settings": user["settings"],
    }, ensure_ascii=False), encoding="utf-8")

    import main as app_main  # noqa: E402

    root = tk.Tk()
    root.geometry("1180x900")
    app = app_main.JianJiApp(root)
    root.update()
    app.open_file(folder / REAL_DOC.name)
    root.update()
    app.editor.mark_set("insert", "1.0")
    app._apply_styles_without_dirty_flag()
    root.update()

    ed = app.editor
    from capture_window import capture_widget_region

    out = PROJECT / "outputs"
    # 停在一个折行有序项正好整块落在视口里的位置
    ed.see("68.0")
    ed.yview_scroll(-4, "units")
    root.update()
    app._redraw_margins()
    root.update()

    fixed = app._display_line_box
    app._display_line_box = lambda index: old_display_line_box(app, index)
    app._redraw_margins()
    root.update()
    before = out / "修复前-序号折行被裁.png"
    capture_widget_region(ed, before, factor=1)
    print(f"修复前 {before.name}")

    app._display_line_box = fixed
    app._redraw_margins()
    root.update()
    after = out / "修复后-序号折行完整.png"
    capture_widget_region(ed, after, factor=1)
    print(f"修复后 {after.name}")

    # 顺手量一下同一屏下两种判据各裁掉几个序号
    app._display_line_box = lambda index: old_display_line_box(app, index)
    app._redraw_margins()
    root.update()
    print("旧判据下被裁的序号：", _clipped(app))
    app._display_line_box = fixed
    app._redraw_margins()
    root.update()
    print("新判据下被裁的序号：", _clipped(app))

    root.destroy()
    storage.default_state_path = real
    return 0


def _clipped(app) -> list:
    out = []
    for canvas in app._decor_pool:
        spec = getattr(canvas, "decor_spec", None)
        if not spec or spec[0] != "ordered" or not canvas.winfo_manager():
            continue
        box = canvas.bbox(canvas.find_all()[0])
        width, height = canvas.winfo_width(), canvas.winfo_height()
        if (box[0] < -1 or box[1] < -1 or box[2] > width + 1
                or box[3] > height + 1):
            out.append((canvas.decor_line, spec[2], box, (width, height)))
    return out


if __name__ == "__main__":
    raise SystemExit(main())
