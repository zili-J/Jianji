"""核验「预览卡片只显示 4 行」+ 顺手截整窗。

用户要求：`6. 调低预览框显示高度，显示 4 行内容即可。`

这个脚本做两件事：
1. 数出每张卡片**实际渲染**了几显示行，和 `CARD_EXCERPT_ROWS` 对一下。
   量法：Canvas 的 text 图元**没有** `dlineinfo`（那是 Text 的），所以先量一个字的
   高（= 一显示行），再量整段文字的高，相除。字体和宽度都取图元自己的属性，不猜。
   （直接数摘录里的 `\\n` 是没用的——摘录早就把换行接成空格了，行数是折行折出来的。）
2. 截一张整窗图，肉眼确认卡片高度确实矮下来了。

**套隐藏桌面跑**，别在前台跑（会弹窗抢焦点）：
    python tools/quiet_desktop.py <python> tools/_shot_cards_rows.py

产出放 outputs/。
"""
from __future__ import annotations

import sys
import tempfile
import time
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402
from capture_window import capture_widget_region  # noqa: E402

TITLES = ("训练计划", "读书笔记", "会议要点", "随手记", "本周复盘", "菜谱")

# 长短不一的正文：短的那篇不该被硬撑到 4 行，长的那篇必须正好停在 4 行。
BODIES = {
    "训练计划": "周一跑步五公里，周二力量训练，周三游泳，周四休息，周五骑行三十公里，"
                "周六爬山，周日拉伸放松，顺便把下周的计划排一排。",
    "读书笔记": "这一章讲的是习惯的复利效应，作者用了一整节的篇幅说明每天进步百分之一"
                "在一年之后会是什么样子，读起来很受触动，于是决定把每天要做的事再精简一遍，"
                "只留三件最重要的，其余的全部砍掉，免得摊子铺得太大反而一件都做不好。",
    "会议要点": "确认了下个版本的三个主要改动，分工和时间点都写在下面了。",
    "随手记": "想到一个点子，先记下来。",
    "本周复盘": "这周主要在处理文稿列表的性能问题，把重建卡片时逐张试排文字的开销降了下来，"
                "另外把底部留白和光标遮挡两个小毛病一起修了。下周准备把编辑区的整篇重解析也看看。",
    "菜谱": "番茄炒蛋：番茄两个切块，鸡蛋三个打散加少许盐，热锅冷油先炒蛋盛出，"
            "再下番茄炒出汁，回锅翻炒调味即可，全程不超过十分钟，很适合工作日的晚饭。",
}


def count_display_rows(app, canvas, item_id: int) -> tuple[int, int, int]:
    """返回 (显示行数, 文字高, 一显示行高)。

    用 `app._card_text_height`（就是应用自己试排文字用的那个原语），
    字体与折行宽度都取图元身上的属性。
    """
    text = canvas.itemcget(item_id, "text")
    if not text:
        return 0, 0, 0
    font_spec = canvas.itemcget(item_id, "font")
    width = int(float(canvas.itemcget(item_id, "width") or 0))
    one_line = app._card_text_height(canvas, "字", font_spec, width)
    total = app._card_text_height(canvas, text, font_spec, width)
    if one_line <= 0:
        return 0, total, one_line
    return round(total / one_line), total, one_line


def main() -> int:
    tmp = Path(tempfile.mkdtemp())
    real = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"

    folder = tmp / "简记日记"
    folder.mkdir()
    for index, title in enumerate(TITLES):
        (folder / f"{index:02d}-{title}.md").write_text(
            f"# {title}\n\n{BODIES[title]}\n", encoding="utf-8")
    storage.set_default_folder(folder)

    import main as app_main  # noqa: E402

    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()
    app.open_file(folder / f"00-{TITLES[0]}.md")

    # 先真的映射出来——没映射时 canvas 的几何量不出来。
    root.deiconify()
    root.lift()
    for _ in range(50):
        root.update()
        if root.winfo_viewable() and root.winfo_width() > 100:
            break
        time.sleep(0.02)
    root.update()

    budget = app_main.CARD_EXCERPT_ROWS
    print(f"CARD_EXCERPT_ROWS = {budget}\n")

    canvas = app.cards_canvas
    print(f"{'卡片':<10} {'显示行':>5} {'文字高':>6} {'一行高':>6}  摘录")
    worst = 0
    for order, title in enumerate(TITLES):
        items = canvas.find_withtag(f"card{order}")
        if not items:
            print(f"{title:<10} {'缺卡片':>5}")
            continue
        rows, total, one_line = count_display_rows(app, canvas, items[0])
        worst = max(worst, rows)
        excerpt = canvas.itemcget(items[0], "text")
        print(f"{title:<10} {rows:>5} {total:>6} {one_line:>6}  {excerpt[:24]}…")

    verdict = "OK" if worst <= budget else f"** 超出预算（{worst} > {budget}）**"
    print(f"\n最多显示行 {worst} / 预算 {budget}  → {verdict}")

    time.sleep(0.35)
    out = PROJECT / "outputs" / "预览卡片4行.png"
    width, height = capture_widget_region(root, out, factor=1)
    print(f"已截图 {out.name} {width}x{height}")

    root.destroy()
    storage.default_state_path = real
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
