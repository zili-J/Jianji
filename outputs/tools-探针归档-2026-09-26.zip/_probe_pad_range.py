"""单独量「底部留白标签」到底挂在哪些行上、把总高撑了多少。

用法：python tools/_probe_pad_range.py
产出：屏幕输出 + outputs/底部留白标签.txt
"""
import json
import os
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import storage                                     # noqa: E402


def real_settings() -> dict:
    path = Path(os.environ.get("LOCALAPPDATA", "")) / "JianJi" / "state.json"
    try:
        return json.loads(path.read_text(encoding="utf-8")).get("settings", {})
    except (OSError, ValueError):
        return {}


def dump(app, title, out):
    editor = app.editor
    ranges = editor.tag_ranges("bottom_pad")
    spans = [(str(ranges[i]), str(ranges[i + 1])) for i in range(0, len(ranges), 2)]
    out.append(f"--- {title} ---")
    out.append(f"bottom_pad 区间 = {spans}")
    out.append(f"行数（逻辑）= {editor.index('end-1c').split('.')[0]}  "
               f"显示行 = {editor.count('1.0', 'end-1c', 'displaylines')}")
    out.append(f"yview = {editor.yview()}   视口高 = {editor.winfo_height()}  "
               f"总高估算 = {editor.winfo_height() / max(1e-9, editor.yview()[1] - editor.yview()[0]):.0f}")
    out.append(f"spacing3 标签值 = {editor.tag_cget('bottom_pad', 'spacing3')!r}")
    out.append(f"Text 自身 spacing1/2/3 = "
               f"{editor.cget('spacing1')}/{editor.cget('spacing2')}/{editor.cget('spacing3')}")
    for number in range(1, int(editor.index("end-1c").split(".")[0]) + 1):
        info = editor.dlineinfo(f"{number}.0")
        text = editor.get(f"{number}.0", f"{number}.end")
        tags = editor.tag_names(f"{number}.0")
        out.append(f"  行 {number} {text[:24]!r} dline={info} tags={tags}")
    out.append("")


def main() -> None:
    tmp = Path(tempfile.mkdtemp())
    state_path = tmp / "state.json"
    state_path.write_text(json.dumps({"settings": real_settings()}, ensure_ascii=False),
                          encoding="utf-8")
    storage.default_state_path = lambda: state_path
    folder = tmp / "简记日记"
    folder.mkdir()
    doc = folder / "长文.md"
    doc.write_text("# 标题\n\n" + "\n".join(f"第 {i} 行正文。" for i in range(1, 60)) + "\n",
                   encoding="utf-8")
    storage.set_default_folder(folder)

    import tkinter as tk

    from main import JianJiApp

    root = tk.Tk()
    root.geometry("1240x820")
    app = JianJiApp(root)
    root.update()
    app.open_file(doc)
    root.update()

    out: list[str] = [f"设置 = {app.settings}",
                      f"_bottom_pad = {app._bottom_pad}", ""]
    dump(app, "打开后（自动挂标签）", out)

    # 手动清掉标签，作为对照
    app.editor.tag_remove("bottom_pad", "1.0", "end")
    root.update()
    dump(app, "手动清掉标签（对照）", out)

    # 手动按预期挂一次
    pad = int(app.editor.winfo_height() * 0.25)
    app.editor.tag_configure("bottom_pad", spacing3=pad)
    app.editor.tag_add("bottom_pad", "end-1c linestart", "end")
    root.update()
    dump(app, f"手动挂 spacing3={pad}", out)

    app.editor.yview_moveto(1.0)
    root.update()
    box = app.editor.bbox("end-1c")
    height = app.editor.winfo_height()
    out.append(f"滚到底：末行 bbox = {box}")
    if box:
        out.append(f"下方空白 = {height - (box[1] + box[3])} px"
                   f"（{(height - (box[1] + box[3])) / height * 100:.1f}%）")

    out_dir = PROJECT / "outputs"
    out_dir.mkdir(exist_ok=True)
    (out_dir / "底部留白标签.txt").write_text("\n".join(out), encoding="utf-8")
    print("\n".join(out))

    root.destroy()


if __name__ == "__main__":
    main()
