"""核验「导出长图」：用一篇覆盖全部语法的文档渲染长图，并抓一张界面截图。

用法：python tools/_shot_export.py
产出：outputs/导出长图-示例.png（渲染结果）
      outputs/导出长图-按钮.png（顶栏截图）
"""
import ctypes
import struct
import sys
import tempfile
import time
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import storage                                    # noqa: E402
from capture_window import capture_hwnd  # noqa: E402

DOC = """# 导出长图

这是一篇用来核验长图导出的文档，覆盖了简记支持的各类 Markdown 语法。

## 行内样式

正文里可以有 **加粗**、*斜体*、~~删除线~~、==高亮==、`行内代码` 和
[链接](https://example.com)，以及一个很长的英文句子 a very long english
sentence that should wrap at word boundaries instead of mid-word.

## 列表

- 第一层项目符号
- 第二层嵌套
  - 再深一层
    - 第三层是方块
- [x] 已经完成的任务
- [ ] 还没做的任务

1. 有序列表第一项
2. 有序列表第二项

## 引用

> 引用的文字前面有一条竖条，
> 续行也要连起来。

## 代码

```python
def greet(name: str) -> str:
    return f"你好，{name}"

print(greet("世界"))
```

---

## 表格

| 语法 | 是否支持 | 说明 |
| --- | :---: | --- |
| 标题 | 是 | H1 到 H6 |
| 表格 | 是 | 带表头底色与斑马纹，单元格内可折行 |
| 图片 | 是 | 显示为紫色斜体的说明文字 |

### 结尾

到这里就结束了。
"""


def png_size(data: bytes) -> tuple[int, int]:
    return struct.unpack(">II", data[16:24])


def main() -> None:
    tmp = Path(tempfile.mkdtemp())
    storage.default_state_path = lambda: tmp / "state.json"
    folder = tmp / "简记日记"
    folder.mkdir()
    doc = folder / "导出长图示例.md"
    doc.write_text(DOC, encoding="utf-8")
    storage.set_default_folder(folder)

    import tkinter as tk

    from main import JianJiApp

    root = tk.Tk()
    root.geometry("1240x820")
    app = JianJiApp(root)
    root.update()
    app.open_file(doc)
    root.update()
    app.editor.mark_set("insert", "1.0")
    app._apply_markdown_styles()
    root.update()

    out = PROJECT / "outputs"
    out.mkdir(exist_ok=True)

    # 1) 长图本体
    options = app._export_options()
    print("排版参数:", {k: v for k, v in vars(options).items()
                        if k not in ("heading", "bullet")})
    start = time.perf_counter()
    images = app.render_document_image(app.editor.get("1.0", "end-1c"))
    elapsed = (time.perf_counter() - start) * 1000
    print(f"渲染 {len(images)} 张，耗时 {elapsed:.0f} ms")
    for index, data in enumerate(images):
        width, height = png_size(data)
        name = f"导出长图-示例{'' if index == 0 else f'-{index + 1}'}.png"
        (out / name).write_bytes(data)
        print(f"  {name}: {width}×{height}  {len(data) / 1024:.0f} KB")

    # 2) 顶栏与整窗截图（导出入口已挪到文稿右键菜单，顶栏只剩状态与专注模式）
    root.update()
    try:
        top = app.topbar.winfo_toplevel()
        w, h = capture_hwnd(int(top.winfo_id()), out / "导出长图-界面.png")
        print(f"写出 outputs/导出长图-界面.png {w}×{h}")
    except OSError as error:                       # pragma: no cover
        print("截图失败:", error)

    # 2b) 长文档：看时间与内存是否还能接受
    long_doc = folder / "长文.md"
    long_doc.write_text(
        "".join(f"## 第 {index} 节\n\n"
                f"这是第 {index} 节的正文，**重点**、`代码` 与 [链接](https://a.b) 都在。\n\n"
                f"- 要点一\n- [x] 已完成\n\n> 引用一句\n\n"
                + ("| 项目 | 数量 |\n| --- | ---: |\n| 甲 | 1 |\n| 乙 | 2 |\n\n"
                   if index % 5 == 0 else "")
                for index in range(1, 121)),
        encoding="utf-8")
    app.open_file(long_doc)
    root.update()
    lines = int(app.editor.index("end-1c").split(".")[0])
    start = time.perf_counter()
    images = app.render_document_image(app.editor.get("1.0", "end-1c"))
    elapsed = (time.perf_counter() - start) * 1000
    sizes = [png_size(data) for data in images]
    print(f"长文档 {lines} 行 → {len(images)} 张 {sizes}，耗时 {elapsed:.0f} ms，"
          f"共 {sum(len(d) for d in images) / 1024:.0f} KB")
    (out / "导出长图-长文.png").write_bytes(images[0])
    app.open_file(doc)
    root.update()

    # 3) 滚轮：一格事件的位移必须是系统默认的 EDITOR_WHEEL_FACTOR 倍。
    #    量像素而不是 yview 比例：短文档的比例会被整行吸附放大误差，
    #    而 yview()[0] 是字符位置比例，不能直接读成像素。
    def wheel_pixels(delta: int, bound: bool) -> int:
        """滚一格后视口实际移动了多少像素。

        向下滚（delta<0）要先把视口顶到最上面、向上滚顶到最下面——
        已经到头时滚动是空操作，量出来会是 0，看不出差别。
        """
        if bound:
            app.editor.bind("<MouseWheel>", app._on_editor_wheel)
        else:
            app.editor.unbind("<MouseWheel>")
        root.update()
        app.editor.yview_moveto(0.0 if delta < 0 else 1.0)
        root.update()
        before = app.editor.yview()[0]
        app.editor.event_generate("<MouseWheel>", delta=delta)
        root.update()
        raw = app.editor.count("1.0", "end-1c", "ypixels")
        if isinstance(raw, (tuple, list)):     # 有的 Tk 版本回一个列表
            raw = raw[0]
        return round(abs(app.editor.yview()[0] - before) * int(raw))

    print(f"文档 {app.editor.index('end-1c')}，视口高 {app.editor.winfo_height()} px")
    for delta in (-120, 120, -240, 240):
        native = wheel_pixels(delta, bound=False)
        ours = wheel_pixels(delta, bound=True)
        ratio = ours / native if native else float("inf")
        print(f"  delta={delta:>5}: 默认 {native:>4} px  简记 {ours:>4} px  倍数 {ratio:.2f}×")
    app.editor.bind("<MouseWheel>", app._on_editor_wheel)

    root.destroy()
    _ = ctypes


if __name__ == "__main__":
    main()
