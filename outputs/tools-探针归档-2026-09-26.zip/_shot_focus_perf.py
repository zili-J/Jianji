"""核验专注模式与滚动的渲染效果（性能优化之后不能有视觉回归）。

产出 outputs/流畅度-正常模式.png、outputs/流畅度-专注模式.png。
"""
from __future__ import annotations

import sys
import tempfile
import time
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402
from capture_window import capture_hwnd  # noqa: E402


def build_doc() -> str:
    parts = ["# 流畅度核验\n"]
    for index in range(1, 61):
        parts.append(f"\n## 第 {index} 节\n")
        parts.append(f"\n这是第 {index} 节的正文，带 **粗体** 和 `代码`。\n")
        parts.append(f"\n- 第 {index} 节的第一条\n  - 嵌套一条\n- [ ] 待办 {index}\n")
        parts.append(f"\n> 第 {index} 节的引用。\n")
        if index % 5 == 0:
            parts.append(f"\n| 项目 | 数量 |\n| --- | ---: |\n| 第 {index} 节 | {index} |\n")
    return "".join(parts)


def main() -> None:
    tmp = Path(tempfile.mkdtemp())
    folder = tmp / "简记日记"
    folder.mkdir()
    doc = folder / "流畅度.md"
    doc.write_text(build_doc(), encoding="utf-8")
    real_state = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"
    storage.set_default_folder(folder)

    from main import JianJiApp

    root = tk.Tk()
    app = JianJiApp(root)
    app.open_file(doc)
    root.update()
    app.editor.mark_set("insert", "40.0")
    app._apply_styles_without_dirty_flag()
    root.update()

    total = len(app.editor.get("1.0", "end-1c").splitlines())
    print(f"文档 {total} 行")

    def snapshot(label: str) -> None:
        bullets = [c for c in app._decor_pool
                   if c.decor_spec is not None and c.decor_spec[0] == "bullet"]
        badges = app.heading_labels
        print(f"  {label}: 留白={app._current_pad} 项目符号={len(bullets)} 个"
              + (f" 首个在 ({bullets[0].winfo_x()}, {bullets[0].winfo_y()})" if bullets else "")
              + f"  徽标画布 x={badges.winfo_x()} 可见={bool(badges.winfo_manager())}")
        numbers = app.gutter.find_all()
        if numbers:
            first = app.gutter.coords(numbers[0])
            text = app.gutter.itemcget(numbers[0], "text")
            print(f"      行号画布 {len(numbers)} 个，第一个是 {text} @y={first[1]:.0f}")

    out_dir = PROJECT / "outputs"
    out_dir.mkdir(parents=True, exist_ok=True)

    snapshot("正常模式")
    path = out_dir / "流畅度-正常模式.png"
    w, h = capture_hwnd(int(root.winfo_toplevel().winfo_id()), path)
    print(f"  {path.name}  {w}x{h}")

    start = time.perf_counter()
    app.toggle_focus()
    toggle_only = (time.perf_counter() - start) * 1000
    start = time.perf_counter()
    root.update()                       # 事件循环里把所有排队的几何刷新跑完
    print(f"  切换专注模式：toggle_focus 本体 {toggle_only:.1f} ms"
          f" + 事件循环 {((time.perf_counter() - start) * 1000):.1f} ms")
    snapshot("专注模式")
    path = out_dir / "流畅度-专注模式.png"
    w, h = capture_hwnd(int(root.winfo_toplevel().winfo_id()), path)
    print(f"  {path.name}  {w}x{h}")

    # 滚动一屏，看装饰有没有跟上
    for _ in range(3):
        app.editor.yview_scroll(4, "units")
        root.update()
    snapshot("专注模式 · 向下滚 12 行")
    path = out_dir / "流畅度-专注模式滚动后.png"
    w, h = capture_hwnd(int(root.winfo_toplevel().winfo_id()), path)
    print(f"  {path.name}  {w}x{h}")

    start = time.perf_counter()
    app.toggle_focus()
    root.update()
    print(f"  退出专注模式（含事件循环）= {(time.perf_counter() - start) * 1000:.1f} ms")
    snapshot("退出专注")

    # 关掉我们自己的重画，看看剩下的时间有多少是 Tk 自己的重排/重折行
    app._flush_geometry = lambda: None
    start = time.perf_counter()
    app.toggle_focus()
    root.update()
    print(f"  只算 Tk 重排（屏蔽我们的重画）= {(time.perf_counter() - start) * 1000:.1f} ms")
    app.toggle_focus()
    root.update()

    root.destroy()
    storage.default_state_path = real_state
    print("done")


if __name__ == "__main__":
    main()
