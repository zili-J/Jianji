"""按**用户自己的设置**把一篇真实文稿从头滚到底，看每个装饰有没有被画布裁掉。

为什么单独有这个脚本（测试里已经有折行几何那几项了）：

* 测试用的是**造出来的**样例，而且窗口固定 1180×760。真机上用户的设置是
  `line_width 60 / font_size 18 / line_height 34`——字号 27px、行高 51px，
  折行位置和默认设置（23px / 33px）完全不同。这个脚本存在的直接原因就是：
  「序号折行被裁」这个 bug 前两版修复都以为修好了，因为探针**把 state.json
  指到临时文件、读的是 DEFAULT_SETTINGS**，量到的根本不是用户看到的排版。
* 真文稿里有序项/引用/缩进的组合比样例乱得多。

用法：

    python tools/_check_decorations.py [文稿路径]

不给路径就用用户 `state.json` 里的 `last_file`。**只读**：用户的 state.json
原样读出来、设置写进临时文件，文稿也是复制一份再打开。
"""
from __future__ import annotations

import json
import re
import shutil
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402

REAL_STATE = Path.home() / "AppData/Local/JianJi/state.json"
STEP_UNITS = 3


def _label(spec: tuple) -> str:
    """把 `decor_spec` 打成人看的短标签。

    各形态的元组长度不一样：`("quote",)` / `("bullet", level)` /
    `("task", level, checked)` / `("ordered", level, number)` / `("hr",)`，
    所以**不能固定取 `spec[2]`**——取到短元组上就是 IndexError。
    """
    if spec[0] == "ordered":
        return str(spec[2])
    if spec[0] == "task":
        return "☑" if spec[2] else "☐"
    return {"bullet": "•", "quote": "▏", "hr": "―"}.get(spec[0], spec[0])


def snapshot(app) -> list[dict]:
    """把当前挂着的装饰画布挨个量一遍，看画布里的图元有没有越界。"""
    rows = []
    for canvas in app._decor_pool:
        spec = getattr(canvas, "decor_spec", None)
        if not spec or not canvas.winfo_manager():
            continue
        items = canvas.find_all()
        if not items:
            continue
        bbox = canvas.bbox(items[0])
        if not bbox:
            continue
        width, height = canvas.winfo_width(), canvas.winfo_height()
        clipped = (bbox[0] < -1 or bbox[1] < -1
                   or bbox[2] > width + 1 or bbox[3] > height + 1)
        rows.append({
            "kind": spec[0], "mark": _label(spec), "line": canvas.decor_line,
            "bbox": bbox, "size": (width, height),
            "pos": (canvas.winfo_x(), canvas.winfo_y()), "clipped": clipped,
        })
    return rows


def main() -> int:
    tmp = Path(tempfile.mkdtemp())
    real_state_path = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"

    if not REAL_STATE.exists():
        print(f"找不到用户设置 {REAL_STATE}")
        return 1
    user = json.loads(REAL_STATE.read_text(encoding="utf-8"))
    settings = user.get("settings", {})

    source = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(user.get("last_file", ""))
    if not source.exists():
        print(f"找不到文稿 {source}（可以把它作为第一个参数传进来）")
        return 1

    folder = tmp / "简记日记"
    folder.mkdir()
    doc = folder / source.name
    shutil.copy2(source, doc)
    (tmp / "state.json").write_text(json.dumps({
        "folder": str(folder),
        "default_folder": str(folder),
        "last_file": str(doc),
        "settings": settings,
    }, ensure_ascii=False), encoding="utf-8")

    import main as app_main  # noqa: E402
    from main import px  # noqa: E402

    root = tk.Tk()
    screen_w, screen_h = root.winfo_screenwidth(), root.winfo_screenheight()
    root.geometry(f"{screen_w}x{screen_h - 80}+0+0")
    app = app_main.JianJiApp(root)
    root.update()

    print(f"文稿 {source.name}（{source.stat().st_size} 字节）")
    print(f"屏幕 {screen_w}×{screen_h}  SCALE={app_main.SCALE}")
    print(f"设置 {app.settings}")
    app.open_file(doc)
    root.update()
    app.editor.mark_set("insert", "1.0")
    app._apply_styles_without_dirty_flag()
    root.update()

    ed = app.editor
    size = px(app.settings["font_size"])
    print(f"编辑器 {ed.winfo_width()}×{ed.winfo_height()} 留白 {app._current_pad} "
          f"正文列宽 {ed.winfo_width() - app._current_pad * 2}")
    print(f"字号 {size}px  行高 {px(app.settings['line_height'])}px")

    total = int(ed.index("end-1c").split(".")[0])
    ordered = [n for n in range(1, total + 1)
               if re.match(r"^[ \t]*[0-9]+[.)] ",
                           ed.get(f"{n}.0", f"{n}.end").rstrip("\r\n"))]
    print(f"共 {total} 行，有序项 {len(ordered)} 条")
    print()

    ed.yview_moveto(0.0)
    root.update()

    clipped_events = 0
    mid_view_bad: set[int] = set()
    steps = 0
    while True:
        app._redraw_margins()
        root.update()
        height = ed.winfo_height()
        for row in snapshot(app):
            if not row["clipped"]:
                continue
            clipped_events += 1
            print(f"步{steps:>3} 行{row['line']:>4} {row['mark']!r:6s} "
                  f"画布{row['size']} 图元{row['bbox']} 画布位置{row['pos']} ✗")
            # 画布整块都在视口里、图元却还被裁 —— 这才是真的 bug；
            # 视口下沿那条是 Tk 自己裁的（那一显示行只露出一半）
            if row["pos"][1] > 4 and row["pos"][1] + row["size"][1] < height - 4:
                mid_view_bad.add(row["line"])
        before = ed.yview()[0]
        ed.yview_scroll(STEP_UNITS, "units")
        root.update()
        steps += 1
        if ed.yview()[0] <= before or steps > 300:
            break

    print()
    print(f"滚了 {steps} 步；被裁观测 {clipped_events} 次")
    print(f"其中画布完全在视口内、图元仍被裁的行号：{sorted(mid_view_bad)}")

    # 再逐个把有序项滚到视口正中量一次（边缘裁剪不影响这里）
    print()
    print("=== 逐项滚到视口正中再量 ===")
    still_bad = []
    for number in ordered:
        ed.see(f"{number}.0")
        ed.yview_scroll(-6, "units")
        root.update()
        app._redraw_margins()
        root.update()
        for row in snapshot(app):
            if row["line"] == number and row["clipped"]:
                still_bad.append(number)
                print(f"行{number:>4} {row['mark']!r:6s} 画布{row['size']} "
                      f"图元{row['bbox']} ✗  raw={tuple(round(v) for v in ed.dlineinfo(f'{number}.0'))}")
    print(f"居中也还坏的行号：{still_bad}")
    print()
    print("结论：" + ("全部完整" if not mid_view_bad and not still_bad else "仍有被裁的装饰"))

    root.destroy()
    storage.default_state_path = real_state_path
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
