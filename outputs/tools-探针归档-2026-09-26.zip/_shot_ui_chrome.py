"""截几张界面图核验这一轮的改动，用于人工核验。

看四件事：

1. 顶部栏常显（左侧编辑状态、右侧「专注模式」）；
2. 编辑时左侧状态是「…」、保存后清空；
3. 有序列表序号——蓝色、和正文同号，**折行后也要完整**；
4. 折行的引用，竖条要连成一条、第一行不能缩成一小截。

产出放 outputs/。一次性脚本，同类见 _shot_heading.py。
"""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402
from capture_window import capture_hwnd, capture_widget_region  # noqa: E402

DOC = (
    "# 今天\n"
    "\n"
    "下午把书架整理了一遍，翻出两本没读完的书。\n"
    "\n"
    "## 明天要做的事\n"
    "\n"
    "1. 把书按作者重新排一遍\n"
    "2. 这一条故意写得很长很长很长很长很长很长很长很长很长很长很长，"
    "长到必须折行才行，折行之后序号还能不能完整显示就是要看的东西\n"
    "3. 给旧书拍张照\n"
    "\n"
    # 缩进最深的有序项：行首记号有 11 列，量显示行时最容易翻车的那种
    "        1. 缩进很深的有序项也写得很长很长很长很长很长很长很长很长很长很长，"
    "长到必须折行\n"
    "\n"
    "### 顺手记一下\n"
    "\n"
    "- 书签换新的\n"
    "- 把借出去的那本要回来\n"
    "\n"
    "> 书非借不能读也。这一句也故意写长一点，长到折行，看看竖条第一行会不会缩掉。\n"
    "> 第二行正常。\n"
)


def main() -> int:
    tmp = Path(tempfile.mkdtemp())
    real = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"

    folder = tmp / "简记日记"
    folder.mkdir()
    (folder / "读书").mkdir()
    (folder / "2026-09-22.md").write_text(DOC, encoding="utf-8")
    (folder / "读书" / "随笔.md").write_text("# 随笔\n\n随便写写。\n", encoding="utf-8")
    storage.set_default_folder(folder)

    import main as app_main

    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()

    doc = folder / "2026-09-22.md"
    app.open_file(doc)
    root.update()

    out = PROJECT / "outputs"

    # 1) 刚打开：顶部栏常显，左侧状态是空的
    root.update()
    w, h = capture_hwnd(int(root.winfo_id()), out / "顶栏-常显.png")
    print(f"顶栏-常显.png {w}×{h}  顶栏在网格里={app.topbar.grid_info() != {}} "
          f"状态文字={app.status_label.cget('text')!r}")

    # 2) 正在编辑：左侧状态是「…」
    app.editor.mark_set("insert", "end-1c")
    app.editor.insert("end", "又想起一句")
    root.update()
    w, h = capture_hwnd(int(root.winfo_id()), out / "顶栏-编辑中.png")
    print(f"顶栏-编辑中.png {w}×{h}  状态文字={app.status_label.cget('text')!r}")

    # 3) 保存之后：状态清空
    app.save_now()
    root.update()
    w, h = capture_hwnd(int(root.winfo_id()), out / "顶栏-已保存.png")
    print(f"顶栏-已保存.png {w}×{h}  状态文字={app.status_label.cget('text')!r}")

    # 4) 有序列表折行 + 引用折行：整块正文特写
    app.editor.mark_set("insert", "1.0")
    app._apply_styles_without_dirty_flag()
    root.update()
    size = capture_widget_region(app.editor, out / "修复后-序号与引用折行.png", factor=2)
    print(f"修复后-序号与引用折行.png {size[0]}×{size[1]}")

    # 顺带把每块装饰的几何打出来，方便对着图核
    for canvas in app._decor_pool:
        spec = getattr(canvas, "decor_spec", None)
        if not spec:
            continue
        print(f"   {spec} -> x={canvas.winfo_x()} y={canvas.winfo_y()} "
              f"{canvas.winfo_width()}×{canvas.winfo_height()}")

    root.destroy()
    storage.default_state_path = real
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
