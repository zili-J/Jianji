"""诊断「在末尾敲一个字，底部 25% 留白就没了」——把标签状态量清楚。

    python tools/quiet_desktop.py python.exe tools/_probe_pad_typing.py
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402

REAL_STATE = Path.home() / "AppData/Local/JianJi/state.json"
PARAGRAPH = "\n".join(f"第 {i} 段正文，用来把文稿撑长一点，好让它超过一屏。"
                      for i in range(1, 60))


def main() -> int:
    tmp = Path(tempfile.mkdtemp())
    saved = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"

    settings = {}
    if REAL_STATE.is_file():
        settings = json.loads(REAL_STATE.read_text(encoding="utf-8")).get("settings", {})
    folder = tmp / "简记日记"
    folder.mkdir()
    doc = folder / "打字留白.md"
    doc.write_text(PARAGRAPH + "\n最后一句正文。\n", encoding="utf-8")
    (tmp / "state.json").write_text(json.dumps({
        "folder": str(folder), "default_folder": str(folder),
        "last_file": str(doc), "settings": settings,
    }, ensure_ascii=False), encoding="utf-8")

    import main as app_main

    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()
    app.open_file(doc)
    root.update()
    editor = app.editor
    print(f"设置 {app.settings}")
    print(f"Text 自身 spacing1/2/3 = "
          f"{editor.cget('spacing1')}/{editor.cget('spacing2')}/{editor.cget('spacing3')}")
    print(f"_bottom_pad = {app._bottom_pad}  _bottom_pad_line = {app._bottom_pad_line}\n")

    def report(title: str) -> None:
        # 量之前先滚到底：`bbox` 给的是**视口内**的坐标，视图不贴底时量到的
        # 「末行下方空白」只是视口里剩的那一点，会把「留白已经没了」看成「还有一点」。
        editor.yview_moveto(1.0)
        root.update()
        height = editor.winfo_height()
        box = editor.bbox("end-1c")
        total = int(editor.count("1.0", "end", "ypixels")[0])
        ranges = editor.tag_ranges("bottom_pad")
        spans = [f"{a}..{b}" for a, b in zip(ranges[0::2], ranges[1::2])]
        blank = "末行在视口外" if box is None else str(height - (box[1] + box[3]))
        print(f"--- {title} ---")
        print(f"  end-1c = {editor.index('end-1c')}  末行号 = {app._bottom_pad_line}")
        print(f"  内容总高 = {total}   视口 = {height}   下方空白 = {blank}")
        print(f"  yview = ({editor.yview()[0]:.4f},{editor.yview()[1]:.4f})")
        print(f"  bottom_pad 区间 = {spans or '（空！）'}")
        print(f"  bottom_pad spacing3 = {editor.tag_cget('bottom_pad', 'spacing3')!r}")
        print(f"  末行文本 = {editor.get('end-1c linestart', 'end-1c lineend')!r}")
        print()

    editor.mark_set("insert", "end-1c")
    app._refresh_cursor_line()
    editor.see("insert")
    root.update()
    editor.yview_moveto(1.0)
    root.update()
    report("滚到底（未打字）")

    editor.insert("insert", "字")
    root.update()
    report("敲了一个字之后")

    app._apply_bottom_pad(force=True)
    root.update()
    report("手动 force 重挂之后")

    editor.insert("insert", "再")
    root.update()
    report("再敲一个字之后")

    app._apply_bottom_pad(force=True)
    root.update()
    report("再 force 一次")

    root.destroy()
    storage.default_state_path = saved
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
