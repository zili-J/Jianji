"""端到端流畅度基准：按用户真实动作计时，跨文档规模看变化趋势。

和 `_bench_perf.py` 的区别：那边量的是单个函数的耗时，这边量的是
「动作 + 一整个事件循环（含 Tk 自己的重排、重折行、重画）」——
用户感受到的卡顿在这条路径上，不在函数里。

用法：python tools/_bench_smoothness.py
"""
from __future__ import annotations

import sys
import tempfile
import time
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402


def build_doc(sections: int) -> str:
    """造一份各语法都有的文档：标题、正文、列表、待办、引用，每五节一个表格。"""
    parts = ["# 流畅度基准\n"]
    for index in range(1, sections + 1):
        parts.append(f"\n## 第 {index} 节\n")
        parts.append(f"\n这是第 {index} 节的正文，带 **粗体** 和 `代码`。\n")
        parts.append(f"\n- 第 {index} 节的第一条\n  - 嵌套一条\n- [ ] 待办 {index}\n")
        parts.append(f"\n> 第 {index} 节的引用。\n")
        if index % 5 == 0:
            parts.append(f"\n| 项目 | 数量 |\n| --- | ---: |\n| 第 {index} 节 | {index} |\n")
    return "".join(parts)


def measure(action, repeat: int = 12) -> float:
    """跑 repeat 次，取最快的一次（避开 GC、首次布局等一次性开销）。"""
    best = float("inf")
    for _ in range(repeat):
        root.update()
        start = time.perf_counter()
        action()
        root.update()
        best = min(best, (time.perf_counter() - start) * 1000)
    return best


def bench(sections: int) -> None:
    tmp = Path(tempfile.mkdtemp())
    folder = tmp / "简记日记"
    folder.mkdir()
    doc = folder / "流畅度.md"
    doc.write_text(build_doc(sections), encoding="utf-8")
    storage.default_state_path = lambda: tmp / "state.json"
    storage.set_default_folder(folder)

    from main import JianJiApp

    global root
    root = tk.Tk()
    app = JianJiApp(root)
    app.open_file(doc)
    root.update()
    app.editor.mark_set("insert", "20.0")
    app._apply_styles_without_dirty_flag()
    root.update()

    lines = len(app.editor.get("1.0", "end-1c").splitlines())

    toggle = measure(lambda: app.toggle_focus(), repeat=6)
    if app.focus_mode:                       # 量完记得切回来
        app.toggle_focus()
        root.update()

    scroll = measure(lambda: app.editor.yview_scroll(4, "units"))

    # 光标要在两行之间来回挪：停在原地的话第二次就是空转，量出来的不是真东西
    hop = {"n": 0}

    def move_cursor():
        hop["n"] += 1
        app.editor.mark_set("insert", "22.0" if hop["n"] % 2 else "23.0")
        app._refresh_cursor_line()

    cursor = measure(move_cursor)

    def type_one():
        app.editor.insert("insert", "字")

    typed = measure(type_one, repeat=8)

    print(f"{lines:5d} 行 | 滚轮一格 {scroll:6.1f} ms | 换一行光标 {cursor:5.1f} ms |"
          f" 敲一个字 {typed:6.1f} ms | 切换专注模式 {toggle:6.1f} ms")
    root.destroy()


if __name__ == "__main__":
    print("动作 + 一整个事件循环的耗时（越快越好）：")
    for size in (20, 60, 150, 400):
        bench(size)
