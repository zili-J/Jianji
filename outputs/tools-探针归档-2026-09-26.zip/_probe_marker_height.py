"""量「行首记号露出前后，这一行的**高度**变不变」。

为什么不用 `_probe_bullet_wrap.py` 的见证 y：那里文稿很长，远离视口的行 Tk 只挂
「估计高度」，绝对 y 是估出来的、会飘。这里把文稿压到**一屏放得下**，每一行都真的
排过版，量到的 y 才是真的。

行高 = 下一行的 y − 本行的 y。行高变了，下方文字就会跳一下。

    python tools/quiet_desktop.py python.exe tools/_probe_marker_height.py
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402

REAL_STATE = Path.home() / "AppData/Local/JianJi/state.json"

BODY = "列表项正文要够长才会折行，这里故意写得长一些用来观察折行位置。"
CASES = [("- " + BODY, "无序 0 级"), ("- [ ] " + BODY, "任务未勾"),
         ("> " + BODY, "引用"), ("1. " + BODY, "有序"), (BODY, "普通正文")]


def main() -> int:
    tmp = Path(tempfile.mkdtemp())
    real_state_path = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"

    settings = {}
    if REAL_STATE.is_file():
        settings = json.loads(REAL_STATE.read_text(encoding="utf-8")).get("settings", {})
    folder = tmp / "简记日记"
    folder.mkdir()
    doc = folder / "行高核验.md"
    lines = ["# 行高", ""]
    targets = []
    for source, label in CASES:
        lines.append(source)
        targets.append((len(lines), label))
    lines.append("结尾行")
    doc.write_text("\n".join(lines) + "\n", encoding="utf-8")
    (tmp / "state.json").write_text(json.dumps({
        "folder": str(folder), "default_folder": str(folder),
        "last_file": str(doc), "settings": settings,
    }, ensure_ascii=False), encoding="utf-8")

    import main as app_main

    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()
    if os.environ.get("JIANJI_OLD"):
        def old_tag_marker(line, start, end, cursor_line, indent):
            tag = "syntax_current" if line == cursor_line else "syntax"
            app.editor.tag_add(tag, f"{line}.{start}", f"{line}.{end}")
            app._line_marks.setdefault(line, []).append(
                ("syntax", "syntax_current", start, end, None))
        app._tag_marker = old_tag_marker
        print("**修复前行为**")
    app.open_file(doc)
    root.update()
    if os.environ.get("JIANJI_SYNTAX_SPACING"):
        values = [int(part) for part in os.environ["JIANJI_SYNTAX_SPACING"].split(",")]
        options = {"elide": True}
        for name, value in zip(("spacing1", "spacing2", "spacing3"), values):
            options[name] = value
        app.editor.tag_configure("syntax", **options)
        print(f"**syntax 标签 {options}**")
    root.update()

    editor = app.editor
    last = len(lines)
    print(f"设置 {app.settings}")
    print(f"px(行高)={app_main.px(app.settings['line_height'])}  "
          f"字体行距={app._body_font_object().metrics('linespace')}  "
          f"_marker_phantom()={app._marker_phantom()}\n")

    def move_cursor(target: str) -> None:
        editor.mark_set("insert", target)
        editor.see("insert")
        app._refresh_cursor_line()
        root.update()

    def row_height(line: int) -> int | None:
        """本行高度 = 下一行的 y − 本行的 y。"""
        editor.tk.call(editor, "count", "-update", "1.0", "end")
        here = editor.bbox(f"{line}.0")
        below = editor.bbox(f"{line + 1}.0")
        if here is None or below is None:
            return None
        return below[1] - here[1]

    print(f"{'列表项':<12} {'记号隐藏':>8} {'记号露出':>8}  结论")
    bad = 0
    for line, label in targets:
        move_cursor(f"{last}.0")            # 光标停在结尾行，目标行仍在一屏内
        away = row_height(line)
        move_cursor(f"{line}.end")
        if os.environ.get("JIANJI_LINE_SPACING1"):
            value = int(os.environ["JIANJI_LINE_SPACING1"])
            editor.tag_configure("probe_line", spacing1=value)
            editor.tag_add("probe_line", f"{line}.0", f"{line}.end")
            root.update()
        here = row_height(line)
        if os.environ.get("JIANJI_LINE_SPACING1"):
            editor.tag_remove("probe_line", f"{line}.0", f"{line}.end")
            root.update()
        cfg = editor.tag_configure("syntax_marker")
        print(f"    [syntax_marker] spacing1={cfg.get('spacing1')} "
              f"spacing2={cfg.get('spacing2')} wrap={cfg.get('wrap')} "
              f"lmargin1={cfg.get('lmargin1')}")
        flag = ""
        if away is not None and here is not None and away != here:
            flag = f"**行高变了 {away} -> {here}（差 {here - away}）**"
            bad += 1
        print(f"{label:<12} {str(away):>8} {str(here):>8}  {flag}")

    # 顺带把「记号隐藏时下方总共被顶下多少」量出来：与「有序」行（记号从不露出）对照
    move_cursor(f"{last}.0")
    print(f"\n光标在结尾行时，各目标行的 y：")
    for line, label in targets:
        box = editor.bbox(f"{line}.0")
        print(f"  {label:<12} y={box[1] if box else None}")
    print(f"\n行高不一致的行数：{bad}")
    root.destroy()
    storage.default_state_path = real_state_path
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
