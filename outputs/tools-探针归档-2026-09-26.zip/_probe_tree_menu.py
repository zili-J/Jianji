"""核验「右键点文件夹会不会弹出菜单」。

用法：python tools/_probe_tree_menu.py
产出：屏幕输出 + outputs/文件夹右键菜单.txt

Windows 上 Tk 的菜单是**原生菜单**，`tk_popup`/`post` 会走进模态循环、不返回，
所以这里把 `tk.Menu.tk_popup` 换成一个只记录参数的桩，看「到底有没有走到弹菜单」
这一步、菜单里有哪些项。这样在隐藏桌面上也能跑。
"""
import json
import os
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import storage                                     # noqa: E402


def real_settings() -> dict:
    path = Path(os.environ.get("LOCALAPPDATA", "")) / "JianJi" / "state.json"
    try:
        return json.loads(path.read_text(encoding="utf-8")).get("settings", {})
    except (OSError, ValueError):
        return {}


def main() -> None:
    tmp = Path(tempfile.mkdtemp())
    state = tmp / "state.json"
    state.write_text(json.dumps({"settings": real_settings()}, ensure_ascii=False),
                     encoding="utf-8")
    storage.default_state_path = lambda: state
    folder = tmp / "简记日记"
    folder.mkdir()
    (folder / "随笔").mkdir()
    (folder / "读书").mkdir()
    (folder / "随笔" / "第一篇.md").write_text("# 第一篇\n\n正文。\n", encoding="utf-8")
    (folder / "根文稿.md").write_text("# 根文稿\n\n正文。\n", encoding="utf-8")
    storage.set_default_folder(folder)

    import tkinter as tk

    from main import JianJiApp

    calls: list[tuple[int, int]] = []

    def fake_popup(self, x, y, *args, **kwargs):
        calls.append((x, y))

    real_popup = tk.Menu.tk_popup
    tk.Menu.tk_popup = fake_popup

    root = tk.Tk()
    root.geometry("1240x820")
    app = JianJiApp(root)
    root.update()

    out: list[str] = []
    tree = app.folder_tree
    out.append(f"树里的节点 = {[(i, tree.item(i, 'text')) for i in tree.get_children()]}")
    out.append("")

    # 逐个节点：直接看菜单里有什么
    for iid in tree.get_children():
        menu = app._tree_menu(iid)
        labels = []
        for index in range(menu.index("end") + 1):
            if menu.type(index) == "separator":
                labels.append("---")
            else:
                labels.append(menu.entrycget(index, "label"))
        out.append(f"节点 {iid!r}（{tree.item(iid, 'text')}）的菜单 = {labels}")

    out.append("")
    # 模拟右键：先量出文件夹那一行的 y
    for iid in tree.get_children():
        box = tree.bbox(iid)
        if not box:
            out.append(f"节点 {iid!r} 不在视口内（bbox 为空），跳过模拟")
            continue
        calls.clear()
        event = type("E", (), {"x": box[0] + 10, "y": box[1] + box[3] // 2,
                               "x_root": 400, "y_root": 300})()
        try:
            app._on_tree_right_click(event)
        except Exception as error:                  # noqa: BLE001
            out.append(f"节点 {iid!r} 右键抛异常：{type(error).__name__}: {error}")
            continue
        out.append(f"节点 {iid!r} 右键 → tk_popup 调用 {len(calls)} 次 {calls}")
        root.update()

    out.append("")
    out.append(f"当前 scope_folder = {app.scope_folder}")
    out.append(f"当前 trash_mode  = {app.trash_mode}")

    tk.Menu.tk_popup = real_popup

    out_dir = PROJECT / "outputs"
    out_dir.mkdir(exist_ok=True)
    (out_dir / "文件夹右键菜单.txt").write_text("\n".join(out), encoding="utf-8")
    print("\n".join(out))

    root.destroy()


if __name__ == "__main__":
    main()
