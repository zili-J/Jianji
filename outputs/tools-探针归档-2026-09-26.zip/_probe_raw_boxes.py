"""逐字符打印 bbox，不做任何分组推断——记号露出前后到底怎么排版，看原始数据。

    python tools/quiet_desktop.py python.exe tools/_probe_raw_boxes.py
    JIANJI_NO_COMPENSATE=1 python tools/quiet_desktop.py python.exe tools/_probe_raw_boxes.py
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402

REAL_STATE = Path.home() / "AppData/Local/JianJi/state.json"

BODY = "列表项正文要够长才会折行，这里故意写得长一些用来观察折行位置。"
CASES = [("- " + BODY, "无序 0 级"), ("- [ ] " + BODY, "任务未勾")]


def main() -> int:
    tmp = Path(tempfile.mkdtemp())
    real_state_path = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"

    settings = {}
    if REAL_STATE.is_file():
        settings = json.loads(REAL_STATE.read_text(encoding="utf-8")).get("settings", {})
    folder = tmp / "简记日记"
    folder.mkdir()
    doc = folder / "原始盒子.md"
    lines = ["# 原始盒子", ""]
    for source, _label in CASES:
        lines.append(source)
        lines.append("")
    doc.write_text("\n".join(lines) + "\n", encoding="utf-8")
    (tmp / "state.json").write_text(json.dumps({
        "folder": str(folder), "default_folder": str(folder),
        "last_file": str(doc), "settings": settings,
    }, ensure_ascii=False), encoding="utf-8")

    import main as app_main

    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()
    if os.environ.get("JIANJI_NO_COMPENSATE"):
        app._body_text_width = lambda _text: 0
        print("**缩进补偿已关闭**")
    if os.environ.get("JIANJI_OLD"):
        # 精确复原修复前的行为：`_tag_marker` 退回原来的 `_tag_syntax` 分支
        # （只加 syntax / syntax_current，不做缩进补偿、不动折行方式）。
        def old_tag_marker(line, start, end, cursor_line, indent):
            tag = "syntax_current" if line == cursor_line else "syntax"
            app.editor.tag_add(tag, f"{line}.{start}", f"{line}.{end}")
            app._line_marks.setdefault(line, []).append(
                ("syntax", "syntax_current", start, end, None))
        app._tag_marker = old_tag_marker
        print("**修复前行为（syntax_current，无补偿、不按字符折行）**")
    app.open_file(doc)
    root.update()

    editor = app.editor
    total = int(editor.index("end-1c").split(".")[0])
    print(f"设置 {app.settings}  留白 {app._current_pad}")
    print(f"编辑器宽 {editor.winfo_width()}  wrap={editor.cget('wrap')}  "
          f"tabs={editor.cget('tabs')!r}")
    print(f"syntax_marker 配置 = {editor.tag_configure('syntax_marker')}")
    print(f"li0 配置 = {editor.tag_configure('li0')}\n")

    def move_cursor(target: str) -> None:
        editor.mark_set("insert", target)
        editor.see("insert")
        app._refresh_cursor_line()
        root.update()

    for index, (source, label) in enumerate(CASES):
        line = 3 + index * 2
        print("=" * 78)
        print(f"{label}  第 {line} 行  共 {len(source)} 字符")
        for state in ("光标在别处", "光标在本行"):
            move_cursor(f"{total}.0" if state == "光标在别处" else f"{line}.end")
            editor.tk.call(editor, "count", "-update", "1.0", "end")
            print(f"  [{state}] insert={editor.index('insert')} "
                  f"tags@0={editor.tag_names(f'{line}.0')}")
            print(f"    rng_marker={[str(x) for x in editor.tag_ranges('syntax_marker')]} "
                  f"rng_syntax={[str(x) for x in editor.tag_ranges('syntax')]}")
            print(f"    dline(0)={editor.dlineinfo(f'{line}.0')}  "
                  f"ndisplay={editor.tk.call(editor, 'count', '-displaylines', f'{line}.0', f'{line}.end')}")
            boxes = []
            for i in range(len(source) + 1):
                box = editor.bbox(f"{line}.{i}")
                boxes.append(f"{i}:{box[0]},{box[1]},{box[2]}x{box[3]}" if box else f"{i}:-")
            print("    " + "  ".join(boxes))
    root.destroy()
    storage.default_state_path = real_state_path
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
