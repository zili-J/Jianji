"""把某一行单独走一遍 `_export_pieces` + `_wrap`，逐步打印，找出「凭空多一个换行」。

    python tools/_probe_wrap_one.py
"""
from __future__ import annotations

import sys
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))

import image_export as ie  # noqa: E402
import main as app_main  # noqa: E402

CASES = [
    # 前一行以两个空格结尾（Markdown 硬换行），这一行以两个空格缩进
    "  语法记号平时自动隐藏；光标移到哪一行，那一行的记号就显示出来，方便修改。",
    # 行内加粗 + 空格 + 西文
    "- **输入即预览**：输入 Markdown 语法后立刻呈现排版效果，没有「源码 / 预览」模式切换。  ",
    # 纯中文长句（对照组，应当正常填满）
    "很长的正文。" * 8,
]


def main() -> int:
    options = ie.Options()
    width = options.margin + options.content_width - options.list_left(0)
    fonts = ie._Fonts()
    try:
        print(f"正文列宽 {options.content_width}  列表项可用宽 {width}  "
              f"正文字号 {options.body_size}\n")
        for raw in CASES:
            print(f"--- 源码行：{raw!r}")
            info = app_main.parse_block(raw)
            body = {"family": options.family, "size": options.body_size}
            text = raw[info.marker[1]:] if info.kind in (
                "bullet", "task", "ordered") else raw
            pieces = app_main._export_pieces(text, body, options)
            print(f"    块类型 {info.kind}   片段 "
                  f"{[(p.text, fonts.width(p.text, p.font)) for p in pieces]}")

            # 手工重放一遍 _wrap 的累加过程，打印每次断行的位置与原因
            print("    逐字累加：")
            used = 0
            for piece in pieces:
                if not piece.text:
                    continue
                widths = fonts.char_widths(piece.text, piece.font)
                for index, char in enumerate(piece.text):
                    over = used + widths[index] > width
                    if over:
                        cut = ie._break_index(piece.text, 0, index)
                        print(f"      第 {index} 字 {char!r} 放不下："
                              f"已用 {used} + {widths[index]} > {width}"
                              f"   空格断点 = {cut}"
                              f"   断点前的文字 = {piece.text[:cut]!r}")
                        break
                    used += widths[index]
                else:
                    continue
                break

            lines = ie._wrap(pieces, width, fonts)
            print(f"    _wrap 出来 {len(lines)} 行：")
            for number, line in enumerate(lines, start=1):
                content = "".join(p.text for p in line)
                print(f"      {number}: 宽 {ie._measure(line, fonts):>4}  {content!r}")
            print()
    finally:
        fonts.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
