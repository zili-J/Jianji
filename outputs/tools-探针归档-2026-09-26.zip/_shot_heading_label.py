"""截取「标题左侧 H1/H2/H3 徽标」的核验图。

产出：
  outputs/标题徽标预览.png   —— 整窗
  outputs/标题徽标特写.png   —— 编辑区 2 倍放大（看徽标与标题的对齐）
"""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import storage  # noqa: E402
import tkinter as tk  # noqa: E402
from capture_window import capture_hwnd, capture_widget_region  # noqa: E402

DOC = """# 一级标题

正文段落，字号与标题完全相同，靠左侧的 H1/H2/H3 徽标区分层级。

## 二级标题

再写一段正文用来对照。徽标和行号一样，只在标题所在行出现。

### 三级标题

最后一段正文。标题下方留白比上方小，避免和下一段贴在一起。

## 再一个二级标题

用来确认徽标会跟随滚动与重排更新。

正文里还有 **加粗**、*斜体* 与 `行内代码` 三种行内样式。
"""


def main() -> None:
    tmp = Path(tempfile.mkdtemp())
    real_state = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"

    folder = tmp / "简记日记"
    folder.mkdir()
    doc = folder / "标题徽标.md"
    doc.write_text(DOC, encoding="utf-8")
    storage.set_default_folder(folder)

    from main import JianJiApp

    root = tk.Tk()
    app = JianJiApp(root)
    app.open_file(doc)
    root.update()

    # 把光标放到文末，让标题行的 Markdown 记号被隐藏，看到真正的排版效果
    app.editor.mark_set("insert", "end-1c")
    app._apply_styles_without_dirty_flag()
    root.update()
    root.update_idletasks()

    out_dir = PROJECT / "outputs"
    out_dir.mkdir(parents=True, exist_ok=True)

    w, h = capture_hwnd(int(root.winfo_toplevel().winfo_id()),
                        out_dir / "标题徽标预览.png")
    print(f"full   {w} x {h}")

    zw, zh = capture_widget_region(app.editor, out_dir / "标题徽标特写.png", factor=2)
    print(f"zoom   {zw} x {zh}")

    # 顺带打印徽标几何，便于数值核对（别只靠看缩略图）
    print("pad", app._current_pad, "canvas x", app.heading_labels.winfo_x(),
          "w", app.heading_labels.winfo_width())
    for item in app.heading_labels.find_all():
        print("  label", app.heading_labels.itemcget(item, "text"),
              app.heading_labels.coords(item))

    root.destroy()
    storage.default_state_path = real_state


if __name__ == "__main__":
    main()
