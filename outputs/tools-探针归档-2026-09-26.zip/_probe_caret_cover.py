"""量「装饰画布有没有盖住插入光标」。

用法：python tools/_probe_caret_cover.py
      （或套隐藏桌面：python tools/quiet_desktop.py <python> tools/_probe_caret_cover.py）

产出：outputs/光标遮挡.txt

为什么单独量这个：Tk 的插入光标是一条 1px 竖线，**画在子窗口下面**，而装饰用的
`tk.Canvas` 是不透明的、`place()` 在正文控件之上 —— 只要它的矩形盖住光标那一列，
光标就整个消失（用户报的「回车续号之后光标丢了」）。文本层面完全看不出问题，
只有把「光标矩形」和「每块画布的矩形」都量出来做相交判断才抓得住。

**必须在用户真实设置下量**：列宽/字号/行高不同，`bbox` 与折行位置都不同。
所以先把 `%LOCALAPPDATA%\\JianJi\\state.json` 里的 `settings` 原样抄进临时 state.json，
再构造 `JianJiApp`（设置只在启动时读一次）。
"""
import json
import os
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))
sys.path.insert(0, str(PROJECT / "tools"))

import storage                                     # noqa: E402

DOC = """# 光标遮挡核验

1. 第一条
2. 第二条
3. 第三条

正文结束。
"""


def real_settings() -> dict:
    """用户 state.json 里的 settings；读不到就退回默认值并打一行提示。"""
    path = Path(os.environ.get("LOCALAPPDATA", "")) / "JianJi" / "state.json"
    try:
        return json.loads(path.read_text(encoding="utf-8")).get("settings", {})
    except (OSError, ValueError):
        print(f"（读不到 {path}，改用默认设置——核验结论可能不适用于用户）")
        return {}


def rect_of_canvas(canvas) -> tuple[int, int, int, int] | None:
    info = canvas.place_info()
    if not info or not canvas.winfo_manager():
        return None
    try:
        x, y = int(info["x"]), int(info["y"])
        w, h = int(info["width"]), int(info["height"])
    except (KeyError, ValueError):
        return None
    return x, y, w, h


def overlaps(a, b) -> bool:
    ax, ay, aw, ah = a
    bx, by, bw, bh = b
    return ax < bx + bw and bx < ax + aw and ay < by + bh and by < ay + ah


def dump(app, title: str, out: list[str]) -> None:
    editor = app.editor
    out.append(f"=== {title} ===")
    out.append(f"文本        = {editor.get('1.0', 'end-1c')!r}")
    out.append(f"insert      = {editor.index('insert')}   _cursor_line = {app._cursor_line}")
    out.append(f"_current_pad = {app._current_pad}   "
               f"editor.winfo_x() = {editor.winfo_x()}   "
               f"editor.winfo_width() = {editor.winfo_width()}")
    text_left = editor.winfo_x() + app._current_pad
    out.append(f"text_left   = {text_left}")

    box = editor.bbox("insert")
    if box is None:
        out.append("bbox('insert') = None（光标不在视口内）")
        caret = None
    else:
        caret = (box[0], box[1], max(1, box[2]), box[3])
        out.append(f"光标矩形    = {caret}   → 竖线那一列 x = {box[0]}")
        # 竖线是 1px 宽，只用它那一列跟画布比
        caret_line = (box[0], box[1], 1, box[3])

    used = 0
    for index, canvas in enumerate(app._decor_pool):
        spec = getattr(canvas, "decor_spec", None)
        if spec is None:
            continue
        used += 1
        rect = rect_of_canvas(canvas)
        line = getattr(canvas, "decor_line", "?")
        out.append(f"  画布#{index} 行 {line} spec={spec!r} 矩形={rect}")
        if rect is not None and caret is not None and overlaps(rect, caret_line):
            out.append(f"    ** 盖住了光标！画布 x {rect[0]}..{rect[0] + rect[2]}，"
                       f"光标列 {caret_line[0]} **")
    out.append(f"（共 {used} 块画布在用）")
    out.append("")


def main() -> None:
    tmp = Path(tempfile.mkdtemp())
    state = tmp / "state.json"
    state.write_text(json.dumps({"settings": real_settings()}, ensure_ascii=False),
                     encoding="utf-8")
    storage.default_state_path = lambda: state
    folder = tmp / "简记日记"
    folder.mkdir()
    doc = folder / "光标遮挡核验.md"
    doc.write_text(DOC, encoding="utf-8")
    storage.set_default_folder(folder)

    import tkinter as tk

    from main import JianJiApp

    root = tk.Tk()
    root.geometry("1240x820")
    app = JianJiApp(root)
    root.update()
    app.open_file(doc)
    root.update()

    out: list[str] = [f"用户设置 = {app.settings}", ""]
    dump(app, "打开后（光标在 1.0）", out)

    # 光标放到「3. 第三条」行尾，按回车 → 续出空项「4. 」
    app.editor.mark_set("insert", "4.end")
    app.editor.focus_set()
    app._refresh_cursor_line()
    root.update()
    dump(app, "光标移到 4.end", out)

    app._on_editor_return()
    root.update()
    dump(app, "回车续号之后（新空项，光标应可见）", out)

    # 再打一个字，看光标是否移出序号画布
    app.editor.insert("insert", "新内容")
    app._refresh_cursor_line()
    root.update()
    dump(app, "在空项里打一个字之后", out)

    out_dir = PROJECT / "outputs"
    out_dir.mkdir(exist_ok=True)
    (out_dir / "光标遮挡.txt").write_text("\n".join(out), encoding="utf-8")
    print("\n".join(out))

    root.destroy()


if __name__ == "__main__":
    main()
