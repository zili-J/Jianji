"""把任意一篇文稿按应用自己的导出链路渲染成长图，写到 outputs/。

    python tools/quiet_desktop.py <python 全路径> tools/_render_doc.py <文稿路径> [输出名]

只读用户的 state.json 拿 settings；写文件只用临时 state.json。
"""
from __future__ import annotations

import json
import os
import struct
import sys
import tempfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))

import image_export as ie  # noqa: E402
import main as app_main  # noqa: E402
import storage  # noqa: E402
import tkinter as tk  # noqa: E402

REAL_STATE = Path(os.environ.get("LOCALAPPDATA", "")) / "JianJi" / "state.json"


def main() -> int:
    if len(sys.argv) < 2:
        print("用法：tools/_render_doc.py <文稿路径> [输出名]")
        return 1
    doc = Path(sys.argv[1])
    stem = sys.argv[2] if len(sys.argv) > 2 else doc.stem
    out = PROJECT / "outputs"
    out.mkdir(exist_ok=True)

    tmp = Path(tempfile.mkdtemp())
    saved = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"
    settings = json.loads(REAL_STATE.read_text(encoding="utf-8")).get("settings", {})
    folder = tmp / "d"
    folder.mkdir()
    (tmp / "state.json").write_text(json.dumps({
        "folder": str(folder), "default_folder": str(folder),
        "last_file": "", "settings": settings}, ensure_ascii=False), encoding="utf-8")

    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()
    options = app._export_options()
    fonts = ie._Fonts()
    try:
        text = doc.read_text(encoding="utf-8-sig")
        images = ie.render(app_main.build_export_rows(text, options), options,
                           app_main.export_palette(), fonts)
    finally:
        fonts.close()
        root.destroy()
        storage.default_state_path = saved

    for index, data in enumerate(images):
        width, height = struct.unpack(">II", data[16:24])
        name = f"{stem}{'' if index == 0 else f'-{index + 1}'}.png"
        (out / name).write_bytes(data)
        print(f"outputs/{name}: {width}×{height}  {len(data) / 1024:.0f} KB")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
