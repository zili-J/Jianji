"""在「图宽 1080px、字号 32px」不变的前提下，量不同边距能消掉多少短尾巴。

每行字数上限 = (1080 − 2×边距) ÷ 32，纯算术：
    边距 72 → 936px → 29 字（现状）
    边距 44 → 992px → 31 字
    边距 24 → 1032px → 32 字
    边距 12 → 1056px → 33 字
所以「1080px + 32px 字号」这两条同时不变时，每行最多就是 33 字。

「短尾巴」定义：同一逻辑行折出 ≥2 个显示行，且**最后一行不足 8 字**。
那种行就是用户看到的「吗）」「留白）」「滑块调节。」。

    python tools/quiet_desktop.py <python 全路径> tools/_probe_orphan.py
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from dataclasses import replace
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))

import image_export as ie  # noqa: E402
import main as app_main  # noqa: E402
import storage  # noqa: E402
import tkinter as tk  # noqa: E402

REAL_STATE = Path(os.environ.get("LOCALAPPDATA", "")) / "JianJi" / "state.json"
DOC_DIR = Path(r"C:\Users\22910\Documents\wb01")
MARGINS = [72, 44, 24, 12]


def main() -> int:
    docs = sorted(p for p in DOC_DIR.glob("*.md"))
    if not docs:
        print("找不到文稿")
        return 1
    tmp = Path(tempfile.mkdtemp())
    saved = storage.default_state_path
    storage.default_state_path = lambda: tmp / "state.json"
    settings = json.loads(REAL_STATE.read_text(encoding="utf-8")).get("settings", {})
    folder = tmp / "d"
    folder.mkdir()
    (tmp / "state.json").write_text(json.dumps({
        "folder": str(folder), "default_folder": str(folder),
        "last_file": "", "settings": settings}, ensure_ascii=False), encoding="utf-8")

    root = tk.Tk()
    root.geometry("1180x760")
    app = app_main.JianJiApp(root)
    root.update()
    base = app._export_options()
    fonts = ie._Fonts()
    try:
        for margin in MARGINS:
            options = replace(base, margin=margin)
            cap = (options.width - 2 * margin) // options.body_size
            orphans = 0
            two_liners = 0
            total = 0
            for doc in docs:
                rows = app_main.build_export_rows(doc.read_text(encoding="utf-8-sig"), options)
                lines = ie.build_layout(rows, options, app_main.export_palette(), fonts)
                per_row: dict[int, list] = {}
                for line in lines:
                    per_row.setdefault(id(line.row), []).append(line)
                for group in per_row.values():
                    if len(group) < 2:
                        continue
                    total += 1
                    two_liners += 1
                    tail = "".join(p.text for p in group[-1].pieces).strip()
                    if len(tail) < 8:
                        orphans += 1
            print(f"边距 {margin:>3}px → 内容宽 {options.width - 2 * margin:>4}px → "
                  f"每行约 {cap:>2} 字：折成多行的 {two_liners:>3} 行里，"
                  f"短尾巴（尾行 <8 字）**{orphans:>3} 处**")
    finally:
        fonts.close()
        root.destroy()
        storage.default_state_path = saved
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
