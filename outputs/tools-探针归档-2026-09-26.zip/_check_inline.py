"""把一段行内语法单独渲染出来，放大核验颜色与记号是否真的被隐藏。"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "app"))

from image_export import Options, Palette, render       # noqa: E402
from main import build_export_rows, export_palette      # noqa: E402

TEXT = ("正文里可以有 **加粗**、*斜体*、~~删除线~~、==高亮==、`行内代码` 和\n"
        "[链接](https://example.com)，还有 ![图片](a.png) 以及 ***两层***。\n")

options = Options(width=1080, margin=24, body_size=40, line_height=58,
                  mono_size=36, table_padding=18, list_indent=30,
                  list_marker_gap=15, marker_radius=7, task_box=18,
                  quote_bar_width=5, quote_bar_gap=21, badge_size=24,
                  badge_gap=12, hr_thickness=2, head_gap=12)
rows = build_export_rows(TEXT, options)
images = render(rows, options, export_palette())
out = ROOT / "outputs" / "_check_inline.png"
out.write_bytes(images[0])
print(f"{out}  {len(images)} 张  {len(images[0]) / 1024:.0f} KB")
for row in rows:
    print(" ", row.kind, [(p.text, p.color, p.bold, p.italic, p.strike,
                           p.underline, p.background) for p in row.pieces])
